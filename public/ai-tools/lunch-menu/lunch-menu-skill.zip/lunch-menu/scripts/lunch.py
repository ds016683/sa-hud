#!/usr/bin/env python3
"""lunch.py, the lunch-menu skill's hand.

One lunch = one event config in private storage (project-files/lunch/<slug>/config.json),
served by the lunch door at https://lunch.thirdhorizon.com/<slug>. Secrets come from
~/.claude/hud-board/.env; nothing here prints them.

  lunch.py new <slug> --title "MMA Lunch" --lunch-at "2026-11-12 12:00" --guests "Carrie, Kate" --menu menu.json
               [--objective-id <id>] [--place "..."] [--closes-at "..."] [--code ...] [--max-items N] [--replace]
  lunch.py list                         every live event and when it scuttles
  lunch.py show <slug>                  the config without the menu body
  lunch.py menu <slug> menu.json        replace the menu
  lunch.py guests <slug> [--add "A, B"] [--remove "C"]
  lunch.py status <slug>                who has ordered, who is in the page, who is waiting, refusals
  lunch.py record <slug> --guest "Carrie" --items margherita [--option "chicken-pesto:Side=Fries"] [--note "..."] [--replace]
  lunch.py final <slug> [--extra "3 x Bread Service (for the table)"] [--to Erica] [--from David]
  lunch.py unblock <slug>               clear wrong-code lockouts (a room on one network shares an address)
  lunch.py check <slug>                 live checks on the public address
  lunch.py rebuild <slug>               rebuild the order sheet on the mission's Workbench
  lunch.py scuttle <slug>               delete the event now (config, orders, trail, sheet); a tombstone stays
"""
import argparse, collections, datetime, json, os, re, secrets, subprocess, sys, time, urllib.error, urllib.request
from zoneinfo import ZoneInfo

HOST = 'lunch.thirdhorizon.com'
CHI = ZoneInfo('America/Chicago')
HERE = os.path.dirname(os.path.abspath(__file__))
ENV = dict(l.strip().split('=', 1) for l in open(os.path.expanduser('~/.claude/hud-board/.env')) if '=' in l and not l.startswith('#'))
H = {'apikey': ENV['SUPABASE_SERVICE_KEY'], 'Authorization': f"Bearer {ENV['SUPABASE_SERVICE_KEY']}", 'Content-Type': 'application/json'}
B = f"{ENV['SUPABASE_URL']}/storage/v1"
SLUG = re.compile(r'^[a-z0-9][a-z0-9-]{0,39}$')
slugify = lambda s: re.sub(r'[^a-z0-9]+', '-', str(s).lower()).strip('-')

def call(method, path, body=None, extra=None):
    req = urllib.request.Request(f'{B}/{path}', data=json.dumps(body, ensure_ascii=False).encode() if body is not None else None, method=method, headers={**H, **(extra or {})})
    raw = urllib.request.urlopen(req).read()
    return json.loads(raw) if raw else None
def get(path):
    try: return call('GET', f'object/project-files/{path}?cb={time.time()}')
    except urllib.error.HTTPError: return None
def put(path, doc): call('POST', f'object/project-files/{path}', doc, {'x-upsert': 'true'})
def ls(prefix, folders=False):
    rows = call('POST', 'object/list/project-files', {'prefix': prefix, 'limit': 1000, 'sortBy': {'column': 'name', 'order': 'asc'}}) or []
    return [f['name'] for f in rows if (f.get('id') is None) == folders]
def rm(paths):
    for i in range(0, len(paths), 100): call('DELETE', 'object/project-files', {'prefixes': paths[i:i + 100]})

def when(text):
    """'2026-11-12 12:00' is Chicago time unless it carries its own offset."""
    d = datetime.datetime.fromisoformat(str(text).strip().replace(' ', 'T'))
    if d.tzinfo is None: d = d.replace(tzinfo=CHI)
    return d
iso = lambda d: d.astimezone(datetime.timezone.utc).isoformat().replace('+00:00', 'Z')
say = lambda i: datetime.datetime.fromisoformat(i.replace('Z', '+00:00')).astimezone(CHI).strftime('%a %b %-d, %-I:%M %p CT') if i else 'not set'
def config(slug):
    c = get(f'lunch/{slug}/config.json')
    if not c: sys.exit(f'no event "{slug}"')
    return c
def save(c): put(f"lunch/{c['slug']}/config.json", c)
def roster(names): return [{'id': slugify(n), 'name': n.strip()} for n in names.split(',') if n.strip()]
def load_menu(path):
    m = json.load(open(path)); seen = set()
    for sec in m.get('sections', []):
        for it in sec.get('items', []):
            if it.get('divider'): continue
            it['id'] = it.get('id') or slugify(it['name'])
            if it['id'] in seen: sys.exit(f"two items share the id {it['id']}; give one an explicit id")
            seen.add(it['id'])
    return m
def items_of(c): return [dict(it, section=sec['title']) for sec in (c.get('menu') or {}).get('sections', []) for it in sec.get('items', []) if it.get('id')]
def orders(slug): return [o for o in (get(f'lunch/{slug}/orders/{n}') for n in ls(f'lunch/{slug}/orders')) if o]
def line(it): return it['name'].rstrip('*') + (' (' + ', '.join(f'{k}: {v}' for k, v in it['options'].items()) + ')' if it.get('options') else '')
def rebuild(slug):
    r = subprocess.run(['node', os.path.join(HERE, 'rebuild.mjs'), slug], capture_output=True, text=True)
    print((r.stdout or r.stderr).strip() or 'sheet rebuild ran')

def cmd_new(a):
    if not SLUG.match(a.slug): sys.exit('slug: lowercase letters, digits and hyphens, the client name')
    if get(f'lunch/{a.slug}/config.json') and not a.replace: sys.exit(f'"{a.slug}" already exists; --replace to overwrite')
    at = when(a.lunch_at)
    c = {'slug': a.slug, 'active': True, 'title': a.title, 'host': 'Third Horizon', 'place': a.place or '', 'when': at.strftime('%A, %B %-d'),
         'lunch_at': iso(at), 'closes_at': iso(when(a.closes_at)) if a.closes_at else None, 'expires_at': iso(at + datetime.timedelta(hours=24)),
         'code': a.code or f'{a.slug.replace("-", "")}-{secrets.randbelow(9000) + 1000}', 'salt': secrets.token_hex(16), 'objective_id': a.objective_id, 'link': f'{HOST}/{a.slug}',
         'roster': roster(a.guests or ''), 'rules': {'max_items': a.max_items}, 'menu': load_menu(a.menu) if a.menu else None}
    save(c)
    print(f"live: https://{HOST}/{a.slug}\naccess code: {c['code']}\nguests: {len(c['roster'])} · items: {len(items_of(c))}\nscuttles: {say(c['expires_at'])} (24 hours after the lunch)")
    if c['objective_id']: rebuild(a.slug)

def cmd_list(a):
    for slug in ls('lunch', folders=True):
        if slug.startswith('_'): continue
        c = get(f'lunch/{slug}/config.json')
        if c: print(f"{slug:<16} {c.get('title', ''):<24} lunch {say(c.get('lunch_at'))} · scuttles {say(c.get('expires_at'))} · {len(ls(f'lunch/{slug}/orders'))} of {len(c.get('roster', []))} in")
    t = ls('lunch/_scuttled'); print(f'{len(t)} scuttled before now')

def cmd_show(a):
    c = config(a.slug); m = c.pop('menu', None)
    print(json.dumps(c, indent=1, ensure_ascii=False)); print('menu:', [(s['title'], sum(1 for i in s['items'] if i.get('id'))) for s in (m or {}).get('sections', [])] or 'none yet')

def cmd_menu(a):
    c = config(a.slug); c['menu'] = load_menu(a.file); save(c); print(len(items_of(c)), 'items'); rebuild(a.slug)

def cmd_guests(a):
    c = config(a.slug)
    for r in roster(a.add or ''):
        if not any(x['id'] == r['id'] for x in c['roster']): c['roster'].append(r)
    gone = {slugify(n) for n in (a.remove or '').split(',') if n.strip()}
    c['roster'] = [r for r in c['roster'] if r['id'] not in gone]
    save(c); print([r['name'] for r in c['roster']]); rebuild(a.slug)

def cmd_status(a):
    c = config(a.slug); os_ = sorted(orders(a.slug), key=lambda o: o['saved_at'])
    print(f"{len(os_)} of {len(c['roster'])} in · scuttles {say(c.get('expires_at'))}")
    for o in os_: print(f"  {o['name']}: {'; '.join(line(i) for i in o['items'])}" + (f" | note: {o['notes']}" if o.get('notes') else ''))
    got = {o['person_id'] for o in os_}; ev = ls(f'lunch/{a.slug}/events')
    seen = {get(f'lunch/{a.slug}/events/{n}').get('person_id') for n in ev if '_identify_' in n}
    print('in the page, not ordered:', ', '.join(r['name'] for r in c['roster'] if r['id'] in seen and r['id'] not in got) or 'no one')
    print('not in yet:', ', '.join(r['name'] for r in c['roster'] if r['id'] not in seen and r['id'] not in got) or 'no one')
    bad = [n for n in ev if '_gate-fail_' in n or '_gate-throttled_' in n or '_post-blocked_' in n]
    print('refused at the gate:', len(bad), [n[11:19] + ' ' + n.split('_')[1] for n in bad[-5:]])

def cmd_record(a):
    c = config(a.slug); r = next((x for x in c['roster'] if x['id'] == slugify(a.guest)), None)
    if not r: sys.exit(f'{a.guest} is not on the guest list; add them with guests --add')
    path = f"lunch/{a.slug}/orders/{r['id']}.json"; prior = get(path)
    if prior and not a.replace: sys.exit(f"{r['name']} already ordered ({'; '.join(line(i) for i in prior['items'])}); --replace to overwrite")
    menu = {i['id']: i for i in items_of(c)}; opts = collections.defaultdict(dict)
    for o in a.option or []:
        iid, kv = o.split(':', 1); k, v = kv.split('=', 1); opts[iid.strip()][k.strip()] = v.strip()
    picked = []
    for iid in [x.strip() for x in a.items.split(',') if x.strip()]:
        if iid not in menu: sys.exit(f'{iid} is not a menu item id; ids: {", ".join(menu)}')
        it = menu[iid]
        for o in it.get('options', []):
            v = opts[iid].get(o['label'])
            if v and v not in o['choices']: sys.exit(f"{it['name']}: {o['label']} is one of {o['choices']}")
            if not v and o.get('required'): sys.exit(f"{it['name']} needs --option \"{iid}:{o['label']}=<{' | '.join(o['choices'])}>\"")
        picked.append({'id': iid, 'name': it['name'], 'section': it['section'], 'price': it.get('price'), 'options': opts[iid]})
    put(path, {'person_id': r['id'], 'name': r['name'], 'items': picked, 'notes': (a.note or '')[:400], 'saved_at': iso(datetime.datetime.now(CHI)), 'version': (prior or {}).get('version', 0) + 1, 'entered_by': 'session, on David\'s word'})
    print('recorded', r['name'], [line(i) for i in picked]); rebuild(a.slug)

def price_of(it):
    for v in (it.get('options') or {}).values():
        m = re.search(r'(\d+(?:\.\d+)?)\s*$', str(v))
        if m: return float(m.group(1))
    m = re.fullmatch(r'\$?\s*(\d+(?:\.\d+)?)', str(it.get('price') or '').strip())
    return float(m.group(1)) if m else None

def cmd_final(a):
    c = config(a.slug); os_ = orders(a.slug); order_of = {s['title']: n for n, s in enumerate((c.get('menu') or {}).get('sections', []))}
    by = collections.OrderedDict(); total = 0.0; known = True; count = 0
    for o in sorted(os_, key=lambda o: o['name']):
        for it in o['items']:
            by.setdefault(it['section'], collections.OrderedDict()).setdefault(line(it), []).append(o['name'])
            p = price_of(it); total += p or 0; known = known and p is not None; count += 1
    body = []
    for sec in sorted(by, key=lambda s: order_of.get(s, 99)):
        body.append(sec)
        for l, names in by[sec].items(): body.append(f"- {len(names)} {l} ({', '.join(names)})")
        body.append('')
    extras = a.extra or []
    if extras: body += ['Also'] + [f'- {e}' for e in extras] + ['']
    notes = [f"{o['name']}: {o['notes']}" for o in os_ if o.get('notes')]
    waiting = [r['name'] for r in c['roster'] if r['id'] not in {o['person_id'] for o in os_}]
    print(f"Subject: {c['title']} order\n\nHi {a.to},\n\nHere is the order for {c['title']}{', ' + c['when'] if c.get('when') else ''}{' at ' + c['place'] if c.get('place') else ''}. Could you place it for us? It is {count}{' menu' if extras else ''} items for {len(os_)} people{', plus the extras at the foot' if extras else ''}.\n")
    print('\n'.join(body).rstrip() + '\n')
    print(('Notes and changes:\n' + '\n'.join(f'- {n}' for n in notes)) if notes else 'No allergies or changes on any of them.')
    if known and count: print(f"\nAt menu prices the ordered items come to about ${total:,.0f} before tax and tip{' (extras not counted)' if extras else ''}.")
    print(f"\nThank you,\n{a.sender}")
    if waiting: print(f"\n[not in the email] still to order: {', '.join(waiting)}", file=sys.stderr)

def cmd_unblock(a):
    names = ls(f'lunch/{a.slug}/throttle'); rm([f'lunch/{a.slug}/throttle/{n}' for n in names]); print('cleared', len(names), 'lockout records')

def cmd_check(a):
    c = config(a.slug); url = f'https://{HOST}/{a.slug}'; ok = True
    def t(name, cond):
        nonlocal ok; ok = ok and cond; print(('PASS  ' if cond else 'FAIL  ') + name)
    try:
        r = urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'lunch-check'})); page = r.read().decode(); h = {k.lower(): v for k, v in r.headers.items()}
    except urllib.error.HTTPError as e: sys.exit(f'{url} answered {e.code}')
    t('the gate answers', 'Access Code' in page)
    t('no guest names before the code', not any(re.search(r'\b' + re.escape(x['name']) + r'\b', page) for x in c['roster']))
    t('no menu items before the code', not any(i['name'] in page for i in items_of(c)))
    t('nonce-only content policy, no third parties', "script-src 'nonce-" in h.get('content-security-policy', '') and 'unsafe-inline' not in h.get('content-security-policy', '') and not re.search(r'https?://', page))
    t('never cached', 'no-store' in h.get('cache-control', ''))
    def post(body, origin=f'https://{HOST}'):
        try: urllib.request.urlopen(urllib.request.Request(url, data=json.dumps(body).encode(), method='POST', headers={'Content-Type': 'application/json', 'X-Requested-With': 'lunch', 'Origin': origin, 'User-Agent': 'lunch-check'})); return 200
        except urllib.error.HTTPError as e: return e.code
    t('an order without a session is refused', post({'action': 'order', 'items': []}) == 401)
    t('a POST from another site is refused', post({'action': 'order', 'items': []}, 'https://example.org') == 403)
    try: urllib.request.urlopen(f'https://{HOST}/'); root = 200
    except urllib.error.HTTPError as e: root = e.code
    t('nothing else answers on the host', root == 404)
    rm([f'lunch/{a.slug}/events/{n}' for n in ls(f'lunch/{a.slug}/events') if '_post-blocked_' in n and n[:13] == iso(datetime.datetime.now(CHI))[:13].replace(':', '-')])
    print(f"{'all good' if ok else 'something is off'} · {url} · code {c['code']}"); sys.exit(0 if ok else 1)

def cmd_scuttle(a):
    c = get(f'lunch/{a.slug}/config.json'); paths = []; n_orders = 0
    for d in ('orders', 'events', 'throttle'):
        names = ls(f'lunch/{a.slug}/{d}'); n_orders = len(names) if d == 'orders' else n_orders
        paths += [f'lunch/{a.slug}/{d}/{n}' for n in names]
    if c: paths.append(f'lunch/{a.slug}/config.json')
    if c and c.get('objective_id'): paths += [f"objectives/{c['objective_id']}/build/lunch-{a.slug}.{x}" for x in ('html', 'json')]
    if not paths: sys.exit(f'nothing to scuttle for "{a.slug}"')
    rm(paths); now = datetime.datetime.now(datetime.timezone.utc)
    put(f"lunch/_scuttled/{a.slug}-{now.strftime('%Y-%m-%d-%H-%M-%S')}.json", {'slug': a.slug, 'title': (c or {}).get('title'), 'lunch_at': (c or {}).get('lunch_at'), 'objective_id': (c or {}).get('objective_id'), 'guests': len((c or {}).get('roster', [])), 'orders': n_orders, 'scuttled_at': iso(now), 'reason': a.reason})
    print(f'scuttled {a.slug}: {len(paths)} objects removed, {n_orders} orders; the address now answers Not Found')

p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter); sub = p.add_subparsers(dest='cmd', required=True)
s = sub.add_parser('new'); s.add_argument('slug'); s.add_argument('--title', required=True); s.add_argument('--lunch-at', required=True); s.add_argument('--guests'); s.add_argument('--menu'); s.add_argument('--objective-id'); s.add_argument('--place'); s.add_argument('--closes-at'); s.add_argument('--code'); s.add_argument('--max-items', type=int, default=0); s.add_argument('--replace', action='store_true'); s.set_defaults(f=cmd_new)
s = sub.add_parser('list'); s.set_defaults(f=cmd_list)
for name, f in (('show', cmd_show), ('status', cmd_status), ('unblock', cmd_unblock), ('check', cmd_check)):
    s = sub.add_parser(name); s.add_argument('slug'); s.set_defaults(f=f)
s = sub.add_parser('rebuild'); s.add_argument('slug'); s.set_defaults(f=lambda a: rebuild(a.slug))
s = sub.add_parser('menu'); s.add_argument('slug'); s.add_argument('file'); s.set_defaults(f=cmd_menu)
s = sub.add_parser('guests'); s.add_argument('slug'); s.add_argument('--add'); s.add_argument('--remove'); s.set_defaults(f=cmd_guests)
s = sub.add_parser('record'); s.add_argument('slug'); s.add_argument('--guest', required=True); s.add_argument('--items', required=True); s.add_argument('--option', action='append'); s.add_argument('--note'); s.add_argument('--replace', action='store_true'); s.set_defaults(f=cmd_record)
s = sub.add_parser('final'); s.add_argument('slug'); s.add_argument('--extra', action='append'); s.add_argument('--to', default='Erica'); s.add_argument('--from', dest='sender', default='David'); s.set_defaults(f=cmd_final)
s = sub.add_parser('scuttle'); s.add_argument('slug'); s.add_argument('--reason', default="on David's word"); s.set_defaults(f=cmd_scuttle)
a = p.parse_args(); a.f(a)
