// Rebuild one event's order sheet (the built page on its mission's Workbench) with the door's own code.
// Usage: node rebuild.mjs <slug>   (needs the sa-hud clone at ~/builds/sa-hud)
import fs from 'node:fs'
const env = Object.fromEntries(fs.readFileSync(process.env.HOME + '/.claude/hud-board/.env', 'utf8').split('\n').filter(l => l.includes('=') && !l.startsWith('#')).map(l => { const i = l.indexOf('='); return [l.slice(0, i).trim(), l.slice(i + 1).trim()] }))
process.env.SUPABASE_SERVICE_KEY = env.SUPABASE_SERVICE_KEY
const { rebuildBoard } = await import(process.env.HOME + '/builds/sa-hud/api/lunch.mjs')
const slug = process.argv[2]
const res = await fetch(`${env.SUPABASE_URL}/storage/v1/object/project-files/lunch/${slug}/config.json?cb=${Date.now()}`, { headers: { apikey: env.SUPABASE_SERVICE_KEY, Authorization: `Bearer ${env.SUPABASE_SERVICE_KEY}` } })
if (!res.ok) { console.log(`no event "${slug}"`); process.exit(1) }
const config = await res.json()
if (!config.objective_id) { console.log('no mission on this event, so no order sheet'); process.exit(0) }
await rebuildBoard(config)
console.log('order sheet rebuilt on the mission Workbench')
