// The lunch door's regression test. Makes its own throwaway event in storage, drives the door's
// handler through every gate and order rule, proves the 24-hour scuttle, and leaves nothing behind.
// Usage: node smoke.mjs   (needs the sa-hud clone at ~/builds/sa-hud; run after any change to api/lunch.mjs)
import fs from 'node:fs'
import crypto from 'node:crypto'
const env = Object.fromEntries(fs.readFileSync(process.env.HOME + '/.claude/hud-board/.env', 'utf8').split('\n').filter(l => l.includes('=') && !l.startsWith('#')).map(l => { const i = l.indexOf('='); return [l.slice(0, i).trim(), l.slice(i + 1).trim()] }))
process.env.SUPABASE_SERVICE_KEY = env.SUPABASE_SERVICE_KEY
const { default: handler, scuttle, sweep } = await import(process.env.HOME + '/builds/sa-hud/api/lunch.mjs')
const H = { apikey: env.SUPABASE_SERVICE_KEY, Authorization: `Bearer ${env.SUPABASE_SERVICE_KEY}`, 'Content-Type': 'application/json' }
const store = (path, doc) => fetch(`${env.SUPABASE_URL}/storage/v1/object/project-files/${path}`, { method: 'POST', headers: { ...H, 'x-upsert': 'true' }, body: JSON.stringify(doc) })
const exists = async (path) => (await fetch(`${env.SUPABASE_URL}/storage/v1/object/project-files/${path}?cb=${Date.now()}`, { headers: H })).ok
const listing = async (prefix) => ((await (await fetch(`${env.SUPABASE_URL}/storage/v1/object/list/project-files`, { method: 'POST', headers: H, body: JSON.stringify({ prefix, limit: 1000 }) })).json()) || []).filter(f => f.id).map(f => f.name)
const drop = (paths) => fetch(`${env.SUPABASE_URL}/storage/v1/object/project-files`, { method: 'DELETE', headers: H, body: JSON.stringify({ prefixes: paths }) })

const slug = 'smoke-' + crypto.randomBytes(3).toString('hex')
const cfg = { slug, active: true, title: 'Smoke Lunch', place: 'Test Kitchen', when: 'Smoke Test', lunch_at: new Date().toISOString(), closes_at: null, expires_at: new Date(Date.now() + 86400e3).toISOString(),
  code: 'smoke-' + crypto.randomBytes(3).toString('hex'), salt: crypto.randomBytes(16).toString('hex'), objective_id: null, roster: [{ id: 'guest-one', name: 'Guest One' }, { id: 'guest-two', name: 'Guest Two' }], rules: { max_items: 0 },
  menu: { title: 'Sample Menu', foot: ['*A footnote'], sections: [
    { title: 'Sandwiches', note: 'Served With Chips', items: [
      { id: 's1', name: 'Sample Sandwich A', desc: 'Turkey, swiss, lettuce & tomato', price: '12', options: [{ label: 'Bread', choices: ['Sourdough', 'Wheat'], required: true }, { label: 'Side', choices: ['Chips', 'Fruit'], required: false }] },
      { divider: true },
      { id: 's2', name: 'Sample Sandwich B', desc: 'Roasted vegetables <b>with</b> pesto', price: '11' }] },
    { title: 'Drinks', items: [{ id: 'd1', name: 'Iced Tea', price: '3' }] }] } }
await store(`lunch/${slug}/config.json`, cfg)

let jar = ''
async function call(method, body, { headers = {}, cookie = jar, ip = '203.0.113.7', s = slug, at } = {}) {
  const res = { code: 200, h: {}, body: '', status(c) { this.code = c; return this }, setHeader(k, v) { this.h[k.toLowerCase()] = v }, send(b) { this.body = String(b); return this } }
  await handler({ method, query: { slug: s, ...(at ? { at } : {}) }, headers: { 'x-forwarded-for': ip, ...(cookie ? { cookie } : {}), ...(method === 'POST' ? { 'content-type': 'application/json', 'x-requested-with': 'lunch', origin: 'https://lunch.thirdhorizon.com' } : {}), ...headers }, body }, res)
  const sc = res.h['set-cookie']; if (sc && cookie === jar) jar = sc.split(';')[0]
  return res
}
let failed = 0
const ok = (name, cond, extra = '') => { console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond || !extra ? '' : '  ' + extra}`); if (!cond) failed++ }
try {
  let r = await call('GET')
  ok('gate page served before the code', r.code === 200 && r.body.includes('Access Code'))
  ok('gate leaks no guest names or menu', !r.body.includes('Guest One') && !r.body.includes('Sample Sandwich'))
  ok('nonce policy, no unsafe-inline, no third parties', /script-src 'nonce-/.test(r.h['content-security-policy']) && !/unsafe-inline|https?:/.test(r.h['content-security-policy']))
  ok('no inline style attributes, no external URLs', !/ style="/.test(r.body) && !/https?:\/\//.test(r.body))
  ok('no security copy on the page', !/security|posture|hmac/i.test(r.body))
  ok('no-store, nosniff, frame deny, HSTS', /no-store/.test(r.h['cache-control']) && r.h['x-content-type-options'] === 'nosniff' && r.h['x-frame-options'] === 'DENY' && /max-age/.test(r.h['strict-transport-security']))
  r = await call('POST', { action: 'order', items: [{ id: 's2' }] }); ok('order refused without a session', r.code === 401)
  r = await call('POST', { action: 'unlock', code: 'wrong' }); ok('wrong code refused', r.code === 401 && !r.h['set-cookie'])
  r = await call('POST', { action: 'unlock', code: cfg.code }, { headers: { 'x-requested-with': '' } }); ok('POST without the custom header refused', r.code === 403)
  r = await call('POST', { action: 'unlock', code: cfg.code }, { headers: { origin: 'https://evil.example' } }); ok('POST from another origin refused', r.code === 403)
  r = await call('POST', { action: 'unlock', code: 'nope' }, { headers: { origin: 'null' }, ip: '203.0.113.200' }); ok('Origin null reaches the code check', r.code === 401)
  r = await call('POST', { action: 'unlock', code: ' ' + cfg.code.toUpperCase().replace('-', ' ') + ' ' }, { at: `/${slug}` })
  ok('code with spaces and capitals opens; cookie scoped to the root address', r.code === 200 && /HttpOnly; Secure; SameSite=Lax/.test(r.h['set-cookie']) && r.h['set-cookie'].includes(`Path=/${slug};`))
  r = await call('POST', { action: 'unlock', code: cfg.code }, { cookie: '', ip: '203.0.113.9', at: '/somewhere-else' }); ok('a cookie path the proxy did not name is not honored', r.h['set-cookie'].includes(`Path=/lunch/${slug};`))
  r = await call('GET'); ok('name page after the code', r.body.includes('Who Is Ordering?') && r.body.includes('Guest One') && !r.body.includes('Sample Sandwich'))
  r = await call('POST', { action: 'identify', person: 'nobody' }); ok('unknown name refused', r.code === 400)
  r = await call('POST', { action: 'identify', person: 'guest-one' }); ok('name picked', r.code === 200)
  r = await call('GET'); ok('menu page: verbatim, escaped, section note, rule, footnote', r.body.includes('Sample Sandwich A') && r.body.includes('lettuce &amp; tomato') && r.body.includes('&lt;b&gt;with&lt;/b&gt;') && r.body.includes('Served With Chips') && r.body.includes('class="rule"') && r.body.includes('*A footnote'))
  r = await call('POST', { action: 'order', items: [{ id: 'not-on-menu' }] }); ok('item not on the menu refused', r.code === 400)
  r = await call('POST', { action: 'order', items: [{ id: 's1', options: {} }] }); ok('missing required option refused', r.code === 400)
  r = await call('POST', { action: 'order', items: [{ id: 's1', options: { Bread: 'Rye' } }] }); ok('option not offered refused', r.code === 400)
  r = await call('POST', { action: 'order', items: [{ id: 's1', options: { Bread: 'Wheat', Side: 'Fruit' } }, { id: 'd1' }], notes: 'No onions <script>alert(1)</script>' }); ok('valid order saved', r.code === 200, r.body)
  r = await call('GET'); ok('confirmation shows the order, note escaped', r.body.includes('Order In. Thanks, Guest.') && r.body.includes('Bread: Wheat') && r.body.includes('&lt;script&gt;') && !r.body.includes('<script>alert'))
  r = await call('GET', null, { cookie: jar.replace(/\.[^.]+$/, '.AAAA') }); ok('forged cookie lands on the gate', r.body.includes('Access Code'))
  for (let i = 0; i < 5; i++) await call('POST', { action: 'unlock', code: 'nope' + i }, { cookie: '', ip: '198.51.100.99' })
  r = await call('POST', { action: 'unlock', code: cfg.code }, { cookie: '', ip: '198.51.100.99' }); ok('sixth try from one address is locked out, even with the right code', r.code === 429)
  r = await call('GET', null, { s: 'no-such-event', cookie: '' }); ok('unknown event is a 404', r.code === 404)
  r = await call('PUT', {}); ok('other methods refused', r.code === 405)
  // the scuttle: once the lunch is 24 hours gone, the first visit or the sweep deletes everything
  await store(`lunch/${slug}/config.json`, { ...cfg, expires_at: new Date(Date.now() - 1000).toISOString() })
  const swept = await sweep()
  ok('the sweep scuttles an expired event', swept.some(x => x.slug === slug) && !(await exists(`lunch/${slug}/config.json`)) && (await listing(`lunch/${slug}/orders`)).length === 0 && (await listing(`lunch/${slug}/events`)).length === 0)
  r = await call('GET', null, { cookie: '' }); ok('a scuttled event answers Not Found', r.code === 404)
  const stones = (await listing('lunch/_scuttled')).filter(n => n.startsWith(slug))
  ok('a tombstone with no names stays', stones.length === 1)
  await drop(stones.map(n => `lunch/_scuttled/${n}`))
} finally {
  if (await exists(`lunch/${slug}/config.json`)) { await scuttle(slug, 'smoke test cleanup'); await drop((await listing('lunch/_scuttled')).filter(n => n.startsWith(slug)).map(n => `lunch/_scuttled/${n}`)) }
}
console.log(failed ? `${failed} FAILED` : 'all passed, nothing left behind')
process.exit(failed ? 1 : 0)
