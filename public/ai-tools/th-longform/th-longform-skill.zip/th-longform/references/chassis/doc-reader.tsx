"use client";

// The document reader (10/25): the long-form layout beside the deck. The bar
// and the standing contents rail are the deck's own (same classes from
// exec-slides.module.css); the right side is a scrolling page of blocks with a
// Next at the very foot. ?s= addresses the page, 1-based, as the deck's does,
// so the unlock redirect and deep links behave the same way.

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import type { CapitalTarget, CardUpdate, DirectoryPerson, DocBlock, DocCapital, DocCard, DocCards, DocChart, DocLine, DocPage, DocPlan, DocRow, DocTable, LinePoint, LineRock, PlanBig, PlanPerson, PlanTruth } from "@/content/doc";
import { US_BORDERS, US_CITIES, US_NATION, US_VIEWBOX } from "@/content/us-map";
import s from "./shell.module.css";
import d from "./doc.module.css";

// ---------------------------------------------------------------------------
// Edit Text (11/1): David writes straight into a prose box on the dev server, fast and
// loose, bold and italic and emoji kept; each box autosaves to .edits/<doc>/page-NN.json
// through /api/edits, and a Format button on the box flags it for Claude to format and
// clean. Production never sees the pill or the route. Modeled on the AMA deck's 10/22
// inline pass, one box at a time instead of one slide.
// ---------------------------------------------------------------------------
const CAN_EDIT = process.env.NODE_ENV !== "production";
type Draft = { label: string; html: string; text: string; savedAt: string; format: boolean; formatAt?: string };
type EditCtxT = { editing: boolean; doc: string; page: number; slug: string; drafts: Record<string, Draft>; bump: () => void };
const EditCtx = React.createContext<EditCtxT>({ editing: false, doc: "", page: 0, slug: "", drafts: {}, bump: () => {} });
const KEEP_TAGS = new Set(["B", "STRONG", "I", "EM", "BR", "P", "UL", "OL", "LI", "U"]);
/** Keep the writing marks and the paragraphs; drop everything else (classes, spans, styles). */
function cleanHtml(root: HTMLElement): string {
  const walk = (node: Node): string => {
    if (node.nodeType === Node.TEXT_NODE) return (node.textContent ?? "").replace(/[<>]/g, (c) => (c === "<" ? "&lt;" : "&gt;"));
    if (node.nodeType !== Node.ELEMENT_NODE) return "";
    const el = node as HTMLElement;
    const inner = Array.from(el.childNodes).map(walk).join("");
    if (!KEEP_TAGS.has(el.tagName)) return el.tagName === "DIV" ? inner + "\n" : inner;
    const tag = el.tagName === "B" ? "strong" : el.tagName === "I" ? "em" : el.tagName.toLowerCase();
    return tag === "br" ? "<br>" : `<${tag}>${inner}</${tag}>`;
  };
  return Array.from(root.childNodes).map(walk).join("").trim();
}
function Ed({ id, label, children, block = true, draftClass }: { id: string; label: string; children: React.ReactNode; block?: boolean; /** the box's own classes, so a draft reads in the box's type */ draftClass?: string }) {
  const ctx = React.useContext(EditCtx);
  const ref = useRef<HTMLDivElement | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const wasLorem = useRef(false);
  const draft = ctx.drafts[id];
  const [state, setState] = useState<"idle" | "saving" | "saved" | "format">(draft?.format ? "format" : draft ? "saved" : "idle");
  const [flash, setFlash] = useState(false);
  useEffect(() => { setState(draft?.format ? "format" : draft ? "saved" : "idle"); }, [draft?.format, draft?.savedAt, draft]);
  const save = useCallback((format = false) => {
    const el = ref.current;
    if (!el) return;
    if (timer.current) clearTimeout(timer.current);
    setState("saving");
    void fetch("/api/edits", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ doc: ctx.doc, page: ctx.page, slug: ctx.slug, id, label, html: cleanHtml(el), text: el.innerText, format }),
    }).then((r) => r.json()).then((j) => { setState(j.format ? "format" : "saved"); if (format) { setFlash(true); setTimeout(() => setFlash(false), 1800); ctx.bump(); } }).catch(() => setState("idle"));
  }, [ctx, id, label]);
  const onInput = useCallback(() => {
    const el = ref.current;
    // the first keystroke over a lorem box leaves plain text, not the lorem's bold
    if (el && wasLorem.current) {
      wasLorem.current = false;
      const text = el.innerText;
      el.innerHTML = "";
      const para = document.createElement("p"); para.textContent = text; el.appendChild(para);
      const sel = window.getSelection(); const range = document.createRange();
      range.selectNodeContents(para); range.collapse(false); sel?.removeAllRanges(); sel?.addRange(range);
    }
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => save(false), 700);
  }, [save]);
  const onFocus = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    // placeholder prose: the first keystroke replaces the lorem
    if (/^\s*lorem ipsum/i.test(el.innerText)) {
      wasLorem.current = true;
      const sel = window.getSelection(); const range = document.createRange();
      range.selectNodeContents(el); sel?.removeAllRanges(); sel?.addRange(range);
    }
  }, []);
  // A saved draft shows in place of the source text, editing or not, with its badge, until Claude folds it.
  const body = draft ? <div className={draftClass ?? d.edDraft} dangerouslySetInnerHTML={{ __html: draft.html }} /> : children;
  // While editing, the box is seeded once and left to the caret: a re-render from the saved copy would jump it to the start.
  const seeded = useRef<React.ReactNode>(null);
  if (ctx.editing && seeded.current === null) seeded.current = body;
  if (!ctx.editing) seeded.current = null;
  if (!ctx.editing) {
    if (!draft) return <>{children}</>;
    return (
      <div className={d.edWrap} data-eid={id}>
        <div className={d.edField} style={{ outlineStyle: "none" }}>{body}</div>
        <div className={d.edTools} style={{ opacity: 1 }}>
          <span className={`${d.edState}${draft.format ? ` ${d.edStateFormat}` : ""}`}>{draft.format ? "Draft · Format requested" : "Draft · Unfolded"}</span>
        </div>
      </div>
    );
  }
  return (
    <div className={`${d.edWrap}${block ? "" : ` ${d.edInline}`}${flash ? ` ${d.edFlash}` : ""}`} data-eid={id}>
      <div ref={ref} className={d.edField} contentEditable suppressContentEditableWarning spellCheck={false} onInput={onInput} onBlur={() => save(false)} onFocus={onFocus}>
        {seeded.current}
      </div>
      <div className={d.edTools}>
        <span className={d.edLabel}>{label}</span>
        <span className={`${d.edState}${state === "format" ? ` ${d.edStateFormat}` : ""}`}>{state === "saving" ? "Saving" : state === "saved" ? "Saved · Draft" : state === "format" ? "Format requested · Claude will see it" : ""}</span>
        <button type="button" className={`${d.edFormat}${state === "format" ? ` ${d.edFormatOn}` : ""}`} onMouseDown={(e) => e.preventDefault()} onClick={() => save(true)} title="Save this box and ask Claude to format and clean it">{state === "format" ? "Requested ✦" : "Format ✦"}</button>
      </div>
    </div>
  );
}

const LEGAL = "Not for Distribution · Confidential & Proprietary Information · Third Horizon";

function em(text: string) {
  const parts = text.split(/\*([^*]+)\*/g);
  if (parts.length === 1) return text;
  return parts.map((chunk, n) => (n % 2 === 1 ? <em key={n}>{chunk}</em> : chunk));
}

// Table and chart cells read in whole dollars; the notes carry the cents.
const money = (x: number) => {
  const r = Math.round(x);
  return r < 0 ? `(${Math.abs(r).toLocaleString("en-US")})` : r.toLocaleString("en-US");
};
const k = (x: number) => `$${Math.round(x / 1000).toLocaleString("en-US")}K`;

export function DocReader({ pages, closeHref, basePath, label }: { pages: DocPage[]; closeHref: string; basePath: string; label: string }) {
  const router = useRouter();
  const params = useSearchParams();
  const raw = Number(params.get("s") ?? 1);
  const i = Number.isFinite(raw) ? Math.min(Math.max(Math.round(raw), 1), pages.length) - 1 : 0;
  const page = pages[i];
  const mainRef = useRef<HTMLElement | null>(null);

  // The page switch (assumptions on or off): on every page open it returns to the page's default, off unless the page says otherwise.
  const defaultOn = !!page.toggle?.defaultOn;
  const [switchOn, setSwitchOn] = useState(defaultOn);
  useEffect(() => { setSwitchOn(defaultOn); }, [i, defaultOn]);
  const blocks = page.toggle && switchOn ? page.toggle.blocksOn : page.blocks;

  const go = useCallback(
    (next: number) => {
      const clamped = Math.min(Math.max(next, 0), pages.length - 1);
      router.replace(`${basePath}?s=${clamped + 1}`, { scroll: false });
    },
    [router, pages.length, basePath],
  );

  // A new page opens at its top, on the desktop column and on a phone's window alike.
  useEffect(() => {
    mainRef.current?.scrollTo({ top: 0 });
    window.scrollTo(0, 0);
  }, [i]);

  const [editing, setEditing] = useState(false);
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [draftTick, setDraftTick] = useState(0);
  const docKey = basePath.replace(/\//g, "") || "doc";
  useEffect(() => {
    if (!CAN_EDIT) return;
    let live = true;
    fetch(`/api/edits?doc=${encodeURIComponent(docKey)}&page=${i + 1}`).then((r) => r.json()).then((j) => { if (live) setDrafts(j.blocks ?? {}); }).catch(() => {});
    return () => { live = false; };
  }, [docKey, i, draftTick]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.isContentEditable || t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT")) return;
      if (e.key === "ArrowRight") go(i + 1);
      else if (e.key === "ArrowLeft") go(i - 1);
      else if (e.key === "Escape") router.push(closeHref);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [i, go, router, closeHref]);

  // Rail, dropdown and the foot buttons read the title plain; the italic marks belong to the page head alone.
  const pageName = (p: DocPage) => (p.cover ? p.cover.heading : p.title.replace(/\*/g, ""));

  return (
    <div className={d.wrap}>
      <header className={`${s.bar} ${d.bar}`}>
        <div className={s.brand}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/brand/th-arches-white.png" alt="" className={s.arches} />
          <span className={s.mark}>Third Horizon</span>
          <span className={s.label}>{label}</span>
        </div>
        <div className={s.barActions}>
          <Link href={closeHref} className={s.close}>Close</Link>
        </div>
      </header>

      <div className={s.mobileNav}>
        <label htmlFor="document-page">Contents</label>
        <select id="document-page" value={i} onChange={(event) => go(Number(event.target.value))}>
          {pages.map((p, n) => (
            <option key={p.slug} value={n}>{p.ref ? `${p.ref}. ` : ""}{pageName(p)}</option>
          ))}
        </select>
      </div>

      <aside className={`${s.rail} ${s.railSpine} ${d.rail}`} aria-label="Contents">
        <div className={s.railTitle}>Contents</div>
        {pages.map((p, n) => (
          <div key={p.slug} className={`${s.railAct} ${s.railActLeaf}${n === i ? ` ${s.railActOn}` : n < i ? ` ${s.railActSeen}` : ""}`}>
            <button type="button" className={`${s.railHead}${n === i ? ` ${s.railCurrent}` : ""}`} onClick={() => go(n)}>
              <span className={s.railNo}>{p.ref}</span>
              <span className={s.railName}>{pageName(p)}</span>
            </button>
          </div>
        ))}
        <div className={s.railFoot}>
          <span className={s.railPos}>{i + 1} of {pages.length}</span>
          <span className={s.railBar} aria-hidden="true"><i style={{ width: `${((i + 1) / pages.length) * 100}%` }} /></span>
          <span className={s.railLegal}>{LEGAL}</span>
        </div>
      </aside>

      <main className={d.main} ref={mainRef} key={page.slug}>
        {CAN_EDIT && (
          <div className={d.edBar}>
            <button type="button" className={`${d.edPill}${editing ? ` ${d.edPillOn}` : ""}`} aria-pressed={editing} onClick={() => setEditing((v) => !v)}>
              {editing ? "Editing · Autosaves" : "Edit Text"}
            </button>
            {editing && <span className={d.edHint}>Write in any box. Bold, italic and emoji stay. Format ✦ asks Claude to clean that box.</span>}
            {Object.keys(drafts).length > 0 && <span className={d.edCount}>{Object.values(drafts).filter((x) => x.format).length} flagged · {Object.keys(drafts).length} draft{Object.keys(drafts).length === 1 ? "" : "s"} on this page</span>}
          </div>
        )}
        <EditCtx.Provider value={{ editing: CAN_EDIT && editing, doc: docKey, page: i + 1, slug: page.slug, drafts, bump: () => setDraftTick((t) => t + 1) }}>
        {page.toggle && (
          <div className={d.switchBar} role="group" aria-label={page.toggle.label}>
            <span className={d.switchLabel}>{page.toggle.label}</span>
            <button type="button" className={`${d.switchBtn}${switchOn ? ` ${d.switchOn}` : ""}`} aria-pressed={switchOn} onClick={() => setSwitchOn((v) => !v)}>
              <span className={d.switchKnob} aria-hidden="true" />
              <span>{switchOn ? "On" : "Off"}</span>
            </button>
            <span className={d.switchNote}>{switchOn ? page.toggle.onNote : page.toggle.offNote}</span>
          </div>
        )}
        <article className={`${d.page}${page.cover ? ` ${d.pageCover}` : ""}`}>
          {page.cover ? (
            <div className={d.cover}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/brand/th-arches-white.png" alt="" className={d.coverArches} />
              <div className={d.coverMark}>Third Horizon</div>
              {page.kicker && <div className={d.coverKicker}>{page.kicker}</div>}
              <h1 className={d.coverHeading}>{page.cover.heading}</h1>
              {page.cover.sub && <p className={d.coverSub}>{em(page.cover.sub)}</p>}
              <span className={d.coverRule} aria-hidden="true" />
              <div className={d.coverNote}>{page.cover.note}</div>
              <div className={d.coverDate}>{page.cover.date}</div>
            </div>
          ) : (
            <>
              {page.kicker && <div className={d.kicker}>{page.kicker}</div>}
              <h1 className={d.title}>{em(page.title)}</h1>
            </>
          )}

          {blocks.map((block, n) => (
            <Block key={`${switchOn ? "on" : "off"}-${n}`} block={block} pages={pages} go={go} eid={`${page.slug}:${n}`} />
          ))}

          <nav className={d.pageNav} aria-label="Pages">
            {i > 0 && !page.cover && (
              <button type="button" className={d.prev} onClick={() => go(i - 1)}>
                <span className={d.tri}><svg width="12" height="14" viewBox="0 0 29.4 34" aria-hidden="true"><polygon points="29.4,0 29.4,34 0,17" /></svg></span>
                <span><span className={d.navK}>Previous</span><br /><span className={d.navT}>{pageName(pages[i - 1])}</span></span>
              </button>
            )}
            {i < pages.length - 1 ? (
              <button type="button" className={d.next} onClick={() => go(i + 1)}>
                <span><span className={d.navK}>{page.cover ? "Begin" : "Next"}{pages[i + 1].ref ? ` · ${pages[i + 1].ref}` : ""}</span><br /><span className={d.navT}>{pageName(pages[i + 1])}</span></span>
                <span className={d.tri}><svg width="12" height="14" viewBox="0 0 29.4 34" aria-hidden="true"><polygon points="0,0 0,34 29.4,17" /></svg></span>
              </button>
            ) : (
              <span className={d.end}>End of the document, for now</span>
            )}
          </nav>
          <div className={d.foot}>
            <span>{LEGAL}</span>
            <span>{label} · {page.ref ? `Page ${page.ref}` : "Cover"}</span>
          </div>
        </article>
        </EditCtx.Provider>
      </main>
    </div>
  );
}

function Block({ block, pages, go, eid }: { block: DocBlock; pages: DocPage[]; go: (n: number) => void; eid: string }) {
  switch (block.kind) {
    case "lead":
      return (
        <Ed id={eid} label="Lead" draftClass={`${s.para} ${s.paraFirst} ${d.lead} ${d.edDraftLead}`}>
          <p className={`${s.para} ${s.paraFirst} ${d.lead}`}>
            <strong className={s.paraBold}>{block.bold}</strong> {em(block.text)}
          </p>
        </Ed>
      );
    case "para":
      return <Ed id={eid} label="Paragraph" draftClass={`${s.para} ${d.para} ${d.edDraftPara}`}><p className={`${s.para} ${d.para}`}>{em(block.text)}</p></Ed>;
    case "h2":
      return <Ed id={eid} label="Heading" draftClass={d.h2}><h2 className={d.h2}>{em(block.text)}</h2></Ed>;
    case "list":
      return (
        <Ed id={eid} label="List">
          <ul className={d.list}>
            {block.items.map((it, n) => <li key={n}>{em(it)}</li>)}
          </ul>
        </Ed>
      );
    case "callout":
      return (
        <Ed id={eid} label="Callout">
          <aside className={d.callout}>
            {block.eyebrow && <div className={d.calloutEyebrow}>{block.eyebrow}</div>}
            <p className={d.calloutText}>{em(block.text)}</p>
          </aside>
        </Ed>
      );
    case "stats":
      return (
        <div className={d.stats}>
          {block.items.map((st) => (
            <div key={st.k} className={`${d.stat}${st.tone === "pos" ? ` ${d.statPos}` : st.tone === "neg" ? ` ${d.statNeg}` : ""}`}>
              <div className={d.statK}>{st.k}</div>
              <div className={d.statV}>{st.v}</div>
              {st.sub && <div className={d.statSub}>{st.sub}</div>}
            </div>
          ))}
        </div>
      );
    case "table":
      return <Table block={block} />;
    case "chart":
      return <Chart block={block} />;
    case "plan":
      return <Plan block={block} />;
    case "line":
      return <LinePlan block={block} />;
    case "capital":
      return <Capital block={block} />;
    case "cards":
      return <Cards block={block} />;
    case "source":
      return <p className={d.source}>{block.text}</p>;
    case "document":
      return (
        <a className={d.docCard} href={block.href} target="_blank" rel="noopener noreferrer">
          <span className={d.docIcon} aria-hidden="true" />
          <span>
            <div className={d.docTitle}>{block.title}</div>
            {block.sub && <div className={d.docSub}>{block.sub}</div>}
            {block.note && <div className={d.docNote}>{block.note}</div>}
          </span>
          <svg className={d.docArrow} viewBox="0 0 12 12" width="12" height="12" aria-hidden="true"><path d="M3 1h8v8M11 1 1 11" fill="none" stroke="currentColor" strokeWidth="1.6" /></svg>
        </a>
      );
    case "contents":
      return (
        <div className={d.toc}>
          <div className={d.tocTitle}>Contents</div>
          {pages.map((p, n) => p.cover ? null : (
            <button key={p.slug} type="button" className={d.tocItem} onClick={() => go(n)}>
              <span>{p.title.replace(/\*/g, "")}</span>
              <span className={d.tocRef}>{p.ref}</span>
            </button>
          ))}
        </div>
      );
    default:
      return null;
  }
}

/* ---- the table: rows expand to their lines, totals open their reading; the Project Code
   in its own column; the whole table opens full screen behind the two-arrow button ---- */
const hasCode = (rows: DocRow[]): boolean => rows.some((r) => !!r.sub || (r.children ? hasCode(r.children) : false));

function Table({ block }: { block: DocTable }) {
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [note, setNote] = useState<Record<string, boolean>>({});
  const [full, setFull] = useState(false);
  const codeCol = useMemo(() => hasCode(block.rows), [block.rows]);
  const cols = block.columns.length + (block.totalLabel ? 1 : 0) + 1 + (codeCol ? 1 : 0);
  useEffect(() => {
    if (!full) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") { e.stopPropagation(); setFull(false); } };
    window.addEventListener("keydown", onKey, true);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey, true); document.body.style.overflow = prev; };
  }, [full]);
  const cell = (v: number | null | undefined, tot = false) => (
    <td className={`${(v ?? 0) < 0 ? d.neg : ""}${tot ? ` ${d.tot}` : ""}`}>{v == null ? "" : money(v)}</td>
  );
  // The row key carries the row's place among its siblings: a sheet can repeat a label (two "MMA (Schedule E)" lines).
  const renderRow = (r: DocRow, depth = 0, index = 0): React.ReactNode => {
    const key = `${depth}:${index}:` + r.label + (r.sub ?? "");
    const canOpen = !!(r.children && r.children.length);
    const canAsk = !!r.note;
    const cls = r.style === "assume" ? `${depth > 0 ? d.child : ""} ${d.assume}` : depth > 0 ? d.child : r.style ? d[r.style] : "";
    // an assumption line carries a purple dot before its name instead of a chip (David 11/3); the legend under the caption reads it
    const dot = r.style === "assume" ? <span className={d.dot} style={{ background: "#B48CF2" }} aria-label={r.flag ?? "Assumption"} /> : null;
    const codeText = r.sub ?? "";
    const codeMuted = !r.sub || /^no project/i.test(r.sub) || /^(the lump|this account)$/i.test(r.sub);
    return (
      <>
        <tr key={key} className={cls}>
          <td style={depth > 0 ? { paddingLeft: 24 + depth * 22 } : undefined}>
            {canOpen || canAsk ? (
              <button
                type="button"
                className={d.rowBtn}
                aria-expanded={canOpen ? !!open[key] : undefined}
                onClick={() => (canOpen ? setOpen((o) => ({ ...o, [key]: !o[key] })) : setNote((o) => ({ ...o, [key]: !o[key] })))}
              >
                {canOpen && <span className={`${d.chev}${open[key] ? ` ${d.chevOpen}` : ""}`} aria-hidden="true" />}
                <span>{dot}{r.label}{r.flag && !dot && <span className={d.flag}>{r.flag}</span>}</span>
                {!canOpen && canAsk && <span className={`${d.ask}${note[key] ? ` ${d.askOn}` : ""}`} aria-hidden="true">i</span>}
              </button>
            ) : (
              <span>{dot}{r.label}{r.flag && !dot && <span className={d.flag}>{r.flag}</span>}</span>
            )}
          </td>
          {codeCol && <td className={`${d.code}${codeMuted ? ` ${d.codeMuted}` : ""}`}>{codeText}</td>}
          {r.cells.map((v, n) => <CellFrag key={n} v={v} />)}
          {block.totalLabel ? cell(r.total, true) : null}
        </tr>
        {canOpen && open[key] && r.children!.map((c, n) => <CellRow key={`${depth + 1}:${n}:` + c.label + (c.sub ?? "")} row={c} depth={depth + 1} index={n} render={renderRow} />)}
        {canAsk && note[key] && (
          <tr key={key + ":note"} className={d.noteRow}><td colSpan={cols}><div className={d.noteInner}>{em(r.note!)}</div></td></tr>
        )}
      </>
    );
  };
  const table = (
    <div className={d.tableWrap}>
      <table className={d.table}>
        <thead>
          <tr>
            <th />
            {codeCol && <th className={d.codeHead}>{block.codeLabel ?? "Project Code"}</th>}
            {block.columns.map((c) => <th key={c}>{c}</th>)}
            {block.totalLabel && <th>{block.totalLabel}</th>}
          </tr>
          {block.columnSubs && (
            <tr className={d.sub}>
              <th />
              {codeCol && <th />}
              {block.columnSubs.map((c, n) => <th key={n}>{c}</th>)}
              {block.totalLabel && <th />}
            </tr>
          )}
        </thead>
        <tbody>
          {block.rows.map((r, n) => <CellRow key={`0:${n}:` + r.label + (r.sub ?? "")} row={r} depth={0} index={n} render={renderRow} />)}
        </tbody>
      </table>
    </div>
  );
  const foot = (
    <>
      {block.expandHint && <div className={d.expandHint}>{block.expandHint}</div>}
      {block.source && <p className={d.source}>{block.source}</p>}
    </>
  );
  const fsBtn = (label: string, out: boolean) => (
    <button type="button" className={d.fsBtn} onClick={() => setFull(out)} aria-label={label} title={label}>
      {out ? (
        <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M2 2h5M2 2v5M2 2l5 5M14 14H9M14 14V9M14 14 9 9" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" /></svg>
      ) : (
        <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M7 7H2M7 7V2M7 7 2 2M9 9h5M9 9v5M9 9l5 5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" /></svg>
      )}
      <span>{label}</span>
    </button>
  );
  const legend = block.legend && block.legend.length ? (
    <div className={d.legend}>
      {block.legend.map((l) => <span key={l.text}><span className={d.dot} style={{ background: l.color }} aria-hidden="true" />{l.text}</span>)}
    </div>
  ) : null;
  return (
    <div className={d.tableBlock}>
      <div className={d.tableHead}>
        {block.caption && <div className={d.caption}>{block.caption}</div>}
        {fsBtn("Full screen", true)}
      </div>
      {legend}
      {table}
      {foot}
      {full && typeof document !== "undefined" && createPortal(
        <div className={d.fsOverlay} role="dialog" aria-modal="true" aria-label={block.caption ?? "Table"}>
          <div className={d.fsBar}>
            <div className={d.caption} style={{ marginBottom: 0 }}>{block.caption ?? "Table"}</div>
            {fsBtn("Minimize", false)}
          </div>
          <div className={d.fsBody}>
            {legend}
            {table}
            {foot}
          </div>
        </div>,
        document.body,
      )}
    </div>
  );
}

function CellFrag({ v }: { v: number | null }) {
  if (v == null) return <td />;
  if (Math.round(v) === 0) return <td className={d.zero}>·</td>;
  return <td className={v < 0 ? d.neg : undefined}>{money(v)}</td>;
}

function CellRow({ row, depth, index, render }: { row: DocRow; depth: number; index: number; render: (r: DocRow, depth?: number, index?: number) => React.ReactNode }) {
  return <>{render(row, depth, index)}</>;
}

/* ---- the chart: grouped bars by month, a net strip beneath, hover to read ---- */
function Chart({ block }: { block: DocChart }) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 1000, H = 300, L = 88, R = 16, T = 18, B = 70;
  const n = block.categories.length;
  const max = useMemo(() => {
    const m = Math.max(...block.bars.flatMap((b) => b.values));
    const step = m > 500000 ? 200000 : m > 100000 ? 50000 : 10000;
    return Math.ceil(m / step) * step;
  }, [block.bars]);
  const step = max > 500000 ? 200000 : max > 100000 ? 50000 : 10000;
  const ticks: number[] = [];
  for (let v = 0; v <= max; v += step) ticks.push(v);
  const plotW = W - L - R, plotH = H - T - B;
  const slot = plotW / n;
  const bw = Math.min(26, (slot * 0.62) / block.bars.length);
  const y = (v: number) => T + plotH - (v / max) * plotH;
  const tone = (t: DocChart["bars"][number]["tone"]) =>
    t === "accent" ? "var(--th-accent-bright)" : t === "gold" ? "var(--th-gold)" : t === "pos" ? "var(--th-pos)" : t === "neg" ? "var(--th-neg)" : "rgba(243,241,234,0.34)";
  const fmt = (v: number) => (block.unit === "n" ? v.toLocaleString("en-US") : `$${money(v)}`);
  const tipX = hover == null ? 0 : ((L + slot * hover + slot / 2) / W) * 100;
  return (
    <div className={d.chartBlock}>
      {block.title && <div className={d.caption}>{block.title}</div>}
      <div className={d.legend}>
        {block.bars.map((b) => <span key={b.name}><i style={{ background: tone(b.tone) }} />{b.name}</span>)}
        {block.line && <span><i style={{ background: "linear-gradient(90deg, var(--th-pos) 50%, var(--th-neg) 50%)" }} />{block.line.name}</span>}
      </div>
      <div style={{ position: "relative" }} onMouseLeave={() => setHover(null)}>
        <svg className={d.chartSvg} viewBox={`0 0 ${W} ${H}`} role="img" aria-label={block.title ?? "Chart"}>
          {ticks.map((v) => (
            <g key={v}>
              <line className={v === 0 ? d.baseline : d.grid} x1={L} x2={W - R} y1={y(v)} y2={y(v)} />
              <text className={d.axis} x={L - 10} y={y(v) + 4} textAnchor="end">{v === 0 ? "0" : k(v)}</text>
            </g>
          ))}
          {block.estimateFrom != null && block.estimateFrom > 0 && block.estimateFrom < n && (
            <g>
              <line className={d.estLine} x1={L + slot * block.estimateFrom} x2={L + slot * block.estimateFrom} y1={T - 6} y2={H - B + 52} />
              <text className={d.estLabel} x={L + slot * block.estimateFrom + 8} y={T + 4}>{block.estimateLabel ?? "Estimate"}</text>
              <text className={d.estLabel} x={L + slot * block.estimateFrom - 8} y={T + 4} textAnchor="end">Closed</text>
            </g>
          )}
          {block.categories.map((c, m) => {
            const x0 = L + slot * m;
            const groupW = bw * block.bars.length + 4 * (block.bars.length - 1);
            const gx = x0 + (slot - groupW) / 2;
            const est = block.estimateFrom != null && m >= block.estimateFrom;
            return (
              <g key={c} onMouseEnter={() => setHover(m)}>
                <rect className={`${d.hit}${hover === m ? ` ${d.hitOn}` : ""}`} x={x0} y={T} width={slot} height={plotH + B - 8} />
                {block.bars.map((b, bi) => (
                  <rect key={b.name} x={gx + bi * (bw + 4)} y={y(b.values[m])} width={bw} height={Math.max(0, y(0) - y(b.values[m]))} fill={tone(b.tone)} fillOpacity={est ? 0.38 : 1} stroke={est ? tone(b.tone) : "none"} strokeDasharray={est ? "3 3" : undefined} strokeWidth={est ? 1 : 0} opacity={hover == null || hover === m ? 1 : 0.55} />
                ))}
                <text className={d.month} x={x0 + slot / 2} y={H - B + 24} textAnchor="middle">{c}</text>
                {block.line && (
                  <text className={d.strip} x={x0 + slot / 2} y={H - B + 48} textAnchor="middle" fill={block.line.values[m] < 0 ? "var(--th-neg)" : "var(--th-pos)"}>
                    {money(block.line.values[m])}
                  </text>
                )}
              </g>
            );
          })}
          {block.line && <text className={d.stripLabel} x={L - 10} y={H - B + 48} textAnchor="end">{block.line.name}</text>}
        </svg>
        {hover != null && (
          <div className={d.tip} style={{ left: `${tipX}%`, top: `${(T / H) * 100}%` }}>
            <div className={d.tipK}>{block.categories[hover]}</div>
            {block.bars.map((b) => <div key={b.name}><span>{b.name}</span><b>{fmt(b.values[hover])}</b></div>)}
            {block.line && <div><span>{block.line.name}</span><b style={{ color: block.line.values[hover] < 0 ? "var(--th-neg)" : "var(--th-pos)" }}>{fmt(block.line.values[hover])}</b></div>}
          </div>
        )}
      </div>
      {block.caption && <p className={d.source}>{block.caption}</p>}
    </div>
  );
}

/* ---- the plan on a spine (10/31, the Micro): the Mission Card's domain flow as a document block.
   Polaris at the head, the things that must be true down the spine at their moments, the big things
   that have to happen keyed beneath each, the Final under a flag at the foot. Three views on one
   spine: Strategy reads the statements; Operations adds how each is measured, who is accountable,
   and opens a big thing to its people, data-related costs and tasks; Budget prices each big thing. ---- */
// ---------------------------------------------------------------------------
// The plan on one line (11/1): big rocks only, each a dated point; the detail opens in a modal.
// ---------------------------------------------------------------------------
const LINE_GOLD = "#F8C761";
const PX_PER_DAY = 7;
const ROW_H = 32;
const FAN_PITCH = 40;
type LineEvent = { rock: LineRock; ri: number; pt: LinePoint; pi: number };
type LineItem = LineEvent | { month: string };
type LineGroup = { date: string; h: number; c: number } & ({ month: string } | { items: LineEvent[] });
const itemDate = (x: LineItem) => ("month" in x ? x.month : x.pt.date);
const daysBetween = (a: string, b: string) => Math.round((lineDate(b).getTime() - lineDate(a).getTime()) / 86400000);
const lineDate = (iso: string) => new Date(iso + "T12:00:00");
const lineDay = (iso: string) => lineDate(iso).toLocaleDateString("en-US", { month: "short", day: "numeric" });
const lineYear = (iso: string) => String(lineDate(iso).getFullYear());

function LinePlan({ block }: { block: DocLine }) {
  const [openKey, setOpenKey] = useState<string | null>(null);
  // Which categories are on the line at all; every category starts on.
  const [off, setOff] = useState<Record<string, boolean>>({});
  const person = (key?: string) => (key ? block.people?.find((p) => p.key === key) : undefined);
  const cat = (r: LineRock) => block.categories?.find((c) => c.key === r.category);
  // Every point of every rock, in date order; ties keep the rocks' own order. The line is a
  // timeline: the distance between two points is their days apart (PX_PER_DAY), with a floor so
  // same-day rows stack. Months with no point get a faint mark so a long stretch still reads.
  const groups = useMemo(() => {
    const all = block.rocks.filter((r) => !(r.category && off[r.category])).flatMap((r) => r.points.map((pt, pi) => ({ rock: r, ri: block.rocks.indexOf(r), pt, pi })));
    const sorted = all.sort((a, b) => a.pt.date.localeCompare(b.pt.date) || a.ri - b.ri || a.pi - b.pi);
    const items: (typeof sorted[number] | { month: string })[] = [...sorted];
    if (sorted.length > 1) {
      const first = lineDate(sorted[0].pt.date), last = lineDate(sorted[sorted.length - 1].pt.date);
      const seen = new Set(sorted.map((e) => e.pt.date.slice(0, 7)));
      for (let y = first.getFullYear(), m = first.getMonth(); y < last.getFullYear() || (y === last.getFullYear() && m <= last.getMonth()); m === 11 ? (y++, m = 0) : m++) {
        const key = `${y}-${String(m + 1).padStart(2, "0")}`;
        if (!seen.has(key)) items.push({ month: `${key}-01` });
      }
    }
    const ordered = items.sort((a, b) => itemDate(a).localeCompare(itemDate(b)));
    // one group per date: a single row (h 32, dot center 16) or a fan of rows around one dot
    const groups: LineGroup[] = [];
    for (const it of ordered) {
      if ("month" in it) { groups.push({ month: it.month, date: it.month, h: ROW_H, c: 16 }); continue; }
      const last = groups[groups.length - 1];
      if (last && !("month" in last) && last.date === it.pt.date) { last.items.push(it); last.h = FAN_PITCH * last.items.length; last.c = last.h / 2; }
      else groups.push({ date: it.pt.date, items: [it], h: ROW_H, c: 16 });
    }
    return groups;
  }, [block.rocks, off]);
  const open = openKey ? block.rocks.find((r) => r.key === openKey) : undefined;
  const openIndex = open ? block.rocks.indexOf(open) + 1 : 0;

  useEffect(() => {
    if (!openKey) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpenKey(null); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openKey]);

  const dot = (color?: string, size = 16, rim?: string) => (
    <span className={d.lineDot} style={{ ["--dotc" as string]: color ?? "var(--th-accent-bright)", ["--rimc" as string]: rim ?? "#2F5F96", width: size, height: size }} aria-hidden="true" />
  );
  const splitDot = (parts: { color: string; rim: string }[], size: number, id: string) => {
    const n = parts.length, r = size / 2, sw = 1.5;
    const stops = (key: "color" | "rim") => parts.flatMap((p, i) => [<stop key={`${i}a`} offset={`${(i / n) * 100}%`} style={{ stopColor: p[key] }} />, <stop key={`${i}b`} offset={`${((i + 1) / n) * 100}%`} style={{ stopColor: p[key] }} />]);
    return (
      <svg className={d.lineSplit} width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-hidden="true">
        <defs>
          <linearGradient id={`${id}-f`} x1="0" x2="1" y1="0" y2="1">{stops("color")}</linearGradient>
          <linearGradient id={`${id}-r`} x1="0" x2="1" y1="0" y2="1">{stops("rim")}</linearGradient>
          <clipPath id={`${id}-c`}><circle cx={r} cy={r} r={r} /></clipPath>
        </defs>
        <circle cx={r} cy={r} r={r - sw / 2} fill={`url(#${id}-f)`} stroke={`url(#${id}-r)`} strokeWidth={sw} />
        {/* the divider runs diagonal, perpendicular to the gradient axis: for two colors, top-right to bottom-left */}
        <g clipPath={`url(#${id}-c)`}>{parts.slice(1).map((_, i) => { const t = ((i + 1) / n) * 2 * size; return <line key={i} x1={t} y1="0" x2="0" y2={t} stroke="var(--th-navy-deep)" strokeWidth="1.5" />; })}</g>
      </svg>
    );
  };

  const detail = (r: LineRock, n: number) => (
    <>
      {r.detail && r.detail.length > 0 && (
        <div className={d.planTree}>
          {r.detail.map((b, m) => (
            <div key={m} className={d.planLeaf}>
              <span className={d.planKey}>{n}.{m + 1}</span>
              <Face who={person(b.owner)} size={16} />
              <span className={d.planLeafText}>{b.text}</span>
            </div>
          ))}
        </div>
      )}
      {r.notes && r.notes.length > 0 && (
        <div className={d.lineNotes}>
          <span className={d.planEyebrow}>Details for later</span>
          {r.notes.map((t, i) => <div key={i} className={d.planLeafText}>{t}</div>)}
        </div>
      )}
    </>
  );

  return (
    <div className={`${d.planBlock} ${d.lineBlock}`}>
      <div className={d.planHead}>
        <span className={d.planBadge}>{block.code ?? "P"}</span>
        <div>
          {block.code && <div className={d.planCode}>{block.code} · Plan</div>}
          <div className={d.planName}>{block.name}</div>
        </div>
      </div>

      {block.categories && (
        <div className={d.lineCats} style={{ gridTemplateColumns: `repeat(${block.categories.length}, minmax(0, 1fr))` }}>
          {block.categories.map((c) => {
            const on = !off[c.key];
            return (
              <span key={c.key} className={d.lineCatWrap} style={{ ["--dotc" as string]: c.color }}>
                <button type="button" className={`${d.lineCat}${on ? ` ${d.lineCatOn}` : ""}${c.link ? ` ${d.lineCatLinked}` : ""}`} aria-pressed={on} onClick={() => setOff((o) => ({ ...o, [c.key]: !o[c.key] }))} title={on ? `${c.label} is on the line. Click to take it off.` : `${c.label} is off the line. Click to put it back.`}>
                  {dot(c.color, 12, c.rim)}
                  <span>{c.label}</span>
                  <span className={d.lineCatState}>{on ? "On" : "Off"}</span>
                </button>
                {c.link && (
                  <Link href={c.link.href} className={d.lineCatOpen} title={c.link.label} aria-label={c.link.label}>
                    <svg width="13" height="13" viewBox="0 0 24 24" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </Link>
                )}
              </span>
            );
          })}
        </div>
      )}
      <div className={d.lineHint}>
        <span><span className={d.lineMore}>Details</span><span>Opens the rock</span></span>
      </div>

      <div className={d.planSpine}>
        <div className={`${d.planRail} ${d.planRailFirst}`}>
          <span className={d.planNodeSlot}><PlanNode n="★" pulse color={LINE_GOLD} /></span>
          <span className={d.planEyebrow} style={{ color: LINE_GOLD }}>Polaris</span>
          {block.horizon && <span className={d.planWhen}>{block.horizon}</span>}
        </div>
        <div className={d.planBody}>
          <div className={`${d.planPolaris}${block.polaris ? "" : ` ${d.planTextOpen}`}`}>{block.polaris ?? "At the end of the plan, Third Horizon will have… Open."}</div>
        </div>

        {groups.map((g, i) => {
          const next = groups[i + 1];
          // the gap to the next group: its days apart, less the space below this group's dot and above the next's
          const gap = next ? Math.max(8, daysBetween(g.date, next.date) * PX_PER_DAY - (g.h - g.c) - next.c) : 34;
          if ("month" in g) {
            return (
              <React.Fragment key={g.month}>
                <div className={`${d.planRail} ${d.lineRail} ${d.lineMonth}`} style={{ paddingBottom: gap }}>
                  <span className={`${d.planNodeSlot} ${d.lineDotSlot}`} style={{ top: 13, right: 4 }}><span className={d.lineMonthTick} /></span>
                  <span className={d.lineMonthLabel}>{lineDate(g.month).toLocaleDateString("en-US", { month: "short" })}</span>
                </div>
                <div className={`${d.planBody} ${d.lineBody} ${d.lineMonthBody}`} style={{ paddingBottom: gap }} />
              </React.Fragment>
            );
          }
          const one = g.items.length === 1;
          const cats = g.items.map((e) => cat(e.rock));
          const distinct = cats.filter((c, i) => c && cats.findIndex((x) => x?.key === c.key) === i) as NonNullable<typeof cats[number]>[];
          const spine = distinct.length > 1
            ? splitDot(distinct.map((c) => ({ color: c.color, rim: c.rim ?? "#2F5F96" })), 28, `split-${g.date}`)
            : dot(cats[0]?.color, 28, cats[0]?.rim);
          const n = g.items.length;
          const row = (e: LineEvent, size: number, i: number) => {
            const c = cat(e.rock);
            const pos = one ? "" : ` ${i === 0 ? d.lineFanFirst : i === n - 1 ? d.lineFanLast : d.lineFanMid}`;
            return (
              <button type="button" className={`${d.lineRock}${one ? "" : ` ${d.lineFanRow}`}${pos}`} onClick={() => setOpenKey(e.rock.key)} aria-haspopup="dialog" title="Open the detail behind this rock">
                {!one && dot(c?.color, 28, c?.rim)}
                <Face who={person(e.rock.owner)} size={size} />
                <span className={`${d.planText} ${d.lineText}`}>{e.pt.text ?? e.rock.text}</span>
                {e.pt.note && <span className={d.lineFlagNote}>{e.pt.note}</span>}
                <span className={d.lineMore}>Details</span>
              </button>
            );
          };
          return (
            <React.Fragment key={g.date}>
              <div className={`${d.planRail} ${d.lineRail}${one ? "" : ` ${d.lineRailFan}`}`} style={{ paddingBottom: gap }}>
                <span className={`${d.planNodeSlot} ${d.lineDotSlot}`} style={{ top: one ? 2 : `calc((100% - ${gap}px) / 2 - 14px)`, right: -7 }}>{spine}</span>
                <span className={one ? d.lineRailLabels : d.lineRailFanLabels} style={one ? undefined : { top: `calc((100% - ${gap}px) / 2 - 16px)` }}>
                  <span className={d.planLabel}>{lineDay(g.date)}</span>
                  <span className={d.planWhen}>{lineYear(g.date)}</span>
                </span>
              </div>
              <div className={`${d.planBody} ${d.lineBody}${one ? "" : ` ${d.lineFan}`}`} style={{ paddingBottom: gap, ["--fantop" as string]: one ? "15px" : `calc((100% - ${gap}px) / 2 - 1px)` }}>
                {one ? row(g.items[0], 28, 0) : g.items.map((e, i) => <React.Fragment key={`${e.rock.key}-${e.pi}`}>{row(e, 28, i)}</React.Fragment>)}
              </div>
            </React.Fragment>
          );
        })}

        <div className={`${d.planRail} ${d.planRailLast}`}>
          <span className={d.planNodeSlot}><PlanNode n={<FlagGlyph />} pulse /></span>
          <span className={`${d.planEyebrow} ${d.planAccent}`}>Final</span>
          {block.horizon && <span className={d.planWhen}>{block.horizon}</span>}
        </div>
        <div className={d.planBody}>
          <div className={`${d.planText}${block.final?.text ? "" : ` ${d.planTextOpen}`}`}>{block.final?.text ?? "The one statement that is true of the whole plan at the end. Open."}</div>
        </div>
      </div>
      {block.source && <p className={d.source}>{block.source}</p>}

      {open && typeof document !== "undefined" && createPortal(
        <div className={d.lineOverlay} role="dialog" aria-modal="true" aria-label={open.text} onClick={() => setOpenKey(null)}>
          <div className={d.lineModal} style={{ borderTopColor: cat(open)?.color }} onClick={(ev) => ev.stopPropagation()}>
            <div className={d.lineModalHead}>
              <div className={d.lineModalWhen}>
                {cat(open) && <span className={d.lineModalPoint}>{dot(cat(open)!.color, 12, cat(open)!.rim)}<span>{cat(open)!.label}</span></span>}
                {open.points.map((pt, i) => (
                  <span key={i} className={d.lineModalPoint}>
                    {dot(cat(open)?.color, 12, cat(open)?.rim)}
                    <span>{pt.text ? `${pt.text} · ` : ""}{lineDay(pt.date)}, {lineYear(pt.date)}{pt.note ? `, ${pt.note}` : ""}</span>
                  </span>
                ))}
              </div>
              <button type="button" className={d.lineClose} onClick={() => setOpenKey(null)} aria-label="Close">×</button>
            </div>
            <div className={`${d.planText} ${d.lineModalTitle}`}><Face who={person(open.owner)} size={28} />{open.text}</div>
            {detail(open, openIndex)}
            {!open.detail?.length && !open.notes?.length && <div className={d.planOpen}>Nothing behind this rock yet.</div>}
          </div>
        </div>,
        document.body,
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// The capital raise page (11/1): targets with owners, and the road (map + travel dates).
// ---------------------------------------------------------------------------
function Capital({ block }: { block: DocCapital }) {
  const [tab, setTab] = useState<"targets" | "road" | "directory">("targets");
  const [q, setQ] = useState("");
  const [openPerson, setOpenPerson] = useState<DirectoryPerson | null>(null);
  const directory = useMemo(() => {
    const all = block.directory ?? [];
    const needle = q.trim().toLowerCase();
    return needle ? all.filter((p) => `${p.name} ${p.org} ${p.email} ${p.subjects.join(" ")}`.toLowerCase().includes(needle)) : all;
  }, [block.directory, q]);
  const [archiveOpen, setArchiveOpen] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);
  const [pill, setPill] = useState<"bio" | "relationship" | "briefing" | "notes">("bio");
  const person = (key?: string) => (key ? block.people?.find((p) => p.key === key) : undefined);
  const everyone = useMemo(() => [...block.targets, ...(block.archive ?? [])], [block.targets, block.archive]);
  const byId = useMemo(() => new Map(everyone.map((t) => [t.id, t])), [everyone]);
  const stopsByCity = useMemo(() => {
    const m = new Map<string, number>();
    block.stops.forEach((st) => m.set(st.city, (m.get(st.city) ?? 0) + 1));
    return m;
  }, [block.stops]);
  const allocated = (city: string) => block.targets.filter((t) => t.city === city);
  const fromArchive = (city: string) => (block.archive ?? []).filter((t) => t.city === city);
  const cityCount = (city: string) => allocated(city).length + fromArchive(city).length;
  const open = openId ? byId.get(openId) : undefined;

  useEffect(() => {
    if (!openId) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpenId(null); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openId]);

  const ownerCell = (t: CapitalTarget) => {
    const who = person(t.owner);
    if (who) return <span className={d.capOwner}><Face who={who} size={22} />{who.name.split(" ")[0]}</span>;
    if (t.sponsor) return <span className={d.capOwner}><span className={d.capInitial}>{t.sponsor[0]}</span>{t.sponsor}</span>;
    return <span className={d.planOpen}>Open</span>;
  };
  const when = (iso?: string) => {
    if (!iso) return null;
    const dt = new Date(iso);
    const day = dt.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    const time = iso.length > 10 ? dt.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }) : "";
    return time ? `${day} · ${time}` : day;
  };
  const avatar = (t: CapitalTarget, size: number) =>
    t.profile?.photo
      // eslint-disable-next-line @next/next/no-img-element
      ? <img className={d.planFace} src={t.profile.photo} alt={t.name} width={size} height={size} />
      : <span className={`${d.capInitial} ${d.capAvatar}`} style={{ width: size, height: size }}>{t.name.split(" ").map((w) => w[0]).slice(0, 2).join("")}</span>;

  const table = (rows: CapitalTarget[], archive: boolean) => (
    <div className={d.capTable} role="table">
      <div className={`${d.capRow} ${d.capHead}`} role="row">
        <span className={d.planEyebrow}>Name</span><span className={d.planEyebrow}>Organization</span><span className={d.planEyebrow}>Owner</span><span className={d.planEyebrow}>Scheduled</span><span className={`${d.planEyebrow} ${d.planCenter}`}>NDA</span><span className={d.planEyebrow}>Status</span>
      </div>
      {rows.length === 0 && <div className={d.capEmpty}><span className={d.planOpen}>No one on the map yet.</span></div>}
      {rows.map((t) => (
        <div key={t.id} className={`${d.capRow}${archive ? ` ${d.capRowArchive}` : ""}`} role="row">
          <button type="button" className={d.capNameBtn} onClick={() => { setOpenId(t.id); setPill("bio"); }} aria-haspopup="dialog" title="Open the briefing card">
            {avatar(t, 30)}
            <span className={d.capWho}><span className={d.capName}>{t.name}</span>{t.title && <span className={d.capTitle}>{t.title}</span>}</span>
          </button>
          <span className={d.capOrg}>{t.org || <span className={d.planOpen}>No organization</span>}</span>
          <span>{ownerCell(t)}</span>
          <span className={d.capSched}>{t.scheduled ? <><span className={d.capSchedWhen}>{when(t.scheduled)}</span>{t.where && <span className={d.capTitle}>{t.where}</span>}</> : <span className={d.planOpen}>Open</span>}</span>
          <span className={`${d.capNda} ${d.planCenter}${t.nda ? ` ${d.capNdaY}` : ""}`}>{t.nda ? "Y" : "N"}</span>
          <span>{t.status ? <span className={d.capTag}>{t.status}</span> : <span className={d.planOpen}>Open</span>}</span>
        </div>
      ))}
    </div>
  );

  const lines = (xs?: string[], empty = "Open.") => (xs && xs.length > 0 ? xs.map((x, i) => <p key={i} className={d.capProse}>{x}</p>) : <p className={`${d.capProse} ${d.planTextOpen}`}>{empty}</p>);
  const bullets = (xs?: string[], empty = "Open.") => (xs && xs.length > 0 ? <ul className={d.capBullets}>{xs.map((x, i) => <li key={i}>{x}</li>)}</ul> : <p className={`${d.capProse} ${d.planTextOpen}`}>{empty}</p>);
  const timeline = (rows?: { when: string; text: string }[], label = "Key Moments") => rows && rows.length > 0 ? (
    <div className={d.capTl}>
      <span className={d.planEyebrow}>{label}</span>
      <div className={d.capTlSpine}>
        {rows.map((r, i) => (
          <React.Fragment key={i}>
            <span className={d.capTlWhen}>{r.when}</span>
            <span className={d.capTlDot} aria-hidden="true" />
            <span className={d.capTlText}>{r.text}</span>
          </React.Fragment>
        ))}
      </div>
    </div>
  ) : null;

  return (
    <div className={`${d.planBlock} ${d.lineBlock}`}>
      <div className={d.planHead}>
        <span className={d.planBadge}>{block.code ?? "C"}</span>
        <div>
          {block.code && <div className={d.planCode}>{block.code} · Capital</div>}
          <div className={d.planName}>{block.name}</div>
        </div>
      </div>

      <div className={d.lineCats} style={{ gridTemplateColumns: `repeat(${block.directory ? 3 : 2}, minmax(0, 1fr))` }}>
        <button type="button" className={`${d.lineCat}${tab === "targets" ? ` ${d.lineCatOn}` : ""}`} aria-pressed={tab === "targets"} onClick={() => setTab("targets")}>
          <span>Targets for Discussion</span><span className={d.lineCatState}>{block.targets.length}</span>
        </button>
        <button type="button" className={`${d.lineCat}${tab === "road" ? ` ${d.lineCatOn}` : ""}`} aria-pressed={tab === "road"} onClick={() => setTab("road")}>
          <span>Map and Travel</span><span className={d.lineCatState}>{block.stops.length} stops</span>
        </button>
        {block.directory && (
          <button type="button" className={`${d.lineCat}${tab === "directory" ? ` ${d.lineCatOn}` : ""}`} aria-pressed={tab === "directory"} onClick={() => setTab("directory")}>
            <span>Directory</span><span className={d.lineCatState}>{block.directory.length} people</span>
          </button>
        )}
      </div>

      {tab === "directory" && block.directory ? (
        <>
          <div className={d.dirBar}>
            <input className={d.dirSearch} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search a name, an organization, a subject" aria-label="Search the directory" />
            <span className={d.dirCount}>{directory.length} of {block.directory.length} · from the Third Horizon mailbox, January to November 2026</span>
          </div>
          <div className={`${d.capTable} ${d.dirTable}`} role="table">
            <div className={`${d.dirRow} ${d.capHead}`} role="row">
              <span className={d.planEyebrow}>Name</span><span className={d.planEyebrow}>Organization</span><span className={`${d.planEyebrow} ${d.planRight}`}>From David</span><span className={`${d.planEyebrow} ${d.planRight}`}>To David</span><span className={d.planEyebrow}>First</span><span className={d.planEyebrow}>Last</span>
            </div>
            {directory.slice(0, 400).map((p) => (
              <div key={p.id} className={d.dirRow} role="row">
                <button type="button" className={d.capNameBtn} onClick={() => setOpenPerson(p)} aria-haspopup="dialog" title="Open the card">
                  <span className={`${d.capInitial} ${d.capAvatar}`} style={{ width: 30, height: 30 }}>{p.name.split(" ").map((w) => w[0]).slice(0, 2).join("")}</span>
                  <span className={d.capWho}><span className={d.capName}>{p.name}</span><span className={d.capTitle}>{p.email}</span></span>
                </button>
                <span className={d.capOrg}>{p.org || <span className={d.planOpen}>Personal address</span>}</span>
                <span className={`${d.capMeta} ${d.planRight}`}>{p.fromMe}</span>
                <span className={`${d.capMeta} ${d.planRight}`}>{p.toMe}</span>
                <span className={d.capMeta}>{p.first}</span>
                <span className={d.capMeta}>{p.last}</span>
              </div>
            ))}
          </div>
        </>
      ) : tab === "targets" ? (
        <>
          <div className={d.capSection}>{table(block.targets, false)}</div>
          {block.archive && block.archive.length > 0 && (
            <div className={d.capArchive}>
              <button type="button" className={d.capArchiveBtn} aria-expanded={archiveOpen} onClick={() => setArchiveOpen((v) => !v)}>
                <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true" className={`${d.planChev}${archiveOpen ? ` ${d.planChevOpen}` : ""}`} style={{ border: 0, width: 12, height: 12 }}><path d="M4 2l4 4-4 4" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
                <span className={d.planEyebrow} style={{ display: "inline" }}>Archive</span>
                <span className={d.capArchiveTitle}>{block.archiveLabel ?? "Archive"}</span>
                <span className={d.lineCatState}>{block.archive.length}</span>
              </button>
              {archiveOpen && table(block.archive, true)}
            </div>
          )}
        </>
      ) : (
        <>
          <svg className={d.capMap} viewBox={US_VIEWBOX} role="img" aria-label="United States, the itinerary's cities">
            <path d={US_NATION} className={d.capNation} />
            <path d={US_BORDERS} className={d.capBorders} />
            {Object.entries(US_CITIES).map(([city, [x, y]]) => {
              const n = stopsByCity.get(city) ?? 0;
              const option = block.options?.includes(city) && n === 0;
              if (n === 0 && !option) return null;
              const r = option ? 6 : 7 + Math.min(n, 4) * 2;
              const right = x > 700;
              return (
                <g key={city} className={option ? d.capCityOption : d.capCity}>
                  <circle cx={x} cy={y} r={r} />
                  {n > 1 && <text x={x} y={y + 4} textAnchor="middle" className={d.capCityCount}>{n}</text>}
                  <text x={right ? x - r - 6 : x + r + 6} y={y + 4} textAnchor={right ? "end" : "start"} className={d.capCityLabel}>{city}{option ? " · option" : ""}{cityCount(city) ? ` · ${cityCount(city)}` : ""}</text>
                </g>
              );
            })}
          </svg>
          <div className={d.capStops}>
            <div className={`${d.capStop} ${d.capHead}`}>
              <span className={d.planEyebrow}>When</span><span className={d.planEyebrow}>Where</span><span className={d.planEyebrow}>Targets Allocated</span>
            </div>
            {block.stops.map((st, i) => {
              const names = [...st.targets.map((id) => byId.get(id)).filter(Boolean) as CapitalTarget[], ...allocated(st.city).filter((t) => !st.targets.includes(t.id))];
              return (
                <div key={i} className={d.capStop}>
                  <span className={d.capWhen}>{st.when}</span>
                  <span className={d.capWhere}>{st.label}{st.note && <span className={d.capTitle}>{st.note}</span>}</span>
                  <span className={d.capAlloc}>
                    {names.length === 0 && fromArchive(st.city).length === 0 ? <span className={d.planOpen}>Open</span> : null}
                    {names.map((t) => <span key={t.id} className={d.capChip}><Face who={person(t.owner)} size={16} />{t.name}<span className={d.capChipOrg}>{t.org}</span></span>)}
                    {fromArchive(st.city).map((t) => <span key={t.id} className={`${d.capChip} ${d.capChipArchive}`} title={t.note ?? "From the archive"}><Face who={person(t.owner)} size={16} />{t.name}<span className={d.capChipOrg}>{t.org}</span>{t.note?.startsWith("City is a guess") && <span className={d.capChipGuess}>?</span>}</span>)}
                  </span>
                </div>
              );
            })}
            {block.options && block.options.length > 0 && (
              <div className={d.capStop}>
                <span className={d.capWhen}>Dec 16 +</span>
                <span className={d.capWhere}>Unplanned<span className={d.capTitle}>options: {block.options.join(", ")}</span></span>
                <span className={d.capAlloc}><span className={d.planOpen}>Open</span></span>
              </div>
            )}
          </div>
        </>
      )}
      {block.source && <p className={d.source}>{block.source}</p>}

      {openPerson && typeof document !== "undefined" && createPortal(
        <div className={d.lineOverlay} role="dialog" aria-modal="true" aria-label={openPerson.name} onClick={() => setOpenPerson(null)}>
          <div className={`${d.lineModal} ${d.capModal}`} onClick={(ev) => ev.stopPropagation()}>
            <div className={d.capModalHead}>
              <span className={`${d.capInitial} ${d.capAvatar}`} style={{ width: 64, height: 64, fontSize: 20 }}>{openPerson.name.split(" ").map((w) => w[0]).slice(0, 2).join("")}</span>
              <div className={d.capModalWho}>
                <div className={d.capModalName}>{openPerson.name}</div>
                <div className={d.capModalRole}>{openPerson.org || "Personal address"} · {openPerson.email}</div>
              </div>
              <button type="button" className={d.lineClose} onClick={() => setOpenPerson(null)} aria-label="Close">×</button>
            </div>
            <div className={d.capModalBody}>
              <span className={d.planEyebrow}>What The Mailbox Shows</span>
              <p className={d.capProse}>{openPerson.fromMe} message{openPerson.fromMe === 1 ? "" : "s"} from David and {openPerson.toMe} to him between {openPerson.first} and {openPerson.last}.</p>
              {openPerson.subjects.length > 0 && <><span className={d.planEyebrow}>Threads That Carried It</span><ul className={d.capBullets}>{openPerson.subjects.map((x, i) => <li key={i}>{x}</li>)}</ul></>}
              <p className={`${d.capProse} ${d.planTextOpen}`}>Background, relationship and briefing are open. Say the word and this person gets a full card and a place on the map.</p>
            </div>
          </div>
        </div>,
        document.body,
      )}
      {open && typeof document !== "undefined" && createPortal(
        <div className={d.lineOverlay} role="dialog" aria-modal="true" aria-label={open.name} onClick={() => setOpenId(null)}>
          <div className={`${d.lineModal} ${d.capModal}`} onClick={(ev) => ev.stopPropagation()}>
            <div className={d.capModalHead}>
              {avatar(open, 64)}
              <div className={d.capModalWho}>
                <div className={d.capModalName}>{open.name}</div>
                <div className={d.capModalRole}>{[open.title, open.org].filter(Boolean).join(", ")}{open.profile?.location ? ` · ${open.profile.location}` : ""}</div>
                <div className={d.capModalMeta}>
                  {ownerCell(open)}
                  {open.scheduled && <span className={d.capSchedWhen}>{when(open.scheduled)}{open.where ? ` · ${open.where}` : ""}</span>}
                  {open.profile?.linkedin && <a className={d.capLink} href={open.profile.linkedin} target="_blank" rel="noreferrer">LinkedIn ↗</a>}
                </div>
              </div>
              <button type="button" className={d.lineClose} onClick={() => setOpenId(null)} aria-label="Close">×</button>
            </div>
            <div className={d.planViews} style={{ marginBottom: 0 }}>
              {([["bio", "Background and Bio"], ["relationship", "Relationship"], ["briefing", "Briefing"], ["notes", "Notes"]] as const).map(([k, label]) => (
                <button key={k} type="button" className={`${d.planPill}${pill === k ? ` ${d.planPillOn}` : ""}`} aria-pressed={pill === k} onClick={() => setPill(k)}>{label}</button>
              ))}
            </div>
            <div className={d.capModalBody}>
              <Ed id={`${open.id}:${pill}`} label={`${open.name} · ${pill === "bio" ? "Background and Bio" : pill === "relationship" ? "Relationship" : pill === "briefing" ? "Briefing" : "Notes"}`}>
              {pill === "bio" && <>{bullets(open.profile?.bio, "Background and bio are open. LinkedIn and the public record fill this.")}{timeline(open.profile?.bioTimeline, "Milestones")}</>}
              {pill === "relationship" && <>{bullets(open.profile?.relationship, "The relationship is open: how we know this person, in David's words and the record.")}{timeline(open.profile?.relationshipTimeline, "What We Have Done Together")}</>}
              {pill === "briefing" && (
                <>
                  {open.profile?.briefing && open.profile.briefing.length > 0 ? (
                    <>
                      <p className={d.capProse}>{open.profile.briefing[0]}</p>
                      <div className={d.capApproach}>
                        <span className={d.planEyebrow}>Lumen's Recommendation</span>
                        {open.profile.briefing.slice(1).map((x, i) => <p key={i} className={d.capProse}>{x}</p>)}
                      </div>
                    </>
                  ) : <p className={`${d.capProse} ${d.planTextOpen}`}>No briefing yet.</p>}
                </>
              )}
              {pill === "notes" && lines(open.profile?.notes, "No notes yet.")}
              </Ed>
            </div>
          </div>
        </div>,
        document.body,
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Cards (11/1): the items that have to land. A goal, an assigned person, a status tag.
// ---------------------------------------------------------------------------
type LiveCard = { owner?: string; leads?: string[]; status?: string; updates?: CardUpdate[] };
const fmtAt = (iso: string) => new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });

/** The purple lines as cards (default) or a table (David 11/3): who brings each in, who leads the work, the one-line status
 *  on the face, and an Open button to a modal where the assignment and the status are updated. The live copy comes from the
 *  document's Ledger store and is merged over the content seed. */
function Cards({ block }: { block: DocCards }) {
  const people = block.people ?? [];
  const person = (key?: string) => (key ? people.find((p) => p.key === key) : undefined);
  const accent = block.accent ?? "var(--th-accent-bright)";
  const [view, setView] = useState<"cards" | "table">("cards");
  const [live, setLive] = useState<Record<string, LiveCard>>({});
  const [openKey, setOpenKey] = useState<string | null>(null);
  const [storeNote, setStoreNote] = useState<string>("");
  useEffect(() => {
    if (!block.store) return;
    let on = true;
    fetch(`/api/finance-review/cards?store=${encodeURIComponent(block.store)}`, { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : r.status === 503 ? { items: {}, note: "The live store is not configured; the seed stands." } : null))
      .then((j) => { if (on && j) { setLive(j.items ?? {}); if (j.note) setStoreNote(j.note); } })
      .catch(() => {});
    return () => { on = false; };
  }, [block.store]);
  const items: DocCard[] = block.items.map((c) => {
    const l = live[c.key];
    return l ? { ...c, owner: l.owner ?? c.owner, leads: l.leads ?? c.leads, status: l.status ?? c.status, updates: [...(c.updates ?? []), ...(l.updates ?? [])] } : c;
  });
  const open = items.find((c) => c.key === openKey) ?? null;
  const save = async (key: string, patch: { owner?: string; leads?: string[]; status?: string; update?: string }) => {
    const r = await fetch(`/api/finance-review/cards`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ store: block.store, key, ...patch }) });
    if (!r.ok) throw new Error(r.status === 503 ? "The live store is not configured." : `Save failed (${r.status}).`);
    const j = await r.json();
    setLive(j.items ?? {});
  };
  const faces = (keys?: string[]) => {
    const who = (keys ?? []).map(person).filter((p): p is PlanPerson => !!p);
    if (!who.length) return <span className={d.planOpen}>Unassigned</span>;
    return <span className={d.cardFaces}>{who.map((p) => <React.Fragment key={p.key}><Face who={p} size={24} />{who.length > 1 ? p.name.split(" ")[0] : p.name.split(" ")[0]}</React.Fragment>)}</span>;
  };
  const statusLine = (c: DocCard) => (c.status ? <div className={d.cardStatus}>{c.status}</div> : <div className={`${d.cardStatus} ${d.cardStatusNone}`}>No status yet.</div>);
  return (
    <div style={{ ["--cardc" as string]: accent }}>
      <div className={d.cardsBar}>
        <span className={d.viewToggle} role="group" aria-label="View">
          <button type="button" className={`${d.viewBtn}${view === "cards" ? ` ${d.viewOn}` : ""}`} aria-pressed={view === "cards"} onClick={() => setView("cards")}>Cards</button>
          <button type="button" className={`${d.viewBtn}${view === "table" ? ` ${d.viewOn}` : ""}`} aria-pressed={view === "table"} onClick={() => setView("table")}>Table</button>
        </span>
        {storeNote && <span className={d.modalNote}>{storeNote}</span>}
      </div>
      {view === "cards" ? (
        <div className={d.cards}>
          {items.map((c) => (
            <div key={c.key} className={d.card}>
              <div className={d.cardTitle}>{c.title}</div>
              <div className={d.cardSub}>{c.code ?? "No Project Code"} · {c.practice ?? ""}</div>
              <div className={d.cardGoal}><span className={d.planEyebrow}>Goal</span><span className={d.cardMoney}>{dollars(c.goal)}</span></div>
              {statusLine(c)}
              <div className={d.cardPeople}>
                <div className={d.cardRole}><span className={d.cardRoleK}>Brings In</span>{faces(c.owner ? [c.owner] : [])}</div>
                <div className={d.cardRole}><span className={d.cardRoleK}>Leads</span>{faces(c.leads)}</div>
              </div>
              <div className={d.cardFoot}>
                {c.link ? <a className={d.cardLink} href={c.link.href} target="_blank" rel="noreferrer">{c.link.label}</a> : <span />}
                <button type="button" className={d.cardOpenBtn} onClick={() => setOpenKey(c.key)}>Open</button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className={d.cardsTableWrap}>
          <table className={d.cardsTable}>
            <thead><tr><th>Line</th><th>Project Code</th><th>Practice Area</th><th className={d.num}>Goal</th><th>Brings In</th><th>Leads</th><th>Status</th><th /></tr></thead>
            <tbody>
              {items.map((c) => (
                <tr key={c.key}>
                  <td>{c.title}{c.link && <> · <a className={d.cardLink} href={c.link.href} target="_blank" rel="noreferrer">{c.link.label}</a></>}</td>
                  <td className={d.cardSub}>{c.code ?? "No Project Code"}</td>
                  <td>{c.practice ?? ""}</td>
                  <td className={d.num}>{dollars(c.goal)}</td>
                  <td>{faces(c.owner ? [c.owner] : [])}</td>
                  <td>{faces(c.leads)}</td>
                  <td>{c.status ?? <span className={d.planOpen}>No status yet.</span>}</td>
                  <td><button type="button" className={d.cardOpenBtn} onClick={() => setOpenKey(c.key)}>Open</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {open && typeof document !== "undefined" && createPortal(
        <CardModal card={open} people={people} accent={accent} onClose={() => setOpenKey(null)} onSave={(patch) => save(open.key, patch)} />,
        document.body,
      )}
    </div>
  );
}

function CardModal({ card, people, accent, onClose, onSave }: { card: DocCard; people: PlanPerson[]; accent: string; onClose: () => void; onSave: (patch: { owner?: string; leads?: string[]; status?: string; update?: string }) => Promise<void> }) {
  const [owner, setOwner] = useState(card.owner ?? "");
  const [lead1, setLead1] = useState(card.leads?.[0] ?? "");
  const [lead2, setLead2] = useState(card.leads?.[1] ?? "");
  const [status, setStatus] = useState(card.status ?? "");
  const [update, setUpdate] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") { e.stopPropagation(); onClose(); } };
    window.addEventListener("keydown", onKey, true);
    const prev = document.body.style.overflow; document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey, true); document.body.style.overflow = prev; };
  }, [onClose]);
  const options = (v: string, set: (x: string) => void, allowNone: boolean) => (
    <select className={d.select} value={v} onChange={(e) => set(e.target.value)}>
      {allowNone && <option value="">Unassigned</option>}
      {people.map((p) => <option key={p.key} value={p.key}>{p.name}{p.role ? `, ${p.role}` : ""}</option>)}
    </select>
  );
  const submit = async () => {
    setBusy(true); setErr("");
    try {
      await onSave({ owner: owner || undefined, leads: [lead1, lead2].filter(Boolean), status: status.trim() || undefined, update: update.trim() || undefined });
      onClose();
    } catch (e) { setErr(e instanceof Error ? e.message : String(e)); } finally { setBusy(false); }
  };
  const log = [...(card.updates ?? [])].sort((a, b) => (a.at < b.at ? 1 : -1));
  return (
    <div className={d.modalBack} onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }} style={{ ["--cardc" as string]: accent }}>
      <div className={d.modal} role="dialog" aria-modal="true" aria-label={card.title}>
        <div className={d.modalHead}>
          <div>
            <div className={d.modalTitle}>{card.title}</div>
            <div className={d.cardSub}>{card.code ?? "No Project Code"} · {card.practice ?? ""} · Goal {dollars(card.goal)}</div>
            {card.link && <a className={d.modalLink} href={card.link.href} target="_blank" rel="noreferrer">{card.link.label}</a>}
          </div>
          <button type="button" className={d.modalClose} onClick={onClose}>Close</button>
        </div>
        <div className={d.modalGrid}>
          <label className={d.field}><span className={d.fieldK}>Brings In</span>{options(owner, setOwner, true)}</label>
          <label className={d.field}><span className={d.fieldK}>Leads The Work</span>{options(lead1, setLead1, true)}</label>
          <label className={d.field}><span className={d.fieldK}>Also Leads</span>{options(lead2, setLead2, true)}</label>
          <label className={d.field}><span className={d.fieldK}>Status, One Line</span><input className={d.input} value={status} onChange={(e) => setStatus(e.target.value)} placeholder="The pithy line on the card" maxLength={160} /></label>
        </div>
        <label className={d.field}><span className={d.fieldK}>Update</span><textarea className={d.textarea} value={update} onChange={(e) => setUpdate(e.target.value)} placeholder="What happened, in your words. Lumen reads these and writes the one-line status." /></label>
        <div className={d.modalFoot}>
          <span className={d.modalNote}>{err || (busy ? "Saving…" : "Saves to the Ledger; everyone reading this page sees it.")}</span>
          <button type="button" className={d.saveBtn} onClick={submit} disabled={busy}>Save</button>
        </div>
        {log.length > 0 && (
          <div className={d.log}>
            <span className={d.fieldK}>Updates</span>
            {log.map((u, i) => <div key={i} className={d.logItem}><span className={d.logAt}>{fmtAt(u.at)}{u.by ? ` · ${u.by}` : ""}</span><span>{u.text}</span></div>)}
          </div>
        )}
      </div>
    </div>
  );
}

type PlanView = "strategy" | "ops" | "budget";
const PLAN_VIEWS: { id: PlanView; label: string }[] = [
  { id: "strategy", label: "Strategy" },
  { id: "ops", label: "Operations" },
  { id: "budget", label: "Budget" },
];
const dollars = (x: number) => `$${Math.round(x).toLocaleString("en-US")}`;
const planDate = (iso?: string) => (iso ? new Date(iso + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "");
const sumBig = (big?: PlanBig[]) => (big ?? []).reduce((a, b) => a + (b.cost ?? 0), 0);

function PlanNode({ n, pulse, size = 28, color }: { n: React.ReactNode; pulse?: boolean; size?: number; color?: string }) {
  return <span className={`${d.planNode}${pulse ? ` ${d.planPulse}` : ""}`} style={{ width: size, height: size, fontSize: size * 0.43, ...(color ? { ["--nodec" as string]: color } : {}) }}>{n}</span>;
}
const FlagGlyph = () => <svg width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 22V3M5 4h12l-2 4 2 4H5" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" /></svg>;
const Open = ({ text }: { text?: string }) => (text ? <>{text}</> : <span className={d.planOpen}>Open</span>);
/** The owner's small face in a circle, titled with the name; nothing when the line has no owner. */
function Face({ who, size = 22 }: { who?: PlanPerson; size?: number }) {
  if (!who) return null;
  if (!who.src) return <span className={d.capInitial} style={{ width: size, height: size, fontSize: Math.round(size * 0.42) }} title={who.name}>{who.name.split(" ").map((w) => w[0]).join("").slice(0, 2)}</span>;
  // eslint-disable-next-line @next/next/no-img-element
  return <img className={d.planFace} src={who.src} alt={who.name} title={`${who.name}${who.role ? `, ${who.role}` : ""}`} width={size} height={size} />;
}

function Plan({ block }: { block: DocPlan }) {
  const [view, setView] = useState<PlanView>("strategy");
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const strategy = view === "strategy", ops = view === "ops", budget = view === "budget";
  const total = block.truths.reduce((a, t) => a + sumBig(t.big), 0) + sumBig(block.final?.big);
  const person = (key?: string) => (key ? block.people?.find((p) => p.key === key) : undefined);
  // A moment is one node on the spine. Consecutive truths with the same label and anchor share it and run in parallel.
  const moments: { start: number; truths: PlanTruth[] }[] = [];
  block.truths.forEach((t, i) => {
    const last = moments[moments.length - 1];
    if (last && last.truths[0].label === t.label && last.truths[0].anchor === t.anchor) last.truths.push(t);
    else moments.push({ start: i, truths: [t] });
  });

  const tree = (t: { big?: PlanBig[] }, n: string) =>
    (t.big?.length ?? 0) > 0 ? (
      <div className={d.planTree}>
        {t.big!.map((b, m) => (
          <div key={m} className={d.planLeaf}>
            <span className={d.planKey}>{n}.{m + 1}</span>
            <Face who={person(b.owner)} />
            <span className={d.planLeafText}>{b.text}</span>
          </div>
        ))}
      </div>
    ) : null;

  const grid = (t: { big?: PlanBig[] }, n: string) => (
    <div className={`${d.planGrid}${budget ? ` ${d.planGridBudget}` : ""}`}>
      {ops && <span />}<span />
      <span className={d.planEyebrow}>The Big Things That Have To Happen</span>
      <span className={d.planEyebrow}>Accountable</span>
      {budget && <span className={`${d.planEyebrow} ${d.planRight}`}>Cost</span>}
      {(t.big ?? []).map((b, m) => {
        const key = `${n}.${m + 1}`;
        const more = !!(b.people || b.dataCosts || (b.tasks && b.tasks.length));
        return (
          <React.Fragment key={m}>
            {ops && (
              <button type="button" className={`${d.planChev}${open[key] ? ` ${d.planChevOpen}` : ""}`} aria-expanded={!!open[key]} title={open[key] ? "Fold" : "Open to people, data-related costs and tasks"} onClick={() => setOpen((o) => ({ ...o, [key]: !o[key] }))}>
                <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M4 2l4 4-4 4" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </button>
            )}
            <span className={d.planKey}>{key}</span>
            <span className={`${d.planCell} ${d.planWithFace}`}><Face who={person(b.owner)} />{b.text}</span>
            <span className={`${d.planCell} ${d.planName} ${d.planWithFace}`}>{b.accountable ? b.accountable : person(b.owner) ? <><Face who={person(b.owner)} />{person(b.owner)!.name}</> : <span className={d.planOpen}>Open</span>}</span>
            {budget && <span className={`${d.planCell} ${d.planRight} ${d.planMoney}`}>{b.cost != null ? dollars(b.cost) : <span className={d.planOpen}>Open</span>}</span>}
            {ops && open[key] && (
              <div className={d.planMore}>
                <div className={d.planMoreGrid}>
                  <div><span className={d.planEyebrow}>People</span><div className={d.planCell}><Open text={b.people} /></div></div>
                  <div><span className={d.planEyebrow}>Data-Related Costs</span><div className={d.planCell}><Open text={b.dataCosts} /></div></div>
                </div>
                <div className={d.planTasks}>
                  <span className={d.planEyebrow}>Task</span><span className={d.planEyebrow}>Who</span><span className={d.planEyebrow}>Due</span><span className={`${d.planEyebrow} ${d.planCenter}`}>Done</span>
                  {(b.tasks ?? []).length === 0 && <span className={`${d.planOpen} ${d.planSpan}`}>No tasks yet</span>}
                  {(b.tasks ?? []).map((k, j) => (
                    <React.Fragment key={j}>
                      <span className={`${d.planCell}${k.done ? ` ${d.planDone}` : ""}`}>{k.text}</span>
                      <span className={d.planCell}><Open text={k.owner} /></span>
                      <span className={d.planCell}>{k.due ? planDate(k.due) : <span className={d.planOpen}>Open</span>}</span>
                      <span className={`${d.planCell} ${d.planCenter}`}>{k.done ? "✓" : "·"}</span>
                    </React.Fragment>
                  ))}
                </div>
                {!more && <span className={d.planOpen}>People, data-related costs and tasks are open for this big thing.</span>}
              </div>
            )}
          </React.Fragment>
        );
      })}
      {(t.big ?? []).length === 0 && <span className={`${d.planOpen} ${d.planSpan}`}>No big things keyed yet.</span>}
      {budget && (t.big ?? []).length > 0 && <><span className={d.planSpanBut} /><span className={`${d.planEyebrow} ${d.planRight} ${d.planAccent}`}>Subtotal · {dollars(sumBig(t.big))}</span></>}
    </div>
  );

  const body = (t: PlanTruth | NonNullable<DocPlan["final"]>, n: string, isFinal: boolean, keyed = false) =>
    strategy ? (
      <div className={d.planStatement}>
        <div className={`${d.planText}${t.text ? "" : ` ${d.planTextOpen}`} ${d.planWithFace}`}>{keyed ? <PlanNode n={n} size={22} /> : null}{"owner" in t ? <Face who={person(t.owner)} size={26} /> : null}{t.text ?? (isFinal ? "The one statement that is true of the whole plan at the end. Open." : "Open.")}</div>
        {tree(t, n)}
      </div>
    ) : (
      <div className={d.planCard}>
        <div className={d.planCardHead}>
          <PlanNode n={isFinal ? <FlagGlyph /> : n} size={22} />
          <div className={`${d.planText} ${d.planTextCard}${t.text ? "" : ` ${d.planTextOpen}`}`}>{t.text ?? "Open."}</div>
        </div>
        <div>
          <span className={d.planEyebrow}>How We Measure It Being True</span>
          <div className={d.planCell}><Open text={t.measure} /></div>
        </div>
        <div className={d.planCardGrid}>{grid(t, n)}</div>
      </div>
    );

  return (
    <div className={d.planBlock}>
      <div className={d.planHead}>
        <span className={d.planBadge}>{block.code ?? "P"}</span>
        <div>
          {block.code && <div className={d.planCode}>{block.code} · Plan</div>}
          <div className={d.planName}>{block.name}</div>
        </div>
      </div>
      <div className={d.planViews}>
        {PLAN_VIEWS.map((v) => (
          <button key={v.id} type="button" className={`${d.planPill}${view === v.id ? ` ${d.planPillOn}` : ""}`} aria-pressed={view === v.id} onClick={() => setView(v.id)}>{v.label}</button>
        ))}
        {budget && <span className={d.planTotal}>Total · {dollars(total)}</span>}
      </div>
      <div className={d.planLegend}>
        <span><PlanNode n="1" size={22} /><span className={d.planLegendSerif}>What Must Be True</span></span>
        <span><span className={d.planKey}>1.1</span><span>The Big Things That Have To Happen</span></span>
        <span><PlanNode n={<FlagGlyph />} size={22} /><span className={d.planLegendSerif}>Final</span></span>
      </div>

      <div className={d.planSpine}>
        <div className={`${d.planRail} ${d.planRailFirst}`}>
          <span className={d.planNodeSlot}><PlanNode n="★" pulse /></span>
          <span className={`${d.planEyebrow} ${d.planAccent}`}>Polaris</span>
          {block.horizon && <span className={d.planWhen}>{block.horizon}</span>}
        </div>
        <div className={d.planBody}>
          {strategy ? (
            <div className={`${d.planPolaris}${block.polaris ? "" : ` ${d.planTextOpen}`}`}>{block.polaris ?? "At the end of the plan, Third Horizon will have… Open."}</div>
          ) : (
            <div className={`${d.planCard} ${d.planCardTint}`}>
              <span className={d.planEyebrow}>Polaris Objective</span>
              <div className={`${d.planPolaris} ${d.planTextCard}${block.polaris ? "" : ` ${d.planTextOpen}`}`}>{block.polaris ?? "Open."}</div>
            </div>
          )}
        </div>

        {moments.map((m) => {
          const t = m.truths[0];
          const n = String(m.start + 1);
          const shared = m.truths.length > 1;
          const range = shared ? `${m.start + 1}-${m.start + m.truths.length}` : n;
          return (
            <React.Fragment key={m.start}>
              <div className={d.planRail}>
                <span className={d.planNodeSlot}><PlanNode n={range} size={shared ? 34 : 28} /></span>
                <span className={d.planLabel}>{t.label}</span>
                {t.anchor && <span className={d.planWhen}>{planDate(t.anchor)}</span>}
                {shared && <span className={d.planWhen}>{m.truths.length} in parallel</span>}
              </div>
              <div className={d.planBody}>
                {!shared ? body(t, n, false) : strategy ? (
                  <div className={d.planMoment}>
                    <div>{body(t, n, false, true)}</div>
                    <div className={d.planMomentRest}>
                      {m.truths.slice(1).map((u, j) => <div key={j}>{body(u, String(m.start + j + 2), false, true)}</div>)}
                    </div>
                  </div>
                ) : (
                  <div className={d.planStack}>
                    {m.truths.map((u, j) => <div key={j}>{body(u, String(m.start + j + 1), false)}</div>)}
                  </div>
                )}
              </div>
            </React.Fragment>
          );
        })}

        <div className={`${d.planRail} ${d.planRailLast}`}>
          <span className={d.planNodeSlot}><PlanNode n={<FlagGlyph />} pulse /></span>
          <span className={`${d.planEyebrow} ${d.planAccent}`}>Final</span>
          {block.horizon && <span className={d.planWhen}>{block.horizon}</span>}
        </div>
        <div className={d.planBody}>{body(block.final ?? {}, "F", true)}</div>
      </div>
      {block.source && <p className={d.source}>{block.source}</p>}
    </div>
  );
}
