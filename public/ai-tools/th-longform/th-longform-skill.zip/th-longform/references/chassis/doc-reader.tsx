"use client";

// The document reader (10/25): the long-form layout beside the deck. The bar
// and the standing contents rail are the deck's own (same classes from
// exec-slides.module.css); the right side is a scrolling page of blocks with a
// Next at the very foot. ?s= addresses the page, 1-based, as the deck's does,
// so the unlock redirect and deep links behave the same way.

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import type { DocBlock, DocChart, DocPage, DocRow, DocTable } from "@/content/doc";
import s from "@/components/executive/exec-slides.module.css";
import d from "./doc.module.css";

const LEGAL = "Not for Distribution · Confidential & Proprietary Information · Third Horizon";

function em(text: string) {
  const parts = text.split(/\*([^*]+)\*/g);
  if (parts.length === 1) return text;
  return parts.map((chunk, n) => (n % 2 === 1 ? <em key={n}>{chunk}</em> : chunk));
}

// Table and chart cells read in whole dollars; the notes carry the cents.
const money = (x: number) => {
  const r = Math.round(x);
  return r < 0 ? `(${Math.abs(r).toLocaleString("en-US")})` : r.toLocaleString("en-US");
};
const k = (x: number) => `$${Math.round(x / 1000).toLocaleString("en-US")}K`;

export function DocReader({ pages, closeHref, basePath, label }: { pages: DocPage[]; closeHref: string; basePath: string; label: string }) {
  const router = useRouter();
  const params = useSearchParams();
  const raw = Number(params.get("s") ?? 1);
  const i = Number.isFinite(raw) ? Math.min(Math.max(Math.round(raw), 1), pages.length) - 1 : 0;
  const page = pages[i];
  const mainRef = useRef<HTMLElement | null>(null);

  const go = useCallback(
    (next: number) => {
      const clamped = Math.min(Math.max(next, 0), pages.length - 1);
      router.replace(`${basePath}?s=${clamped + 1}`, { scroll: false });
    },
    [router, pages.length, basePath],
  );

  // A new page opens at its top, on the desktop column and on a phone's window alike.
  useEffect(() => {
    mainRef.current?.scrollTo({ top: 0 });
    window.scrollTo(0, 0);
  }, [i]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.isContentEditable || t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT")) return;
      if (e.key === "ArrowRight") go(i + 1);
      else if (e.key === "ArrowLeft") go(i - 1);
      else if (e.key === "Escape") router.push(closeHref);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [i, go, router, closeHref]);

  // Rail, dropdown and the foot buttons read the title plain; the italic marks belong to the page head alone.
  const pageName = (p: DocPage) => (p.cover ? p.cover.heading : p.title.replace(/\*/g, ""));

  return (
    <div className={d.wrap}>
      <header className={`${s.bar} ${d.bar}`}>
        <div className={s.brand}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/brand/th-arches-white.png" alt="" className={s.arches} />
          <span className={s.mark}>Third Horizon</span>
          <span className={s.label}>{label}</span>
        </div>
        <div className={s.barActions}>
          <Link href={closeHref} className={s.close}>Close</Link>
        </div>
      </header>

      <div className={s.mobileNav}>
        <label htmlFor="document-page">Contents</label>
        <select id="document-page" value={i} onChange={(event) => go(Number(event.target.value))}>
          {pages.map((p, n) => (
            <option key={p.slug} value={n}>{p.ref ? `${p.ref}. ` : ""}{pageName(p)}</option>
          ))}
        </select>
      </div>

      <aside className={`${s.rail} ${s.railSpine} ${d.rail}`} aria-label="Contents">
        <div className={s.railTitle}>Contents</div>
        {pages.map((p, n) => (
          <div key={p.slug} className={`${s.railAct} ${s.railActLeaf}${n === i ? ` ${s.railActOn}` : n < i ? ` ${s.railActSeen}` : ""}`}>
            <button type="button" className={`${s.railHead}${n === i ? ` ${s.railCurrent}` : ""}`} onClick={() => go(n)}>
              <span className={s.railNo}>{p.ref}</span>
              <span className={s.railName}>{pageName(p)}</span>
            </button>
          </div>
        ))}
        <div className={s.railFoot}>
          <span className={s.railPos}>{i + 1} of {pages.length}</span>
          <span className={s.railBar} aria-hidden="true"><i style={{ width: `${((i + 1) / pages.length) * 100}%` }} /></span>
          <span className={s.railLegal}>{LEGAL}</span>
        </div>
      </aside>

      <main className={d.main} ref={mainRef} key={page.slug}>
        <article className={`${d.page}${page.cover ? ` ${d.pageCover}` : ""}`}>
          {page.cover ? (
            <div className={d.cover}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/brand/th-arches-white.png" alt="" className={d.coverArches} />
              <div className={d.coverMark}>Third Horizon</div>
              {page.kicker && <div className={d.coverKicker}>{page.kicker}</div>}
              <h1 className={d.coverHeading}>{page.cover.heading}</h1>
              {page.cover.sub && <p className={d.coverSub}>{em(page.cover.sub)}</p>}
              <span className={d.coverRule} aria-hidden="true" />
              <div className={d.coverNote}>{page.cover.note}</div>
              <div className={d.coverDate}>{page.cover.date}</div>
            </div>
          ) : (
            <>
              {page.kicker && <div className={d.kicker}>{page.kicker}</div>}
              <h1 className={d.title}>{em(page.title)}</h1>
            </>
          )}

          {page.blocks.map((block, n) => (
            <Block key={n} block={block} pages={pages} go={go} />
          ))}

          <nav className={d.pageNav} aria-label="Pages">
            {i > 0 && !page.cover && (
              <button type="button" className={d.prev} onClick={() => go(i - 1)}>
                <span className={d.tri}><svg width="12" height="14" viewBox="0 0 29.4 34" aria-hidden="true"><polygon points="29.4,0 29.4,34 0,17" /></svg></span>
                <span><span className={d.navK}>Previous</span><br /><span className={d.navT}>{pageName(pages[i - 1])}</span></span>
              </button>
            )}
            {i < pages.length - 1 ? (
              <button type="button" className={d.next} onClick={() => go(i + 1)}>
                <span><span className={d.navK}>{page.cover ? "Begin" : "Next"}{pages[i + 1].ref ? ` · ${pages[i + 1].ref}` : ""}</span><br /><span className={d.navT}>{pageName(pages[i + 1])}</span></span>
                <span className={d.tri}><svg width="12" height="14" viewBox="0 0 29.4 34" aria-hidden="true"><polygon points="0,0 0,34 29.4,17" /></svg></span>
              </button>
            ) : (
              <span className={d.end}>End of the document, for now</span>
            )}
          </nav>
          <div className={d.foot}>
            <span>{LEGAL}</span>
            <span>{label} · {page.ref ? `Page ${page.ref}` : "Cover"}</span>
          </div>
        </article>
      </main>
    </div>
  );
}

function Block({ block, pages, go }: { block: DocBlock; pages: DocPage[]; go: (n: number) => void }) {
  switch (block.kind) {
    case "lead":
      return (
        <p className={`${s.para} ${s.paraFirst} ${d.lead}`}>
          <strong className={s.paraBold}>{block.bold}</strong> {em(block.text)}
        </p>
      );
    case "para":
      return <p className={`${s.para} ${d.para}`}>{em(block.text)}</p>;
    case "h2":
      return <h2 className={d.h2}>{em(block.text)}</h2>;
    case "list":
      return (
        <ul className={d.list}>
          {block.items.map((it, n) => <li key={n}>{em(it)}</li>)}
        </ul>
      );
    case "callout":
      return (
        <aside className={d.callout}>
          {block.eyebrow && <div className={d.calloutEyebrow}>{block.eyebrow}</div>}
          <p className={d.calloutText}>{em(block.text)}</p>
        </aside>
      );
    case "stats":
      return (
        <div className={d.stats}>
          {block.items.map((st) => (
            <div key={st.k} className={`${d.stat}${st.tone === "pos" ? ` ${d.statPos}` : st.tone === "neg" ? ` ${d.statNeg}` : ""}`}>
              <div className={d.statK}>{st.k}</div>
              <div className={d.statV}>{st.v}</div>
              {st.sub && <div className={d.statSub}>{st.sub}</div>}
            </div>
          ))}
        </div>
      );
    case "table":
      return <Table block={block} />;
    case "chart":
      return <Chart block={block} />;
    case "source":
      return <p className={d.source}>{block.text}</p>;
    case "document":
      return (
        <a className={d.docCard} href={block.href} target="_blank" rel="noopener noreferrer">
          <span className={d.docIcon} aria-hidden="true" />
          <span>
            <div className={d.docTitle}>{block.title}</div>
            {block.sub && <div className={d.docSub}>{block.sub}</div>}
            {block.note && <div className={d.docNote}>{block.note}</div>}
          </span>
          <svg className={d.docArrow} viewBox="0 0 12 12" width="12" height="12" aria-hidden="true"><path d="M3 1h8v8M11 1 1 11" fill="none" stroke="currentColor" strokeWidth="1.6" /></svg>
        </a>
      );
    case "contents":
      return (
        <div className={d.toc}>
          <div className={d.tocTitle}>Contents</div>
          {pages.map((p, n) => p.cover ? null : (
            <button key={p.slug} type="button" className={d.tocItem} onClick={() => go(n)}>
              <span>{p.title.replace(/\*/g, "")}</span>
              <span className={d.tocRef}>{p.ref}</span>
            </button>
          ))}
        </div>
      );
    default:
      return null;
  }
}

/* ---- the table: rows expand to their lines, totals open their reading ---- */
function Table({ block }: { block: DocTable }) {
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [note, setNote] = useState<Record<string, boolean>>({});
  const cols = block.columns.length + (block.totalLabel ? 1 : 0) + 1;
  const cell = (v: number | null | undefined, tot = false) => (
    <td className={`${(v ?? 0) < 0 ? d.neg : ""}${tot ? ` ${d.tot}` : ""}`}>{v == null ? "" : money(v)}</td>
  );
  const renderRow = (r: DocRow, depth = 0): React.ReactNode => {
    const key = `${depth}:` + r.label + (r.sub ?? "");
    const canOpen = !!(r.children && r.children.length);
    const canAsk = !!r.note;
    const cls = depth > 0 ? d.child : r.style ? d[r.style] : "";
    return (
      <>
        <tr key={key} className={cls}>
          <td style={depth > 0 ? { paddingLeft: 24 + depth * 22 } : undefined}>
            {canOpen || canAsk ? (
              <button
                type="button"
                className={d.rowBtn}
                aria-expanded={canOpen ? !!open[key] : undefined}
                onClick={() => (canOpen ? setOpen((o) => ({ ...o, [key]: !o[key] })) : setNote((o) => ({ ...o, [key]: !o[key] })))}
              >
                {canOpen && <span className={`${d.chev}${open[key] ? ` ${d.chevOpen}` : ""}`} aria-hidden="true" />}
                <span>{r.label}{r.sub && <span className={d.childSub}>{r.sub}</span>}</span>
                {!canOpen && canAsk && <span className={`${d.ask}${note[key] ? ` ${d.askOn}` : ""}`} aria-hidden="true">i</span>}
              </button>
            ) : (
              <span>{r.label}{r.sub && <span className={d.childSub}>{r.sub}</span>}</span>
            )}
          </td>
          {r.cells.map((v, n) => <CellFrag key={n} v={v} />)}
          {block.totalLabel ? cell(r.total, true) : null}
        </tr>
        {canOpen && open[key] && r.children!.map((c) => <CellRow key={`${depth + 1}:` + c.label + (c.sub ?? "")} row={c} depth={depth + 1} render={renderRow} />)}
        {canAsk && note[key] && (
          <tr key={key + ":note"} className={d.noteRow}><td colSpan={cols}><div className={d.noteInner}>{em(r.note!)}</div></td></tr>
        )}
      </>
    );
  };
  return (
    <div className={d.tableBlock}>
      {block.caption && <div className={d.caption}>{block.caption}</div>}
      <div className={d.tableWrap}>
        <table className={d.table}>
          <thead>
            <tr>
              <th />
              {block.columns.map((c) => <th key={c}>{c}</th>)}
              {block.totalLabel && <th>{block.totalLabel}</th>}
            </tr>
            {block.columnSubs && (
              <tr className={d.sub}>
                <th />
                {block.columnSubs.map((c, n) => <th key={n}>{c}</th>)}
                {block.totalLabel && <th />}
              </tr>
            )}
          </thead>
          <tbody>
            {block.rows.map((r) => <CellRow key={"0:" + r.label + (r.sub ?? "")} row={r} depth={0} render={renderRow} />)}
          </tbody>
        </table>
      </div>
      {block.expandHint && <div className={d.expandHint}>{block.expandHint}</div>}
      {block.source && <p className={d.source}>{block.source}</p>}
    </div>
  );
}

function CellFrag({ v }: { v: number | null }) {
  if (v == null) return <td />;
  if (Math.round(v) === 0) return <td className={d.zero}>·</td>;
  return <td className={v < 0 ? d.neg : undefined}>{money(v)}</td>;
}

function CellRow({ row, depth, render }: { row: DocRow; depth: number; render: (r: DocRow, depth?: number) => React.ReactNode }) {
  return <>{render(row, depth)}</>;
}

/* ---- the chart: grouped bars by month, a net strip beneath, hover to read ---- */
function Chart({ block }: { block: DocChart }) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 1000, H = 300, L = 88, R = 16, T = 18, B = 70;
  const n = block.categories.length;
  const max = useMemo(() => {
    const m = Math.max(...block.bars.flatMap((b) => b.values));
    const step = m > 500000 ? 200000 : m > 100000 ? 50000 : 10000;
    return Math.ceil(m / step) * step;
  }, [block.bars]);
  const step = max > 500000 ? 200000 : max > 100000 ? 50000 : 10000;
  const ticks: number[] = [];
  for (let v = 0; v <= max; v += step) ticks.push(v);
  const plotW = W - L - R, plotH = H - T - B;
  const slot = plotW / n;
  const bw = Math.min(26, (slot * 0.62) / block.bars.length);
  const y = (v: number) => T + plotH - (v / max) * plotH;
  const tone = (t: DocChart["bars"][number]["tone"]) =>
    t === "accent" ? "var(--th-accent-bright)" : t === "gold" ? "var(--th-gold)" : t === "pos" ? "var(--th-pos)" : t === "neg" ? "var(--th-neg)" : "rgba(243,241,234,0.34)";
  const fmt = (v: number) => (block.unit === "n" ? v.toLocaleString("en-US") : `$${money(v)}`);
  const tipX = hover == null ? 0 : ((L + slot * hover + slot / 2) / W) * 100;
  return (
    <div className={d.chartBlock}>
      {block.title && <div className={d.caption}>{block.title}</div>}
      <div className={d.legend}>
        {block.bars.map((b) => <span key={b.name}><i style={{ background: tone(b.tone) }} />{b.name}</span>)}
        {block.line && <span><i style={{ background: "linear-gradient(90deg, var(--th-pos) 50%, var(--th-neg) 50%)" }} />{block.line.name}</span>}
      </div>
      <div style={{ position: "relative" }} onMouseLeave={() => setHover(null)}>
        <svg className={d.chartSvg} viewBox={`0 0 ${W} ${H}`} role="img" aria-label={block.title ?? "Chart"}>
          {ticks.map((v) => (
            <g key={v}>
              <line className={v === 0 ? d.baseline : d.grid} x1={L} x2={W - R} y1={y(v)} y2={y(v)} />
              <text className={d.axis} x={L - 10} y={y(v) + 4} textAnchor="end">{v === 0 ? "0" : k(v)}</text>
            </g>
          ))}
          {block.categories.map((c, m) => {
            const x0 = L + slot * m;
            const groupW = bw * block.bars.length + 4 * (block.bars.length - 1);
            const gx = x0 + (slot - groupW) / 2;
            return (
              <g key={c} onMouseEnter={() => setHover(m)}>
                <rect className={`${d.hit}${hover === m ? ` ${d.hitOn}` : ""}`} x={x0} y={T} width={slot} height={plotH + B - 8} />
                {block.bars.map((b, bi) => (
                  <rect key={b.name} x={gx + bi * (bw + 4)} y={y(b.values[m])} width={bw} height={Math.max(0, y(0) - y(b.values[m]))} fill={tone(b.tone)} opacity={hover == null || hover === m ? 1 : 0.55} />
                ))}
                <text className={d.month} x={x0 + slot / 2} y={H - B + 24} textAnchor="middle">{c}</text>
                {block.line && (
                  <text className={d.strip} x={x0 + slot / 2} y={H - B + 48} textAnchor="middle" fill={block.line.values[m] < 0 ? "var(--th-neg)" : "var(--th-pos)"}>
                    {money(block.line.values[m])}
                  </text>
                )}
              </g>
            );
          })}
          {block.line && <text className={d.stripLabel} x={L - 10} y={H - B + 48} textAnchor="end">{block.line.name}</text>}
        </svg>
        {hover != null && (
          <div className={d.tip} style={{ left: `${tipX}%`, top: `${(T / H) * 100}%` }}>
            <div className={d.tipK}>{block.categories[hover]}</div>
            {block.bars.map((b) => <div key={b.name}><span>{b.name}</span><b>{fmt(b.values[hover])}</b></div>)}
            {block.line && <div><span>{block.line.name}</span><b style={{ color: block.line.values[hover] < 0 ? "var(--th-neg)" : "var(--th-pos)" }}>{fmt(block.line.values[hover])}</b></div>}
          </div>
        )}
      </div>
      {block.caption && <p className={d.source}>{block.caption}</p>}
    </div>
  );
}
