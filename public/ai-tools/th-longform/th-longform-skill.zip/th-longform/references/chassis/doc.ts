// =============================================================================
// DOCUMENT KINDS (10/25) — the long-form layout beside the deck. A document
// proposal is a sequence of pages the reader scrolls, each a run of blocks
// (prose, tables, charts, documents, stats) with a Next at the very foot of
// the page and the same contents rail as the deck on the left. Born on the
// Company Finance Review (David 10/25: "a hybrid word document with next
// buttons at the very bottom of a page, long form, prose-anchored, but with
// graphs, tables, documents, etc.").
//
// Text fields accept *italics* between asterisks, as the deck's withEm does.
// =============================================================================

export type DocStat = { k: string; v: string; sub?: string; tone?: "pos" | "neg" };

/** A table row. cells carry one value per column; total is the trailing
 *  summary column when the table has one. children expand beneath a row on
 *  click (a practice area opening to its client lines). note opens the row's
 *  reasoning beneath it (every figure the reader can click, the canon). */
export type DocRow = {
  label: string;
  sub?: string;
  cells: (number | null)[];
  total?: number | null;
  style?: "indent" | "total" | "net" | "final";
  note?: string;
  children?: DocRow[];
  /** A short chip beside the label (Assumption, Yellow in the sheet). */
  flag?: string;
};

export type DocTable = {
  kind: "table";
  id: string;
  caption?: string;
  columns: string[];
  /** A second header line under the columns (Actual, Projected). */
  columnSubs?: string[];
  totalLabel?: string;
  rows: DocRow[];
  source?: string;
  /** The hint under the table when rows expand. */
  expandHint?: string;
};

export type DocChart = {
  kind: "chart";
  id: string;
  title?: string;
  categories: string[];
  bars: { name: string; values: number[]; tone: "accent" | "gold" | "pos" | "neg" | "mid" }[];
  /** A line over the bars (net income), read on the same axis. */
  line?: { name: string; values: number[] };
  caption?: string;
  /** Format values as dollars (default) or plain numbers. */
  unit?: "$" | "n";
  /** Categories from this index on are estimates: drawn lighter, behind a divider. */
  estimateFrom?: number;
  estimateLabel?: string;
};

export type DocBlock =
  | { kind: "lead"; bold: string; text: string }
  | { kind: "para"; text: string }
  | { kind: "h2"; text: string }
  | { kind: "list"; items: string[] }
  | { kind: "callout"; eyebrow?: string; text: string }
  | { kind: "stats"; items: DocStat[] }
  | DocTable
  | DocChart
  | { kind: "source"; text: string }
  /** A document the page carries: a file or a live surface, opened in a new tab. */
  | { kind: "document"; title: string; href: string; sub?: string; note?: string }
  /** The cover's list of pages, rendered from the page array. */
  | { kind: "contents" };

export type DocPage = {
  slug: string;
  /** The page number as shown ("1"); the cover carries "". */
  ref: string;
  title: string;
  /** Mono eyebrow above the title. */
  kicker?: string;
  /** Present on the cover page only: the big centered composition. */
  cover?: { heading: string; sub?: string; note: string; date: string };
  blocks: DocBlock[];
};
