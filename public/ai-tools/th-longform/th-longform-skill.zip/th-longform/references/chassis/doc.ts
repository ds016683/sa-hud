// =============================================================================
// DOCUMENT KINDS (10/25) — the long-form layout beside the deck. A document
// document is a sequence of pages the reader scrolls, each a run of blocks
// (prose, tables, charts, documents, stats) with a Next at the very foot of
// the page and the same contents rail as the deck on the left. Born on the
// Company Finance Review (David 10/25: "a hybrid word document with next
// buttons at the very bottom of a page, long form, prose-anchored, but with
// graphs, tables, documents, etc.").
//
// Text fields accept *italics* between asterisks, as the deck's withEm does.
// =============================================================================

export type DocStat = { k: string; v: string; sub?: string; tone?: "pos" | "neg" };

/** A table row. cells carry one value per column; total is the trailing
 *  summary column when the table has one. children expand beneath a row on
 *  click (a practice area opening to its client lines). note opens the row's
 *  reasoning beneath it (every figure the reader can click, the canon). */
export type DocRow = {
  label: string;
  sub?: string;
  cells: (number | null)[];
  total?: number | null;
  style?: "indent" | "total" | "net" | "final" | "assume";
  note?: string;
  children?: DocRow[];
  /** A short chip beside the label (Assumption, Yellow in the sheet). */
  flag?: string;
};

export type DocTable = {
  kind: "table";
  id: string;
  caption?: string;
  columns: string[];
  /** A second header line under the columns (Actual, Projected). */
  columnSubs?: string[];
  totalLabel?: string;
  /** Header of the code column, drawn when any row carries a `sub` (default "Project Code"). */
  codeLabel?: string;
  rows: DocRow[];
  source?: string;
  /** The hint under the table when rows expand. */
  expandHint?: string;
  /** Dots explained under the caption (a purple dot marks an assumption on the sheet). */
  legend?: { color: string; text: string }[];
};

export type DocChart = {
  kind: "chart";
  id: string;
  title?: string;
  categories: string[];
  bars: { name: string; values: number[]; tone: "accent" | "gold" | "pos" | "neg" | "mid" }[];
  /** A line over the bars (net income), read on the same axis. */
  line?: { name: string; values: number[] };
  caption?: string;
  /** Format values as dollars (default) or plain numbers. */
  unit?: "$" | "n";
  /** Categories from this index on are estimates: drawn lighter, behind a divider. */
  estimateFrom?: number;
  estimateLabel?: string;
};


/** A plan on a spine (10/31, the Micro): the shape of the Mission Card's domain
 *  flow carried onto a document page. Polaris at the head; the things that
 *  must be true at key moments down the spine, each with the big things that
 *  have to happen beneath it; a Final under a flag at the foot. Three views on
 *  the one spine: Strategy reads the statements, Operations adds the working
 *  fields (how it is measured, who is accountable, people, data-related costs,
 *  tasks), Budget prices each big thing and adds up. */
/** A person who can own a line: key, name, and the small face under public/people/. */
export type PlanPerson = { key: string; name: string; role?: string; /** The face; without one the reader draws initials. */ src?: string };
export type PlanTask = { text: string; owner?: string; due?: string; done?: boolean };
export type PlanBig = { text: string; /** The owner's person key: a small face sits between the key and the text. */ owner?: string; accountable?: string; people?: string; dataCosts?: string; cost?: number; tasks?: PlanTask[] };
export type PlanTruth = { label: string; anchor?: string; owner?: string; text: string; measure?: string; big?: PlanBig[] };
export type DocPlan = {
  kind: "plan";
  id: string;
  /** The mono code and the serif name over the spine. */
  code?: string;
  name: string;
  /** Under the Polaris and Final nodes (End Of 2027). */
  horizon?: string;
  polaris?: string;
  /** The people who can own a line on this plan. */
  people?: PlanPerson[];
  truths: PlanTruth[];
  final?: { text?: string; measure?: string; big?: PlanBig[] };
  source?: string;
};

/** A plan on one line (11/1): big rocks only, each a dated point on a vertical line; the
 *  detail behind a rock opens in a modal, or inline when its category is expanded. Color is
 *  the rock's category (Capital blue, CSOG purple, Staff green, Operations red). */
export type LineCategory = { key: string; label: string; color: string; /** a page behind the category: ?s=N and the words for the link */ link?: { href: string; label: string }; /** the darker, bolder shade of the same color for the point's thin rim */ rim?: string };
export type LinePoint = { date: string; /** words for this point on the line, in place of the rock's text */ text?: string; /** a small caption beside the words: "date to set", "week of" */ note?: string };
export type LineRock = {
  key: string;
  text: string;
  category?: string;
  /** Primary rocks take the Polaris-sized dot; secondary ones the small dot. Primary when unset. */
  tier?: "primary" | "secondary";
  owner?: string;
  points: LinePoint[];
  /** The lines behind the rock. */
  detail?: PlanBig[];
  /** Details marked for later. */
  notes?: string[];
};
export type DocLine = {
  kind: "line";
  id: string;
  code?: string;
  name: string;
  horizon?: string;
  polaris?: string;
  people?: PlanPerson[];
  categories?: LineCategory[];
  rocks: LineRock[];
  final?: { text?: string };
  source?: string;
};

/** The capital raise page (11/1): targets with an owner, and the road (map + travel dates) where targets are allocated to cities. */
/** What sits behind a name: the three pills of the briefing card. */
export type TimelineRow = { when: string; text: string };
/** The four pills of the briefing card: Background and Bio (bullets, then a timeline), Relationship (bullets, then a timeline), Briefing (the meeting and Lumen's recommendation), Notes. */
export type CapitalProfile = { linkedin?: string; photo?: string; location?: string; bio?: string[]; bioTimeline?: TimelineRow[]; relationship?: string[]; relationshipTimeline?: TimelineRow[]; briefing?: string[]; notes?: string[] };
export type CapitalTarget = { id: string; org: string; name: string; title?: string; kind: string; wave?: number; owner?: string; /** a sponsor with no face on the plan, by name */ sponsor?: string; logins?: number; nda?: boolean; city?: string; note?: string; /** ISO datetime of the scheduled conversation; a data source for other pages later */ scheduled?: string; where?: string; /** a tag: Awaiting NDA, Deck sent, Meeting set, Passed, In */ status?: string; profile?: CapitalProfile };
export type CapitalStop = { date: string; when: string; label: string; city: string; targets: string[]; note?: string };
/** A person in the relationship directory (11/2), from the mailbox index; more feeds later. */
export type DirectoryPerson = { id: string; name: string; email: string; org: string; fromMe: number; toMe: number; first: string; last: string; subjects: string[]; owner?: string; city?: string; status?: string };
export type DocCapital = { kind: "capital"; id: string; code?: string; name: string; people?: PlanPerson[]; options?: string[]; targets: CapitalTarget[]; /** the prior list, kept whole and folded away */ archive?: CapitalTarget[]; archiveLabel?: string; /** everyone David has a thread with */ directory?: DirectoryPerson[]; stops: CapitalStop[]; source?: string };

/** Cards for the items that have to land (11/1): a goal, an assigned person, a status tag. */
export type CardLink = { label: string; href: string };
export type CardUpdate = { at: string; by?: string; text: string };
/** One purple line as a card: who brings it in (`owner`), who leads the work (`leads`), the pithy one-line `status` on its face
 *  (Lumen transcribes it from the updates), and the updates typed into the modal. The live copy lives in the Ledger store. */
export type DocCard = { key: string; title: string; code?: string; practice?: string; goal: number; owner?: string; leads?: string[]; status?: string; link?: CardLink; note?: string; updates?: CardUpdate[] };
export type DocCards = { kind: "cards"; id: string; people?: PlanPerson[]; items: DocCard[]; accent?: string; /** The artifact under the document's Ledger project that holds the live assignments and statuses. */ store?: string };

export type DocBlock =
  | { kind: "lead"; bold: string; text: string }
  | { kind: "para"; text: string }
  | { kind: "h2"; text: string }
  | { kind: "list"; items: string[] }
  | { kind: "callout"; eyebrow?: string; text: string }
  | { kind: "stats"; items: DocStat[] }
  | DocTable
  | DocChart
  | DocPlan
  | DocLine
  | DocCapital
  | DocCards
  | { kind: "source"; text: string }
  /** A document the page carries: a file or a live surface, opened in a new tab. */
  | { kind: "document"; title: string; href: string; sub?: string; note?: string }
  /** The cover's list of pages, rendered from the page array. */
  | { kind: "contents" };

export type DocPage = {
  slug: string;
  /** The page number as shown ("1"); the cover carries "". */
  ref: string;
  title: string;
  /** Mono eyebrow above the title. */
  kicker?: string;
  /** Present on the cover page only: the big centered composition. */
  cover?: { heading: string; sub?: string; note: string; date: string };
  blocks: DocBlock[];
  /** A page switch (10/25, the purple assumptions): off by default and the page
   *  shows `blocks`; on, it shows `blocksOn`. Both are complete block runs, so
   *  every figure, table and chart moves together. */
  toggle?: { label: string; offNote?: string; onNote?: string; blocksOn: DocBlock[]; /** Open the page with the switch on (the default is off). */ defaultOn?: boolean };
};
