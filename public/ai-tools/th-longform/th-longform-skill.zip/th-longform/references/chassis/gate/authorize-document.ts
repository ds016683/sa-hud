import "server-only";
import { cookies } from "next/headers";
import { notFound, redirect } from "next/navigation";
import { cookieName, verifyGateToken } from "./gate";
import { findDocument, documentCode } from "./documents";

export async function requireDocument(slug: string) {
  const document = findDocument(slug);
  if (!document) notFound();
  const token = (await cookies()).get(cookieName(slug))?.value;
  if (!(await verifyGateToken(slug, documentCode(document), token))) redirect(`/${slug}/unlock`);
  return document;
}
