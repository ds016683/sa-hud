export function documentPath(pathname: string): { slug: string; unlock: boolean } {
  let path = pathname;
  try { path = decodeURIComponent(pathname); } catch {}
  path = path.replace(/^\/_next\/data\/[^/]+\//, "/");
  const [slug = "", ...rest] = path.split("/").filter(Boolean);
  return {
    slug: slug.replace(/\.(?:segments|rsc|json)$/, ""),
    unlock: rest.length === 1 && rest[0].replace(/\.rsc$/, "") === "unlock",
  };
}
