// The documents registry: one entry per long-form document, one route per
// slug, one code per reader. Codes may be overridden without a deploy by
// setting DOCUMENT_CODE_<SLUG> (uppercased, dashes to underscores) in the
// environment. Every entry is a document; there is no deck here.

import "server-only";
import type { DocPage } from "@/content/doc";
import { FINANCE_REVIEW_PAGES } from "@/content/finance-review";

export type Document = {
  slug: string;
  /** The bar label beside the wordmark and the browser title. */
  label: string;
  /** Who it is prepared for; shows on the unlock page. */
  preparedFor: string;
  /** The default access code; DOCUMENT_CODE_<SLUG> overrides it. */
  code: string;
  /** The snapshot build of the pages; a live document rebuilds them at request time. */
  pages: DocPage[];
};

export const DOCUMENTS: Document[] = [
  {
    slug: "finance-review",
    label: "Company Finance Review",
    preparedFor: "David Smith, Third Horizon",
    code: "cfr2026",
    pages: FINANCE_REVIEW_PAGES,
  },
];

export function findDocument(slug: string): Document | undefined {
  return DOCUMENTS.find((d) => d.slug === slug);
}

export function documentCode(d: Document): string {
  return process.env[`DOCUMENT_CODE_${d.slug.toUpperCase().replace(/-/g, "_")}`] ?? d.code;
}
