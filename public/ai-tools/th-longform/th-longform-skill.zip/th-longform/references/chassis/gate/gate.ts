export const COOKIE_PREFIX = "thl_";
export const COOKIE_DAYS = 30;
export const PRIVATE_CACHE_CONTROL = "private, no-store, max-age=0, must-revalidate";

export function cookieName(slug: string): string {
  return COOKIE_PREFIX + slug;
}

async function signingKey(code: string): Promise<CryptoKey> {
  const secret = process.env.DOCUMENT_SECRET ?? "";
  return crypto.subtle.importKey("raw", new TextEncoder().encode(code + "|" + secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}

export async function gateToken(slug: string, code: string, expiresAt = Math.floor(Date.now() / 1000) + COOKIE_DAYS * 86400): Promise<string> {
  const message = new TextEncoder().encode(`document:${slug}:${expiresAt}`);
  const signature = await crypto.subtle.sign("HMAC", await signingKey(code), message);
  const hex = Array.from(new Uint8Array(signature)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
  return `v1.${expiresAt}.${hex}`;
}

export async function verifyGateToken(slug: string, code: string, token: string | undefined): Promise<boolean> {
  const match = token?.match(/^v1\.(\d+)\.([a-f0-9]{64})$/);
  if (!match) return false;
  const expiresAt = Number(match[1]);
  if (!Number.isSafeInteger(expiresAt) || expiresAt <= Math.floor(Date.now() / 1000)) return false;
  const signature = new Uint8Array(32);
  for (let index = 0; index < signature.length; index++) {
    signature[index] = Number.parseInt(match[2].slice(index * 2, index * 2 + 2), 16);
  }
  const message = new TextEncoder().encode(`document:${slug}:${expiresAt}`);
  return crypto.subtle.verify("HMAC", await signingKey(code), signature, message);
}
