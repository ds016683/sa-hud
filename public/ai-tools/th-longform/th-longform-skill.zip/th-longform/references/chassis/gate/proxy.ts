import { NextResponse, type NextRequest } from "next/server";
import { findDocument, documentCode } from "@/lib/documents";
import { cookieName, PRIVATE_CACHE_CONTROL, verifyGateToken } from "@/lib/gate";
import { documentPath } from "@/lib/document-path";

function privateResponse(response: NextResponse): NextResponse {
  response.headers.set("Cache-Control", PRIVATE_CACHE_CONTROL);
  response.headers.set("CDN-Cache-Control", "no-store");
  response.headers.set("Vercel-CDN-Cache-Control", "no-store");
  return response;
}

export async function proxy(request: NextRequest) {
  const { slug, unlock } = documentPath(request.nextUrl.pathname);
  if (!slug || unlock || slug === "api") return privateResponse(NextResponse.next());
  const d = findDocument(slug);
  if (!d) return privateResponse(NextResponse.next());
  const have = request.cookies.get(cookieName(slug))?.value;
  if (await verifyGateToken(slug, documentCode(d), have)) return privateResponse(NextResponse.next());
  const url = request.nextUrl.clone();
  url.pathname = `/${slug}/unlock`;
  url.search = "";
  return privateResponse(NextResponse.redirect(url));
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|brand/).*)"],
};
