import { NextResponse, type NextRequest } from "next/server";
import { findDocument, documentCode } from "@/lib/documents";
import { COOKIE_DAYS, cookieName, gateToken, PRIVATE_CACHE_CONTROL } from "@/lib/gate";

// POST { slug, code } from the unlock form. Right code: set the document's
// cookie and send the reader to page one. Wrong code: back to the unlock page
// with ?e=1. Nothing about the code is echoed.

export async function POST(request: NextRequest) {
  const form = await request.formData();
  const slug = String(form.get("slug") ?? "");
  const code = String(form.get("code") ?? "").trim();
  const d = findDocument(slug);
  const base = new URL(request.url);
  if (!d) return NextResponse.redirect(new URL("/", base), 303);
  if (!code || code.toLowerCase() !== documentCode(d).toLowerCase()) {
    return NextResponse.redirect(new URL(`/${slug}/unlock?e=1`, base), 303);
  }
  const res = NextResponse.redirect(new URL(`/${slug}?s=1`, base), 303);
  res.headers.set("Cache-Control", PRIVATE_CACHE_CONTROL);
  res.cookies.set(cookieName(slug), await gateToken(slug, documentCode(d)), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: COOKIE_DAYS * 24 * 60 * 60,
  });
  return res;
}
