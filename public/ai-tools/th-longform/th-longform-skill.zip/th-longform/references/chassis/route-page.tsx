import { Suspense } from "react";
import { DocReader } from "@/components/document/doc-reader";
import { findProposal } from "@/lib/proposals";
import { requireProposal } from "@/lib/authorize-proposal";

// /finance-review (10/25): the Company Finance Review, the first document on
// the proposals chassis. Its own route so the shared [slug] deck route, which
// serves the AMA proposal, stays exactly as shipped (David 10/25: the AMA
// proposal stays locked in place). Same gate, same registry entry.

export const dynamic = "force-dynamic";

const SLUG = "finance-review";

export async function generateMetadata() {
  const p = findProposal(SLUG);
  return { title: p ? `${p.label} · Third Horizon` : "Third Horizon · Proposals" };
}

export default async function FinanceReviewPage() {
  const p = await requireProposal(SLUG);
  return (
    <Suspense fallback={null}>
      <DocReader pages={p.pages ?? []} closeHref="https://thirdhorizon.com" basePath={`/${p.slug}`} label={p.label} />
    </Suspense>
  );
}
