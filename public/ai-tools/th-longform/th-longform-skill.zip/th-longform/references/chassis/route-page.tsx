import { Suspense } from "react";
import { DocReader } from "@/components/document/doc-reader";
import { findProposal } from "@/lib/proposals";
import { requireProposal } from "@/lib/authorize-proposal";
import { financeLive } from "@/lib/finance-source";
import { buildFinanceReviewPages } from "@/content/finance-review";

// /finance-review (10/25): the Company Finance Review, the first document on
// the proposals chassis. Its own route so the shared [slug] deck route, which
// serves the AMA proposal, stays exactly as shipped (David 10/25: the AMA
// proposal stays locked in place). Same gate, same registry entry.
//
// Live data (10/26): the October to December estimate and the cash worksheet
// are read from the SharePoint workbook at request time, with an eTag check at
// most once a minute; the committed snapshot stands in when SharePoint is out.

export const dynamic = "force-dynamic";

const SLUG = "finance-review";

export async function generateMetadata() {
  const p = findProposal(SLUG);
  return { title: p ? `${p.label} · Third Horizon` : "Third Horizon · Proposals" };
}

export default async function FinanceReviewPage() {
  const p = await requireProposal(SLUG);
  const live = await financeLive();
  const pages = buildFinanceReviewPages(live);
  return (
    <Suspense fallback={null}>
      <DocReader pages={pages} closeHref="https://thirdhorizon.com" basePath={`/${p.slug}`} label={p.label} />
    </Suspense>
  );
}
