import { Suspense } from "react";
import { DocReader } from "@/components/document/doc-reader";
import { findDocument } from "@/lib/documents";
import { requireDocument } from "@/lib/authorize-document";
import { financeLive } from "@/lib/finance-source";
import { buildFinanceReviewPages } from "@/content/finance-review";

// Every document is served here from the registry, behind the gate. A live
// document rebuilds its pages at request time from its live read; the others
// use their snapshot build.

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const d = findDocument(slug);
  return { title: d ? `${d.label} · Third Horizon` : "Third Horizon · Long Form" };
}

export default async function DocumentPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const d = await requireDocument(slug);
  const pages = d.slug === "finance-review" ? buildFinanceReviewPages(await financeLive()) : d.pages;
  return (
    <Suspense fallback={null}>
      <DocReader pages={pages} closeHref="https://thirdhorizon.com" basePath={`/${d.slug}`} label={d.label} />
    </Suspense>
  );
}
