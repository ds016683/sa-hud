import { notFound } from "next/navigation";
import s from "@/components/gate/gate.module.css";
import { GateShell } from "@/components/gate/gate-shell";
import { findDocument } from "@/lib/documents";

// /<slug>/unlock: the code page, in the CIP gate's canon.

export default async function UnlockPage({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ e?: string }> }) {
  const { slug } = await params;
  const { e } = await searchParams;
  const d = findDocument(slug);
  if (!d) notFound();
  return (
    <GateShell sub={d.label}>
      <div className={s.col}>
        <div className={s.eyebrow}>Prepared for {d.preparedFor}</div>
        <h1 className={s.title}>{d.label}</h1>
        <div className={s.notice}>
          <div className={s.noticeTitle}>Shared by link</div>
          <p className={s.noticeBody}>This document is confidential to the people it was prepared for. Enter the access code you were sent to open it.</p>
        </div>
        <form className={s.form} method="post" action="/api/unlock">
          <input type="hidden" name="slug" value={d.slug} />
          <div className={s.field}>
            <label className={s.label} htmlFor="code">Access code</label>
            <input id="code" name="code" className={s.input} type="password" autoComplete="off" autoFocus required />
            {e ? <div className={s.error}>That code did not match. Check the note you were sent and try again.</div> : null}
          </div>
          <div className={s.linkRow}>
            <button type="submit" className={s.btn}>Open the document</button>
          </div>
        </form>
      </div>
    </GateShell>
  );
}
