import { notFound } from "next/navigation";
import s from "@/components/gate/gate.module.css";
import { GateShell } from "@/components/gate/gate-shell";
import { findProposal } from "@/lib/proposals";

// /finance-review/unlock: the code page for the Company Finance Review, in the
// CIP gate's canon. Its own page beside the shared [slug]/unlock so the AMA
// proposal's unlock page stays exactly as shipped (David 10/25).

const SLUG = "finance-review";

export default async function FinanceReviewUnlockPage({ searchParams }: { searchParams: Promise<{ e?: string }> }) {
  const { e } = await searchParams;
  const p = findProposal(SLUG);
  if (!p) notFound();
  return (
    <GateShell sub={p.label}>
      <div className={s.col}>
        <div className={s.eyebrow}>Prepared for {p.preparedFor}</div>
        <h1 className={s.title}>{p.label}</h1>
        <div className={s.notice}>
          <div className={s.noticeTitle}>Shared by link</div>
          <p className={s.noticeBody}>This review is confidential to the people it was prepared for. Enter the access code you were sent to open it.</p>
        </div>
        <form className={s.form} method="post" action="/api/unlock">
          <input type="hidden" name="slug" value={p.slug} />
          <div className={s.field}>
            <label className={s.label} htmlFor="code">Access code</label>
            <input id="code" name="code" className={s.input} type="password" autoComplete="off" autoFocus required />
            {e ? <div className={s.error}>That code did not match. Check the note you were sent and try again.</div> : null}
          </div>
          <div className={s.linkRow}>
            <button type="submit" className={s.btn}>Open the review</button>
          </div>
        </form>
      </div>
    </GateShell>
  );
}
