// Generated from the live pro forma (SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026,
// 2026 block, columns U to AC) on October 25, 2026 by the session's build_pf_data.py. Do not edit by hand; regenerate.
import type { DocRow } from "./doc";

export type PfData = { readOn: string; months: string[]; labels: string[]; sections: DocRow[]; base: DocRow; forecasted: DocRow; expenses: DocRow; net: DocRow; sectionsTotal: number; kidsCount: number };

export const PF: PfData = {
 "readOn": "October 25, 2026",
 "months": [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep"
 ],
 "labels": [
  "Actual",
  "Actual",
  "Actual",
  "Actual",
  "Projected",
  "Projected",
  "Projected",
  "Projected",
  "Projected"
 ],
 "sections": [
  {
   "label": "BEH - Behavioral Health",
   "cells": [
    256346,
    217730,
    217243,
    295991,
    245837,
    238905,
    302532,
    266930,
    274453
   ],
   "total": 2315968,
   "children": [
    {
     "label": "All Health",
     "sub": "BEH-26-01-ALL",
     "cells": [
      0,
      0,
      0,
      0,
      1333,
      1333,
      1333,
      0,
      0
     ],
     "total": 4000
    },
    {
     "label": "American Hospital Association (Alliance)",
     "sub": "BEH-24-01-AHA",
     "cells": [
      36000,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 36000
    },
    {
     "label": "APNC Strategic Adivsory",
     "sub": "BEH-25-02-APN",
     "cells": [
      1500,
      1500,
      1500,
      1500,
      4000,
      1500,
      0,
      0,
      0
     ],
     "total": 11500
    },
    {
     "label": "Ascension Recovery Services - feasibility study",
     "sub": "BEH-26-01-ARS",
     "cells": [
      10000,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 10000
    },
    {
     "label": "Axis Health",
     "sub": "BEH-26-01-AHS",
     "cells": [
      6640,
      6640,
      6640,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 19920
    },
    {
     "label": "Axis Health",
     "sub": "BEH-26-02-AHS",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      6000,
      6000,
      0
     ],
     "total": 12000
    },
    {
     "label": "Clayton Christenson - Can You Play",
     "sub": "BEH-25-01-CCI",
     "cells": [
      24000,
      24000,
      24000,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 72000
    },
    {
     "label": "Clayton Christenson - Can You Play",
     "sub": "BEH-26-01-CCI",
     "cells": [
      0,
      0,
      0,
      11250,
      11250,
      11250,
      11250,
      0,
      0
     ],
     "total": 45000
    },
    {
     "label": "Colorado Dept. of Human Services",
     "sub": "BEH-26-01-CHS",
     "cells": [
      0,
      0,
      0,
      0,
      17842,
      9644,
      2875,
      3000,
      1500
     ],
     "total": 34861
    },
    {
     "label": "Community Mental Health Fund (Behavioral Health Funder's Collaborative)",
     "sub": "BEH-26-01-CMH",
     "cells": [
      0,
      10230,
      10230,
      10230,
      10230,
      0,
      0,
      0,
      0
     ],
     "total": 40920
    },
    {
     "label": "Denver Public Health",
     "sub": "BEH-25-01-DPH",
     "cells": [
      11812,
      9874,
      14881,
      23471,
      8345,
      12339,
      12500,
      16812,
      12500
     ],
     "total": 122535
    },
    {
     "label": "Easterseals New Hampshire",
     "sub": "BEH-26-01-ENH",
     "cells": [
      0,
      0,
      0,
      4000,
      4000,
      4000,
      0,
      0,
      0
     ],
     "total": 12000
    },
    {
     "label": "Elliot Health System",
     "sub": "BEH-26-01-EHS",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      25000,
      25000,
      25000,
      25000
     ],
     "total": 100000
    },
    {
     "label": "HealthTeamWorks",
     "sub": "BEH-26-01-HTW",
     "cells": [
      0,
      0,
      0,
      1800,
      1800,
      1800,
      1800,
      1800,
      0
     ],
     "total": 9000
    },
    {
     "label": "Health Strategies of NH",
     "sub": "BEH-26-01-HSN",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      12500,
      12500,
      12500
     ],
     "total": 37500
    },
    {
     "label": "Indiana Family and Social Services Admin",
     "sub": "BEH-25-01-IND",
     "cells": [
      15000,
      15000,
      15000,
      15000,
      15000,
      15000,
      15000,
      15000,
      35000
     ],
     "total": 155000
    },
    {
     "label": "Kids TLC",
     "sub": "BEH-25-01-KID",
     "cells": [
      0,
      10000,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 10000
    },
    {
     "label": "Maine Behavioral Health Foundation",
     "sub": "BEH-26-01-MBH",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      6250,
      12500,
      12500
     ],
     "total": 31250
    },
    {
     "label": "Maine Health Access Foundation",
     "sub": "BEH-26-01-MHA",
     "cells": [
      3333,
      3333,
      3333,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 10000
    },
    {
     "label": "McCall BHN",
     "sub": "BEH-25-01-MCC",
     "cells": [
      5000,
      5000,
      5000,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 15000
    },
    {
     "label": "Mental Well-Being Initiative (Yr 2)",
     "sub": "BEH-26-01-MWB",
     "cells": [
      0,
      6500,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 6500
    },
    {
     "label": "National Council for Mental Wellbeing",
     "sub": "BEH-24-01-NCW",
     "cells": [
      5140,
      3300,
      3300,
      5716,
      12300,
      9600,
      13000,
      3844,
      0
     ],
     "total": 56200
    },
    {
     "label": "National Council for Mental Wellbeing CCBHC TTA",
     "sub": "BEH-26-01-NCW",
     "cells": [
      0,
      0,
      0,
      50408,
      50408,
      52526,
      42687,
      41765,
      47504
     ],
     "total": 285298
    },
    {
     "label": "New Hampshire Charitable Foundation",
     "sub": "BEH-26-01-NHCF",
     "cells": [
      12500,
      12500,
      12500,
      12500,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 50000
    },
    {
     "label": "NFI North",
     "sub": "BEH-26-01-NFI",
     "cells": [
      0,
      0,
      6667,
      10000,
      10000,
      3333,
      3333,
      3333,
      3333
     ],
     "total": 39998
    },
    {
     "label": "NORC - NH",
     "sub": "BEH-26-01-NOR",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      41680,
      30810,
      26050
     ],
     "total": 98540
    },
    {
     "label": "NYS - OASAS",
     "sub": "BEH-24-01-NYS",
     "cells": [
      25000,
      25000,
      25000,
      25000,
      25000,
      25000,
      25000,
      25000,
      25000
     ],
     "total": 225000
    },
    {
     "label": "NYS - OASAS - ATC Project",
     "sub": "BEH-25-01-NYS",
     "cells": [
      11343,
      11343,
      11343,
      25115,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 59145
    },
    {
     "label": "Oregon ADPC",
     "sub": "BEH-25-01-ORE",
     "cells": [
      11000,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 11000
    },
    {
     "label": "Oregon ADPC Extension - Amendment 2",
     "sub": "BEH-25-01-ORE1",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      12000,
      2400,
      2400
     ],
     "total": 16800
    },
    {
     "label": "Oregon Prevention",
     "sub": "BEH-25-02-ORE",
     "cells": [
      50000,
      50000,
      50000,
      50000,
      50000,
      50000,
      50000,
      50000,
      54000
     ],
     "total": 454000
    },
    {
     "label": "Recovery Link",
     "sub": "BEH-25-01-REL",
     "cells": [
      6078,
      1508,
      5849,
      0,
      6879,
      580,
      158,
      0,
      0
     ],
     "total": 21051
    },
    {
     "label": "Rosecrance (SUPR)",
     "sub": "BEH-25-01-ROS",
     "cells": [
      5500,
      5500,
      5500,
      30500,
      6950,
      5500,
      0,
      0,
      0
     ],
     "total": 59450
    },
    {
     "label": "Rosecrance (SUPR) - 2026-2027 renewal",
     "sub": "BEH-26-01-ROS",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      9667,
      9667,
      9667
     ],
     "total": 29000
    },
    {
     "label": "San Luis Behavioral Health Group",
     "sub": "BEH-26-01-SLB",
     "cells": [
      0,
      0,
      0,
      3000,
      3000,
      3000,
      3000,
      0,
      0
     ],
     "total": 12000
    },
    {
     "label": "Signal BHN",
     "sub": "BEH-25-01-SIG/BEH-26-01-SIG",
     "cells": [
      7500,
      7500,
      7500,
      7500,
      7500,
      7500,
      7500,
      7500,
      7500
     ],
     "total": 67500
    },
    {
     "label": "Southwest Counseling Services",
     "sub": "BEH-25-01-SWC",
     "cells": [
      9000,
      9000,
      9000,
      9000,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 36000
    }
   ]
  },
  {
   "label": "PAD - Payment Design & Analytics",
   "cells": [
    30033,
    37922,
    45983,
    40193,
    27583,
    39752,
    58033,
    35139,
    57500
   ],
   "total": 372137,
   "children": [
    {
     "label": "Blue Cross Blue Shield of Michigan",
     "sub": "PAD-24-01-BCM",
     "cells": [
      8416,
      8416,
      8416,
      8416,
      8416,
      8416,
      8416,
      8416,
      8416
     ],
     "total": 75744
    },
    {
     "label": "KPMG - Colorado Medicaid APMs",
     "sub": "PAD-24-01-KCM",
     "cells": [
      10000,
      10000,
      10000,
      10000,
      10000,
      10000,
      10000,
      10000,
      10000
     ],
     "total": 90000
    },
    {
     "label": "Lakes Treatment Center",
     "sub": "PAD-25-01-LTC",
     "cells": [
      0,
      5625,
      14000,
      3625,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 23250
    },
    {
     "label": "Michigan Dental",
     "sub": "PAD-24-01-MID",
     "cells": [
      2450,
      2469,
      900,
      1075,
      0,
      10419,
      0,
      5806,
      0
     ],
     "total": 23119
    },
    {
     "label": "Moreton USHE RFP",
     "sub": "PAD-26-01-MOR",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      20000,
      0,
      0
     ],
     "total": 20000
    },
    {
     "label": "Moreton USHE - retainer",
     "sub": "PAD-26-01-MOR2",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      15000
     ],
     "total": 15000
    },
    {
     "label": "Mutual of Omaha",
     "sub": "PAD-26-01-MOO",
     "cells": [
      0,
      0,
      0,
      6160,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 6160
    },
    {
     "label": "NAATP",
     "sub": "PAD-26-01-NAA",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      450,
      0,
      0
     ],
     "total": 450
    },
    {
     "label": "Part D Advisors",
     "sub": "PAD-24-01-PDA",
     "cells": [
      0,
      1750,
      3500,
      1750,
      0,
      1750,
      0,
      1750,
      13250
     ],
     "total": 23750
    },
    {
     "label": "REDi Health",
     "sub": "PAD-26-01-PAD",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      10000,
      0,
      0
     ],
     "total": 10000
    },
    {
     "label": "REDi Health",
     "sub": "PAD-26-02-PAD (8.28.2026 - 8.27.2027)",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1667
     ],
     "total": 1667
    },
    {
     "label": "SSNC",
     "sub": "PAD-24-01-SSC",
     "cells": [
      9167,
      9167,
      9167,
      9167,
      9167,
      9167,
      9167,
      9167,
      9167
     ],
     "total": 82503
    },
    {
     "label": "Terry Group Support",
     "sub": "EXISTING MSA",
     "cells": [
      0,
      495,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 495
    }
   ]
  },
  {
   "label": "MAR - Market Analytics",
   "cells": [
    240792,
    308292,
    144125,
    209713,
    258006,
    334423,
    246980,
    221564,
    275514
   ],
   "total": 2239407,
   "children": [
    {
     "label": "Complete Ortho",
     "sub": "PAD-26-01-COR",
     "cells": [
      0,
      30000,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 30000
    },
    {
     "label": "Handl Health (MotivHealth Sub)",
     "sub": "PAD 25-01-MHH",
     "cells": [
      3333,
      3333,
      3333,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 10000
    },
    {
     "label": "Intermountain - DaaS",
     "sub": "PAD-26-01-IMT (5.14.2026 - 5.13.2027)",
     "cells": [
      0,
      0,
      0,
      0,
      417,
      417,
      417,
      417,
      417
     ],
     "total": 2083
    },
    {
     "label": "Intermountain -",
     "sub": "PAD-26-01-IMT2",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      6000,
      6000
     ],
     "total": 12000
    },
    {
     "label": "Marsh & McLennan Agency (Schedule E - Core)",
     "sub": "PAD-25-01-MMA; PAD 25-03-MMA",
     "cells": [
      58392,
      58392,
      58392,
      58392,
      58392,
      58392,
      58392,
      58392,
      58392
     ],
     "total": 525528
    },
    {
     "label": "Marsh & McLennan Agency (Schedule E - Enhance)",
     "sub": "PAD 25-03-MMA-APRDRG",
     "cells": [
      9412,
      9412,
      9412,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 28236
    },
    {
     "label": "Marsh & McLennan Agency (Schedule E - Enhance)",
     "sub": "PAD 25-03-MMA-REGNET1",
     "cells": [
      10000,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 10000
    },
    {
     "label": "Marsh & McLennan Agency (Schedule E - Enhance)",
     "sub": "PAD 25-03-MMA-REGNET2",
     "cells": [
      0,
      0,
      0,
      0,
      30000,
      30000,
      30000,
      0,
      0
     ],
     "total": 90000
    },
    {
     "label": "Marsh & McLennan Agency (Schedule E - Enhance)",
     "sub": "PAD 25-03-MMA-NETENH",
     "cells": [
      0,
      0,
      0,
      0,
      5000,
      5000,
      5000,
      0,
      0
     ],
     "total": 15000
    },
    {
     "label": "Marsh & McLennan Agency (Schedule E - Enhance)",
     "sub": "PAD 25-03-MMA-SELECT1",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      40000
     ],
     "total": 40000
    },
    {
     "label": "Marsh & McLennan Agency (Schedule E - Enhance)",
     "sub": "PAD 25-03-MMA-REGENT3",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      36250
     ],
     "total": 36250
    },
    {
     "label": "Marsh & McLennan Agency (Schedule F - Innovation)",
     "sub": "PAD 25-04-MMA-HRE",
     "cells": [
      100000,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 100000
    },
    {
     "label": "Marsh & McLennan Agency (Schedule F - Innovation)",
     "sub": "PAD 25-04-MMA-DRU",
     "cells": [
      0,
      100000,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 100000
    },
    {
     "label": "Marsh & McLennan Agency (Schedule F - Innovation)",
     "sub": "PAD 25-04-MMA-SPRX",
     "cells": [
      8937,
      8937,
      8937,
      8937,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 35748
    },
    {
     "label": "Marsh & McLennan Agency (Schedule F - Innovation)",
     "sub": "PAD 25-04-MMA-EPI",
     "cells": [
      0,
      0,
      0,
      41666,
      41666,
      41666,
      0,
      0,
      0
     ],
     "total": 124999
    },
    {
     "label": "Marsh & McLennan Agency (Schedule F - Innovation)",
     "sub": "PAD 25-04-MMA-CLMTIC",
     "cells": [
      6467,
      6467,
      6467,
      6467,
      12934,
      12934,
      0,
      0,
      0
     ],
     "total": 51738
    },
    {
     "label": "Marsh & McLennan Agency (Schedule F - Innovation)",
     "sub": "PAD 25-04-MMA-QUAL",
     "cells": [
      0,
      0,
      0,
      0,
      27755,
      27755,
      27755,
      27755,
      27755
     ],
     "total": 138775
    },
    {
     "label": "Marsh & McLennan Agency (Schedule F - Innovation)",
     "sub": "PAD 25-04-MMA-PLTF",
     "cells": [
      0,
      0,
      0,
      0,
      16175,
      16175,
      0,
      0,
      0
     ],
     "total": 32350
    },
    {
     "label": "Marsh & McLennan Agency (Schedule F - Innovation)",
     "sub": "PAD-25-04-MMA-NNV",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      53750,
      53750,
      53750,
      53750
     ],
     "total": 215000
    },
    {
     "label": "MMA Midatlantic (Promise Health Plan)",
     "sub": "PAD-26-01-MMA",
     "cells": [
      0,
      8333,
      8333,
      8333,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 25000
    },
    {
     "label": "MJ Insurance",
     "sub": "PAD-26-01-MJI (3.17.2026 - 3.16-2027)",
     "cells": [
      0,
      0,
      3333,
      3333,
      3333,
      3333,
      3333,
      3333,
      3333
     ],
     "total": 23333
    },
    {
     "label": "One Utah Health Collaborative - DaaS",
     "sub": "PAD-26-01-UHC (2.17.2026 - 2.16.2027)",
     "cells": [
      0,
      1667,
      1667,
      1667,
      1667,
      1667,
      1667,
      1667,
      4792
     ],
     "total": 16458
    },
    {
     "label": "One Utah Health Collaborative - BH Parity",
     "sub": "PAD-26-02-UHC",
     "cells": [
      0,
      0,
      0,
      0,
      21417,
      21417,
      21417,
      0,
      0
     ],
     "total": 64250
    },
    {
     "label": "Recreate BH",
     "sub": "PAD-26-01-RBH (9.1.2026 = 8.31.2027",
     "cells": [
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      2575
     ],
     "total": 2575
    },
    {
     "label": "Sanford",
     "sub": "PAD-26-01-SAN (3.27.2026 - 3.26.2027)",
     "cells": [
      0,
      0,
      0,
      36667,
      1667,
      1667,
      1667,
      1667,
      1667
     ],
     "total": 45000
    },
    {
     "label": "Silver Hill Hospital",
     "sub": "PAD-26-01-SHH (Sept. 1, 2026 - Aug. 31, 2027)",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1250
     ],
     "total": 1250
    },
    {
     "label": "The Kennedy Forum - Parity Index (AMA)",
     "sub": "MAR-24-01-TKF4",
     "cells": [
      0,
      37500,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 37500
    },
    {
     "label": "The Kennedy Forum - Parity Index (APF)",
     "sub": "MAR-24-01-TKF5",
     "cells": [
      12500,
      12500,
      12500,
      12500,
      12500,
      12500,
      12500,
      12500,
      0
     ],
     "total": 100000
    },
    {
     "label": "The Kennedy Forum - Parity Index (NYS)",
     "sub": "MAR-24-01-TKF6",
     "cells": [
      11750,
      11750,
      11750,
      11750,
      11750,
      11750,
      11750,
      11750,
      0
     ],
     "total": 94000
    },
    {
     "label": "The Kennedy Forum - Parity Index (Blank)",
     "sub": "MAR-24-01-TKF7",
     "cells": [
      20000,
      20000,
      20000,
      20000,
      5000,
      5000,
      5000,
      5000,
      0
     ],
     "total": 100000
    },
    {
     "label": "The Kennedy Forum - MHPI Expansion (Tool)",
     "sub": "MAR-24-01-TKF8",
     "cells": [
      0,
      0,
      0,
      0,
      8333,
      16667,
      0,
      0,
      0
     ],
     "total": 25000
    },
    {
     "label": "The Kennedy Forum - BiPolar User Interface",
     "sub": "MAR-24-01-TFK9",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      13500,
      13500,
      13500,
      13500
     ],
     "total": 54000
    },
    {
     "label": "The Kennedy Forum - BiPolar User Interface - DaaS",
     "sub": "MAR-24-01-TFK9 (6.1.2026 - 5.30.2027)",
     "cells": [
      0,
      0,
      0,
      0,
      null,
      833,
      833,
      833,
      833
     ],
     "total": 3333
    },
    {
     "label": "The Kennedy Forum - URAC",
     "sub": "MAR-24-01-TKF10",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      25000,
      25000
     ],
     "total": 50000
    }
   ]
  },
  {
   "label": "WWB - Workplace Well-Being",
   "cells": [
    7500,
    2500,
    32500,
    40000,
    51500,
    48825,
    3825,
    5525,
    11325
   ],
   "total": 203500,
   "children": [
    {
     "label": "AARP",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      5500,
      0,
      0
     ],
     "total": 5500
    },
    {
     "label": "APNC - Agile Leadership",
     "sub": "WWB-26-01-APN",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      3825,
      3825,
      5525,
      3825
     ],
     "total": 17000
    },
    {
     "label": "Barnes & Thornburg",
     "sub": "WWW-25-01-BAT",
     "cells": [
      2500,
      2500,
      2500,
      2500,
      2500,
      2500,
      0,
      0,
      0
     ],
     "total": 15000
    },
    {
     "label": "Deloitte Consulting",
     "sub": "WWB-25-01-DEC",
     "cells": [
      0,
      0,
      30000,
      37500,
      49000,
      42500,
      0,
      0,
      7500
     ],
     "total": 166500
    },
    {
     "label": "Health Fitness Corporation",
     "cells": [
      5000,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 5000
    }
   ]
  },
  {
   "label": "CMH - Community Health",
   "cells": [
    55238,
    66905,
    156905,
    58905,
    66148,
    97896,
    89396,
    82062,
    18687
   ],
   "total": 692142,
   "children": [
    {
     "label": "American Medical Association (IPI)",
     "sub": "CMH-25-01-AMA",
     "cells": [
      19167,
      19167,
      19167,
      19167,
      17035,
      0,
      0,
      0,
      0
     ],
     "total": 93703
    },
    {
     "label": "DCM Foundation",
     "sub": "CMH-26-01-DCM",
     "cells": [
      null,
      null,
      null,
      null,
      null,
      null,
      10000,
      10000,
      10000
     ],
     "total": 30000
    },
    {
     "label": "Dream Engine Ventures",
     "sub": "CMH-25-01-DEV",
     "cells": [
      8000,
      8000,
      8000,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 24000
    },
    {
     "label": "Food is Medicine Coalition (FIMC)",
     "sub": "CMH-26-01-FIM",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      4354,
      4354,
      4354,
      4354
     ],
     "total": 17415
    },
    {
     "label": "Health Plan Alliance",
     "sub": "CMH-25-01-HPA",
     "cells": [
      3500,
      3500,
      3500,
      3500,
      3500,
      3500,
      0,
      0,
      0
     ],
     "total": 21000
    },
    {
     "label": "National Association of Chronic Disease Directors: SWAT",
     "sub": "CMH-25-01-NAC5",
     "cells": [
      20000,
      20000,
      20000,
      0,
      0,
      15000,
      0,
      0,
      0
     ],
     "total": 75000
    },
    {
     "label": "National Association of Chronic Disease Directors - 10508",
     "sub": "CMH-26-01-NAC1",
     "cells": [
      0,
      7500,
      7500,
      7500,
      7500,
      7500,
      7500,
      0,
      0
     ],
     "total": 45000
    },
    {
     "label": "National Association of Chronic Disease Directors - 10513",
     "sub": "CMH-26-01-NAC2",
     "cells": [
      0,
      4167,
      4167,
      4167,
      4167,
      4167,
      4167,
      4333,
      4333
     ],
     "total": 33667
    },
    {
     "label": "Pomegranate Market",
     "sub": "CMH-26-01-POM",
     "cells": [
      0,
      0,
      0,
      0,
      9375,
      9375,
      9375,
      9375,
      0
     ],
     "total": 37500
    },
    {
     "label": "Project Angel Heart",
     "sub": "BEH-25-01-PAH",
     "cells": [
      4571,
      4571,
      4571,
      4571,
      4571,
      0,
      0,
      0,
      0
     ],
     "total": 22857
    },
    {
     "label": "Project Angel Heart - Amendment",
     "sub": "BEH-25-01-PAH1",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      5000,
      5000,
      5000,
      0
     ],
     "total": 15000
    },
    {
     "label": "SNMI - Innovation Development Institute, Inc (MATTER) - Amendment #2",
     "sub": "CMH-24-01-SSH2",
     "cells": [
      0,
      0,
      90000,
      20000,
      20000,
      49000,
      49000,
      49000,
      0
     ],
     "total": 277000
    }
   ]
  },
  {
   "label": "Third Horizon - General",
   "cells": [
    8333,
    7500,
    7500,
    32500,
    22500,
    20425,
    9541,
    37500,
    9000
   ],
   "total": 154799,
   "children": [
    {
     "label": "Alliance of Community Health Plans - AI",
     "sub": "THS-26-01-ACH",
     "cells": [
      0,
      7500,
      7500,
      32500,
      22500,
      17500,
      7500,
      7500,
      7500
     ],
     "total": 110000
    },
    {
     "label": "APNC - David Smith Strategy",
     "sub": "THS-26-01-APN",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      2925,
      2041,
      30000,
      0
     ],
     "total": 34966
    },
    {
     "label": "APNC - MSA Schedule 2: Strategic Advisory",
     "sub": "THS-26-02-APN2",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1500
     ],
     "total": 1500
    },
    {
     "label": "High Watch",
     "cells": [
      8333,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 8333
    }
   ]
  }
 ],
 "base": {
  "label": "Base Revenue",
  "cells": [
   618910,
   662015,
   602946,
   770017,
   671574,
   780225,
   710307,
   648720,
   646479
  ],
  "total": 6111194
 },
 "forecasted": {
  "label": "Forecasted Revenue",
  "cells": [
   618910,
   662015,
   602946,
   770017,
   671574,
   780225,
   710307,
   648720,
   646479
  ],
  "total": 6111194
 },
 "expenses": {
  "label": "Expenses",
  "cells": [
   677213,
   674453,
   617627,
   703203,
   706557,
   720641,
   722660,
   669959,
   629022
  ],
  "total": 6121335
 },
 "net": {
  "label": "Net Income",
  "cells": [
   -58303,
   -12438,
   -14681,
   66814,
   -34983,
   59584,
   -12353,
   -21239,
   17457
  ],
  "total": -10141
 },
 "sectionsTotal": 5977953,
 "kidsCount": 105
};
