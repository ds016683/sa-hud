// Generated from NetSuite over SuiteQL (posting transactions, accounting-period basis, the nine 2026 periods
// January through September) on October 25, 2026 by the session's ns_pl_jan_sep.py + build_ns_data.py. Do not edit by hand; regenerate.
import type { DocRow } from "./doc";

export type NsTotal = { cells: number[]; total: number };
export type NsData = { readOn: string; months: string[]; closed: boolean[]; income: DocRow[]; expense: DocRow[]; otherIncome: DocRow[]; otherExpense: DocRow[]; totals: { income: NsTotal; expense: NsTotal; ordinary: NsTotal; otherIncome: NsTotal; otherExpense: NsTotal; net: NsTotal }; accountCount: number };

export const NS: NsData = {
 "readOn": "October 25, 2026",
 "months": [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep"
 ],
 "closed": [
  true,
  true,
  true,
  true,
  true,
  true,
  true,
  true,
  true
 ],
 "income": [
  {
   "label": "40000 - Revenue",
   "cells": [
    598243.42,
    641348.66,
    608946.73,
    676857.76,
    672743.21,
    780226.12,
    715955.78,
    648720.84,
    647075.07
   ],
   "total": 5990117.59,
   "children": [
    {
     "label": "41000 - Recurring Revenue",
     "cells": [
      88833.33,
      120308.0,
      64500.0,
      119807.67,
      54083.01,
      69916.34,
      108119.76,
      66833.01,
      101950.68
     ],
     "total": 794351.8,
     "children": [
      {
       "label": "41100 - Recurring Revenue - non-subscription",
       "cells": [
        52833.33,
        118641.33,
        59500.0,
        113141.0,
        46999.67,
        61999.67,
        100203.09,
        63499.67,
        92500.67
       ],
       "total": 709318.43,
       "children": [
        {
         "label": "Indiana Family and Social Services Admin, Division of Mental Health and Addictio",
         "sub": "BEH-25-01-IND",
         "cells": [
          0,
          15000.0,
          15000.0,
          15000.0,
          15000.0,
          15000.0,
          15000.0,
          15000.0,
          35000.0
         ],
         "total": 140000.0
        },
        {
         "label": "New York State Office of Addiction Services and Supports",
         "sub": "BEH-25-01-NYS",
         "cells": [
          0,
          59141.33,
          0,
          59141.33,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 118282.66
        },
        {
         "label": "KPMG LLP",
         "sub": "no Project Code",
         "cells": [
          10000.0,
          10000.0,
          10000.0,
          10000.0,
          10000.0,
          10000.0,
          10000.0,
          10000.0,
          10000.0
         ],
         "total": 90000.0
        },
        {
         "label": "SS&C Health",
         "sub": "PAD-26-01-SSC",
         "cells": [
          9166.67,
          9166.67,
          9166.67,
          9166.67,
          9166.67,
          9166.67,
          9166.67,
          9166.67,
          9166.67
         ],
         "total": 82500.03
        },
        {
         "label": "New Hampshire Charitable Foundation",
         "sub": "BEH-26-01-NHCF",
         "cells": [
          12500.0,
          12500.0,
          12500.0,
          12500.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 50000.0
        },
        {
         "label": "New York State Office of Addiction Services and Supports",
         "sub": "BEH-24-01-NYS",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          45536.75,
          0,
          0
         ],
         "total": 45536.75
        },
        {
         "label": "Rosecrance",
         "sub": "BEH-26-01-ROS",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          9666.67,
          9666.67,
          9666.67
         ],
         "total": 29000.01
        },
        {
         "label": "Rosecrance",
         "sub": "BEH-25-01-ROS",
         "cells": [
          5500.0,
          5500.0,
          5500.0,
          0,
          5500.0,
          5500.0,
          0,
          0,
          0
         ],
         "total": 27500.0
        },
        {
         "label": "Signal Behavioral Health Network",
         "sub": "BEH-26-01-SIG",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          7500.0,
          7500.0,
          7500.0
         ],
         "total": 22500.0
        },
        {
         "label": "NFI North",
         "sub": "BEH-26-01-NFI",
         "cells": [
          0,
          0,
          0,
          3333.0,
          3333.0,
          3333.0,
          3333.0,
          3333.0,
          3333.0
         ],
         "total": 19998.0
        },
        {
         "label": "Blue Cross Blue Shield of Michigan",
         "sub": "PAD-24-01-BCM",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          8416.66,
          8416.66
         ],
         "total": 16833.32
        },
        {
         "label": "Barnes & Thornburg",
         "sub": "THS-25-01-BAT",
         "flag": "Client by code",
         "cells": [
          2500.0,
          2500.0,
          2500.0,
          2500.0,
          2500.0,
          2500.0,
          0,
          0,
          0
         ],
         "total": 15000.0
        },
        {
         "label": "National Association of Chronic Disease Directors (NACDD)",
         "sub": "CMH-25-01-NAC5",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          15000.0,
          0,
          0,
          0
         ],
         "total": 15000.0
        },
        {
         "label": "Maine Health Access Foundation",
         "sub": "no Project Code",
         "cells": [
          3333.33,
          3333.33,
          3333.33,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 9999.99
        },
        {
         "label": "Addiction Professionals of North Carolina (APNC)",
         "sub": "BEH-25-02-APN",
         "cells": [
          1500.0,
          1500.0,
          1500.0,
          1500.0,
          1500.0,
          1500.0,
          0,
          0,
          0
         ],
         "total": 9000.0
        },
        {
         "label": "High Watch Recovery Center",
         "sub": "no Project Code",
         "cells": [
          8333.33,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 8333.33
        },
        {
         "label": "Alliance of Community Health Plans",
         "sub": "THS-26-01-ACH",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          7500.0
         ],
         "total": 7500.0
        },
        {
         "label": "Addiction Professionals of North Carolina (APNC)",
         "sub": "THS-26-02-APN2",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          1500.0
         ],
         "total": 1500.0
        },
        {
         "label": "Intermountain Healthcare",
         "sub": "PAD-26-01-IMT",
         "cells": [
          0,
          0,
          0,
          0,
          0.0,
          0,
          0,
          416.67,
          416.67
         ],
         "total": 833.34
        },
        {
         "label": "Health Plan Alliance",
         "sub": "CMH-25-01-HPA",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          1.0
         ],
         "total": 1.0
        }
       ]
      },
      {
       "label": "41200 - Subscription Revenue",
       "cells": [
        36000.0,
        1666.67,
        5000.0,
        6666.67,
        7083.34,
        7916.67,
        7916.67,
        3333.34,
        9450.01
       ],
       "total": 85033.37,
       "children": [
        {
         "label": "41210 - DaaS Subscrptions",
         "cells": [
          0,
          1666.67,
          5000.0,
          6666.67,
          7083.34,
          7916.67,
          7916.67,
          3333.34,
          9450.01
         ],
         "total": 49033.37,
         "children": [
          {
           "label": "MJ Insurance",
           "sub": "PAD-26-01-MJI",
           "cells": [
            0,
            0,
            3333.33,
            3333.33,
            3333.33,
            3333.33,
            3333.33,
            0,
            0
           ],
           "total": 16666.65
          },
          {
           "label": "One Utah Health Collaborative",
           "sub": "PAD-26-01-UHC",
           "cells": [
            0,
            1666.67,
            1666.67,
            1666.67,
            1666.67,
            1666.67,
            1666.67,
            1666.67,
            4791.67
           ],
           "total": 16458.36
          },
          {
           "label": "Sanford",
           "sub": "PAD-26-01-SAN",
           "cells": [
            0,
            0,
            0,
            1666.67,
            1666.67,
            1666.67,
            1666.67,
            1666.67,
            1666.67
           ],
           "total": 10000.02
          },
          {
           "label": "REDi Health",
           "sub": "PAD-26-02-RED",
           "flag": "Client by code",
           "cells": [
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            1666.67
           ],
           "total": 1666.67
          },
          {
           "label": "The Kennedy Forum",
           "sub": "MAR-24-01-TKF9",
           "flag": "Client by code",
           "cells": [
            0,
            0,
            0,
            0,
            0,
            833.33,
            833.33,
            0,
            0
           ],
           "total": 1666.66
          },
          {
           "label": "Intermountain Healthcare",
           "sub": "PAD-26-01-IMT",
           "cells": [
            0,
            0,
            0,
            0,
            416.67,
            416.67,
            416.67,
            0,
            0
           ],
           "total": 1250.01
          },
          {
           "label": "Silver Hill Hospital",
           "sub": "PAD-26-01-SHH",
           "flag": "Client by code",
           "cells": [
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            1250.0
           ],
           "total": 1250.0
          },
          {
           "label": "Recreate Behavioral Health Network",
           "sub": "PAD-26-01-RBH",
           "cells": [
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            75.0
           ],
           "total": 75.0
          }
         ]
        },
        {
         "label": "41220 - Member Dues",
         "cells": [
          36000.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 36000.0,
         "children": [
          {
           "label": "American Hospital Association (Alliance)",
           "sub": "BEH-24-01-AHA",
           "cells": [
            36000.0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
           ],
           "total": 36000.0
          }
         ]
        }
       ]
      }
     ]
    },
    {
     "label": "42000 - Non-Recurring Revenue (Variable)",
     "cells": [
      509410.09,
      520595.66,
      539957.1,
      557033.81,
      618660.2,
      710309.78,
      607386.02,
      581887.83,
      545124.39
     ],
     "total": 5190364.88,
     "children": [
      {
       "label": "42100 - Fixed Fee",
       "cells": [
        486930.0,
        507189.0,
        493028.25,
        507138.31,
        573162.62,
        645811.8,
        554455.02,
        526053.08,
        531901.61
       ],
       "total": 4825669.69,
       "children": [
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD-25-03-MMA",
         "cells": [
          58392.0,
          58392.0,
          58392.0,
          58392.0,
          58392.0,
          58392.0,
          58392.0,
          58392.0,
          58392.0
         ],
         "total": 525528.0
        },
        {
         "label": "Oregon Health Authority - ADPC",
         "sub": "BEH-25-02-ORE",
         "cells": [
          50000.0,
          50000.0,
          50000.0,
          50000.0,
          50000.0,
          50000.0,
          50000.0,
          50000.0,
          54000.0
         ],
         "total": 454000.0
        },
        {
         "label": "National Council for Mental Wellbeing",
         "sub": "BEH-26-01-NCW",
         "cells": [
          0,
          0,
          0,
          52526.34,
          52526.34,
          52526.34,
          41764.51,
          41764.51,
          41764.51
         ],
         "total": 282872.55
        },
        {
         "label": "Innovation Development Institute, Inc (MATTER)",
         "sub": "CMH-24-01-SSH2",
         "cells": [
          0,
          0,
          90000.0,
          20000.0,
          20000.0,
          49000.0,
          49000.0,
          49000.0,
          0
         ],
         "total": 277000.0
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD-25-04-MMA-NNV",
         "cells": [
          0,
          0,
          0,
          0,
          0.0,
          53750.0,
          53750.0,
          53750.0,
          53750.0
         ],
         "total": 215000.0
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD-25-04-MMA-QUAL",
         "cells": [
          0,
          0,
          0,
          0.0,
          27755.0,
          27755.0,
          27755.0,
          27755.0,
          27755.0
         ],
         "total": 138775.0
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD 25-04-MMA-EPI",
         "cells": [
          0,
          0,
          0.0,
          41666.33,
          41666.33,
          41666.33,
          0,
          0,
          0
         ],
         "total": 124998.99
        },
        {
         "label": "Deloitte Consulting",
         "sub": "WWB-25-01-DEC",
         "cells": [
          0,
          0,
          30000.0,
          37500.0,
          6500.0,
          42500.0,
          0,
          0,
          7500.0
         ],
         "total": 124000.0
        },
        {
         "label": "New York State Office of Addiction Services and Supports",
         "sub": "BEH-25-01-NYS",
         "cells": [
          11343.33,
          -47798.0,
          -13755.42,
          -55277.7,
          0,
          0,
          0,
          0,
          0
         ],
         "total": -105487.79
        },
        {
         "label": "Alliance of Community Health Plans",
         "sub": "THS-26-01-ACH",
         "cells": [
          0,
          7500.0,
          7500.0,
          32500.0,
          22500.0,
          17500.0,
          7500.0,
          7500.0,
          0
         ],
         "total": 102500.0
        },
        {
         "label": "The Kennedy Forum",
         "sub": "MAR-24-01-TKF7",
         "cells": [
          20000.0,
          20000.0,
          20000.0,
          20000.0,
          5000.0,
          5000.0,
          5000.0,
          5000.0,
          0
         ],
         "total": 100000.0
        },
        {
         "label": "The Kennedy Forum",
         "sub": "MAR-24-01-TKF5",
         "cells": [
          12500.0,
          12500.0,
          12500.0,
          12500.0,
          12500.0,
          12500.0,
          12500.0,
          12500.0,
          0
         ],
         "total": 100000.0
        },
        {
         "label": "Elliot Health System",
         "sub": "BEH-26-01-EHS",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          25000.0,
          25000.0,
          25000.0,
          25000.0
         ],
         "total": 100000.0
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD-25-04-MMA-HRE",
         "cells": [
          100000.0,
          0.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 100000.0
        },
        {
         "label": "Marsh & McLennan Agency (Schedule F - Innovation)",
         "sub": "PAD 25-04-MMA-DRU",
         "cells": [
          0,
          100000.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 100000.0
        },
        {
         "label": "National Opinion Research Center - NORC",
         "sub": "BEH-26-01-NOR",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          41680.0,
          30810.0,
          26050.0
         ],
         "total": 98540.0
        },
        {
         "label": "The Kennedy Forum",
         "sub": "MAR-24-01-TKF6",
         "cells": [
          11750.0,
          11750.0,
          11750.0,
          11750.0,
          11750.0,
          11750.0,
          11750.0,
          11750.0,
          0
         ],
         "total": 94000.0
        },
        {
         "label": "American Medical Association",
         "sub": "CMH-25-01-AMA",
         "cells": [
          19167.0,
          19167.0,
          19167.0,
          19167.0,
          17035.28,
          0,
          0,
          0,
          0
         ],
         "total": 93703.28
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD-25-03-MMA-REGNET2",
         "cells": [
          0,
          0,
          0,
          0.0,
          30000.0,
          30000.0,
          30000.0,
          0,
          0
         ],
         "total": 90000.0
        },
        {
         "label": "The Clayton Christensen Institute for Disruptive Innovation, Inc.",
         "sub": "BEH-25-01-CCI",
         "cells": [
          24000.0,
          24000.0,
          24000.0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 72000.0
        },
        {
         "label": "One Utah Health Collaborative - BH Parity",
         "sub": "PAD-26-02-UHC",
         "cells": [
          0,
          0,
          0,
          0,
          21416.66,
          21416.66,
          21416.66,
          0,
          0
         ],
         "total": 64249.98
        },
        {
         "label": "New York State Office of Addiction Services and Supports",
         "sub": "BEH-24-01-NYS",
         "cells": [
          25000.0,
          25000.0,
          25000.0,
          25000.0,
          -4774.0,
          -16160.75,
          -49363.0,
          12284.0,
          19016.25
         ],
         "total": 61002.5
        },
        {
         "label": "National Association of Chronic Disease Directors (NACDD)",
         "sub": "CMH-25-01-NAC5",
         "cells": [
          20000.0,
          20000.0,
          20000.0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 60000.0
        },
        {
         "label": "Blue Cross Blue Shield of Michigan",
         "sub": "PAD-24-01-BCM",
         "cells": [
          8416.66,
          8416.66,
          8416.66,
          8416.66,
          8416.66,
          8416.66,
          8416.66,
          0,
          0
         ],
         "total": 58916.62
        },
        {
         "label": "The Kennedy Forum",
         "sub": "MAR-24-01-TKF9",
         "flag": "Client by code",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          13500.0,
          13500.0,
          14333.33,
          14333.33
         ],
         "total": 55666.66
        },
        {
         "label": "National Council for Mental Wellbeing",
         "sub": "BEH-24-01-NCM",
         "cells": [
          3000.0,
          3300.0,
          3100.0,
          3800.0,
          12300.0,
          9600.0,
          13000.0,
          3843.72,
          0
         ],
         "total": 51943.72
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD-25-04-MMA-CLMTIC",
         "cells": [
          6467.25,
          6467.25,
          6467.25,
          6467.25,
          12934.5,
          12934.5,
          0,
          0,
          0
         ],
         "total": 51738.0
        },
        {
         "label": "The Kennedy Forum - URAC",
         "sub": "MAR-24-01-TKF10",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          25000.0,
          25000.0
         ],
         "total": 50000.0
        },
        {
         "label": "The Clayton Christensen Institute for Disruptive Innovation, Inc.",
         "sub": "BEH-26-01-CCI",
         "cells": [
          0,
          0,
          0,
          11250.0,
          11250.0,
          11250.0,
          11250.0,
          0,
          0
         ],
         "total": 45000.0
        },
        {
         "label": "National Association of Chronic Disease Directors (NACDD)",
         "sub": "CMH-26-01-NAC1",
         "cells": [
          0,
          7500.0,
          7500.0,
          7500.0,
          7500.0,
          7500.0,
          7500.0,
          0,
          0
         ],
         "total": 45000.0
        },
        {
         "label": "Signal Behavioral Health Network",
         "sub": "BEH-25-01-SIG",
         "cells": [
          7500.0,
          7500.0,
          7500.0,
          7500.0,
          7500.0,
          7500.0,
          0,
          0,
          0
         ],
         "total": 45000.0
        },
        {
         "label": "Deloitte Consulting",
         "sub": "no Project Code",
         "cells": [
          0,
          0,
          0,
          0,
          42500.0,
          0,
          0,
          0,
          0
         ],
         "total": 42500.0
        },
        {
         "label": "Community Mental Health Fund",
         "sub": "BEH-25-01-CMH",
         "cells": [
          0,
          10230.0,
          10230.0,
          10230.0,
          10230.0,
          0,
          0,
          0,
          0
         ],
         "total": 40920.0
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD-25-03-MMA-REGNET3",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          40000.0
         ],
         "total": 40000.0
        },
        {
         "label": "Health Strategies of New Hampshire",
         "sub": "BEH-26-01-HSN",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          12500.0,
          12500.0,
          12500.0
         ],
         "total": 37500.0
        },
        {
         "label": "Denver Department of Public Health & Environment",
         "sub": "BEH-25-01-DPH",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          12500.0,
          12500.0,
          12500.0
         ],
         "total": 37500.0
        },
        {
         "label": "Pomegranate Market",
         "sub": "CMH-26-01-POM",
         "cells": [
          0,
          0,
          0,
          0,
          9375.0,
          9375.0,
          9375.0,
          9375.0,
          0
         ],
         "total": 37500.0
        },
        {
         "label": "The Kennedy Forum",
         "sub": "MAR-24-01-TKF4",
         "cells": [
          0,
          37500.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 37500.0
        },
        {
         "label": "Marsh & McLennan Agency (Schedule E - Enhance)",
         "sub": "PAD-25-03-MMA-SELECT1",
         "flag": "Client by code",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          36250.0
         ],
         "total": 36250.0
        },
        {
         "label": "Southwest Counseling Service",
         "sub": "BEH-25-01-SWC",
         "cells": [
          9000.0,
          9000.0,
          9000.0,
          9000.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 36000.0
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD 25-04-MMA-SPRX",
         "cells": [
          8937.0,
          8937.0,
          8937.0,
          8937.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 35748.0
        },
        {
         "label": "Sanford",
         "sub": "PAD-26-01-SAN",
         "cells": [
          0.0,
          0.0,
          0.0,
          35000.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 35000.0
        },
        {
         "label": "National Association of Chronic Disease Directors (NACDD)",
         "sub": "CMH-26-01-NAC2",
         "cells": [
          0,
          4167.0,
          4167.0,
          4167.0,
          4167.0,
          4167.0,
          4165.0,
          4333.33,
          4333.33
         ],
         "total": 33666.66
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD-25-04-MMA-PLTF",
         "cells": [
          0,
          0,
          0,
          0.0,
          16175.0,
          16175.0,
          0,
          0,
          0
         ],
         "total": 32350.0
        },
        {
         "label": "Maine Behavioral Health Foundation",
         "sub": "BEH-26-01-MBH",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          6250.0,
          12500.0,
          12500.0
         ],
         "total": 31250.0
        },
        {
         "label": "Rosecrance",
         "sub": "BEH-25-01-ROS",
         "cells": [
          0,
          0,
          0,
          30500.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 30500.0
        },
        {
         "label": "Complete Orthopedics",
         "sub": "PAD-26-01-COR",
         "cells": [
          0,
          30000.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 30000.0
        },
        {
         "label": "DCM Foundation",
         "sub": "CMH-26-01-DCM",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          10000.0,
          10000.0,
          10000.0
         ],
         "total": 30000.0
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD 25-03-MMA-APRDRG",
         "cells": [
          9412.0,
          9412.0,
          9412.0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 28236.0
        },
        {
         "label": "Colorado Department of Human Services",
         "sub": "BEH-26-01-CHS",
         "cells": [
          0,
          0,
          0,
          0,
          17842.08,
          9644.2,
          0,
          0,
          0
         ],
         "total": 27486.28
        },
        {
         "label": "The Kennedy Forum",
         "sub": "MAR-24-01-TKF8",
         "cells": [
          0,
          0,
          0,
          0,
          8333.33,
          16666.67,
          0,
          0,
          0
         ],
         "total": 25000.0
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD-26-01-MMA",
         "cells": [
          0,
          8333.33,
          8333.33,
          8333.33,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 24999.99
        },
        {
         "label": "Dream Engine Ventures",
         "sub": "CMH-25-01-DEV",
         "cells": [
          8000.0,
          8000.0,
          8000.0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 24000.0
        },
        {
         "label": "Part D Advisors",
         "sub": "no Project Code",
         "cells": [
          0,
          1750.0,
          3500.0,
          1750.0,
          0,
          1750.0,
          0,
          1750.0,
          13250.0
         ],
         "total": 23750.0
        },
        {
         "label": "The Lakes Treatment Center, Inc.",
         "sub": "PAD-25-01-LTC",
         "cells": [
          0,
          5625.0,
          14000.0,
          3625.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 23250.0
        },
        {
         "label": "Project Angel Heart",
         "sub": "BEH-25-01-PAH",
         "cells": [
          4571.43,
          4571.43,
          4571.43,
          4571.43,
          4571.43,
          0,
          0,
          0,
          0
         ],
         "total": 22857.15
        },
        {
         "label": "Health Plan Alliance",
         "sub": "CMH-25-01-HPA",
         "cells": [
          3500.0,
          3500.0,
          3500.0,
          3500.0,
          3500.0,
          3500.0,
          0,
          0,
          0
         ],
         "total": 21000.0
        },
        {
         "label": "NFI North",
         "sub": "BEH-26-01-NFI",
         "cells": [
          0.0,
          0.0,
          6666.67,
          6666.67,
          6666.67,
          0,
          0,
          0,
          0
         ],
         "total": 20000.01
        },
        {
         "label": "Axis Health System",
         "sub": "BEH-26-01-AHS",
         "cells": [
          6640.0,
          6640.0,
          6640.0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 19920.0
        },
        {
         "label": "Food is Medicine Coalition (FIMC)",
         "sub": "CMH-26-01-FIM",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          4353.86,
          4353.86,
          4353.86,
          4353.86
         ],
         "total": 17415.44
        },
        {
         "label": "Addiction Professionals of North Carolina (APNC)",
         "sub": "WWB-26-01-APN",
         "cells": [
          0,
          0,
          0,
          0,
          0.0,
          3825.0,
          3825.0,
          5525.0,
          3825.0
         ],
         "total": 17000.0
        },
        {
         "label": "Oregon Health Authority - ADPC",
         "sub": "BEH-25-01-ORE1",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          12000.0,
          2400.0,
          2400.0
         ],
         "total": 16800.0
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD-25-03-MMA-NETENH",
         "cells": [
          0,
          0,
          0,
          0.0,
          5000.0,
          5000.0,
          5000.0,
          0,
          0
         ],
         "total": 15000.0
        },
        {
         "label": "Moreton & Company",
         "sub": "PAD-26-01-MOR2",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          15000.0
         ],
         "total": 15000.0
        },
        {
         "label": "Project Angel Heart",
         "sub": "BEH-25-01-PAH1",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          5000.0,
          5000.0,
          5000.0,
          0
         ],
         "total": 15000.0
        },
        {
         "label": "McCall Behavioral Health Network",
         "sub": "BEH-25-01-MCC",
         "cells": [
          5000.0,
          5000.0,
          5000.0,
          0.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 15000.0
        },
        {
         "label": "Indiana Family and Social Services Admin, Division of Mental Health and Addictio",
         "sub": "BEH-25-01-IND",
         "cells": [
          15000.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 15000.0
        },
        {
         "label": "Easterseals New Hampshire",
         "sub": "BEH-26-01-ENH",
         "cells": [
          0,
          0,
          0,
          4000.0,
          4000.0,
          4000.0,
          0,
          0,
          0
         ],
         "total": 12000.0
        },
        {
         "label": "San Luis Valley Behavioral Health Group",
         "sub": "BEH-26-01-SLB",
         "cells": [
          0,
          0,
          0.0,
          3000.0,
          3000.0,
          3000.0,
          3000.0,
          0.0,
          0
         ],
         "total": 12000.0
        },
        {
         "label": "Intermountain -",
         "sub": "PAD-26-01-IMT2",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          6000.0,
          6000.0
         ],
         "total": 12000.0
        },
        {
         "label": "Axis Health System",
         "sub": "BEH-26-02-AHS",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          6000.0,
          6000.0,
          0
         ],
         "total": 12000.0
        },
        {
         "label": "Oregon Health Authority - ADPC",
         "sub": "BEH-25-01-ORE",
         "cells": [
          11000.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 11000.0
        },
        {
         "label": "Marsh & McLennan Agency",
         "sub": "PAD 25-03-MMA-REGNET",
         "flag": "Client by code",
         "cells": [
          10000.0,
          0.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 10000.0
        },
        {
         "label": "REDi Health",
         "sub": "PAD-26-01-RED",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          10000.0,
          0,
          0
         ],
         "total": 10000.0
        },
        {
         "label": "KidsTLC",
         "sub": "BEH-25-01-KID",
         "cells": [
          0,
          10000.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 10000.0
        },
        {
         "label": "Ascension Recovery Services",
         "sub": "BEH-25-01-ARS",
         "cells": [
          10000.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 10000.0
        },
        {
         "label": "Handl Health, Inc.",
         "sub": "PAD 25-01-MHH",
         "cells": [
          3333.33,
          3333.33,
          3333.33,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 9999.99
        },
        {
         "label": "HealthTeamWorks",
         "sub": "BEH-26-01-HTW",
         "cells": [
          0,
          0,
          0,
          1800.0,
          1800.0,
          1800.0,
          1800.0,
          1800.0,
          0
         ],
         "total": 9000.0
        },
        {
         "label": "MJ Insurance",
         "sub": "PAD-26-01-MJI",
         "cells": [
          0,
          0,
          0.0,
          0,
          0,
          0,
          0,
          3333.33,
          3333.33
         ],
         "total": 6666.66
        },
        {
         "label": "Blaine County Mental Well Being Initiative",
         "sub": "BEH-26-01-MWB",
         "cells": [
          0,
          6500.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 6500.0
        },
        {
         "label": "AARP",
         "sub": "no Project Code",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          5500.0,
          0,
          0
         ],
         "total": 5500.0
        },
        {
         "label": "Health Fitness Corporation",
         "sub": "no Project Code",
         "cells": [
          5000.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 5000.0
        },
        {
         "label": "Addiction Professionals of North Carolina (APNC)",
         "sub": "THS-26-01-APN",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          2925.0,
          2041.0,
          0,
          0
         ],
         "total": 4966.0
        },
        {
         "label": "AllHealth Network",
         "sub": "BEH-26-01-ALL",
         "cells": [
          0,
          0,
          0,
          0,
          1333.34,
          1333.33,
          1333.33,
          0,
          0
         ],
         "total": 4000.0
        },
        {
         "label": "Recreate Behavioral Health Network",
         "sub": "PAD-26-01-RBH",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          2500.0
         ],
         "total": 2500.0
        },
        {
         "label": "Addiction Professionals of North Carolina (APNC)",
         "sub": "BEH-25-02-APN",
         "cells": [
          0,
          0,
          0,
          0,
          2500.0,
          0,
          0,
          0,
          0
         ],
         "total": 2500.0
        },
        {
         "label": "Prairie States Enterprises",
         "sub": "no Project Code",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          595.0
         ],
         "total": 595.0
        },
        {
         "label": "Champaign-Urbana Public Health District",
         "sub": "no Project Code",
         "cells": [
          0,
          0,
          0,
          500.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 500.0
        },
        {
         "label": "Chestnut Health Systems",
         "sub": "BEH-26-01-CHT",
         "cells": [
          0,
          0,
          0,
          500.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 500.0
        },
        {
         "label": "Vitality Group",
         "sub": "no Project Code",
         "cells": [
          0,
          500.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 500.0
        },
        {
         "label": "Terry Group",
         "sub": "no Project Code",
         "cells": [
          0,
          495.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 495.0
        },
        {
         "label": "The Strategic Collaboration Group, Inc.",
         "sub": "no Project Code",
         "cells": [
          0,
          0,
          0,
          200.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 200.0
        },
        {
         "label": "Illinois Youth Tobacco Survey",
         "sub": "no Project Code",
         "cells": [
          0,
          0,
          0,
          200.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 200.0
        },
        {
         "label": "Project Oz",
         "sub": "no Project Code",
         "cells": [
          0,
          0,
          200.0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 200.0
        },
        {
         "label": "One Utah Health Collaborative",
         "sub": "PAD-26-01-UHC",
         "cells": [
          0,
          0.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 0.0
        },
        {
         "label": "Blaine County Mental Well Being Initiative",
         "sub": "BEH-25-01-BCO",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0.0
         ],
         "total": 0.0
        },
        {
         "label": "Intermountain Healthcare",
         "sub": "PAD-25-01-IMT",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0.0
         ],
         "total": 0.0
        }
       ]
      },
      {
       "label": "42300 - Time & Materials",
       "cells": [
        22480.09,
        13406.66,
        46928.85,
        49895.5,
        45497.58,
        64497.98,
        52931.0,
        55834.75,
        13222.78
       ],
       "total": 364695.19,
       "children": [
        {
         "label": "New York State Office of Addiction Services and Supports",
         "sub": "BEH-24-01-NYS",
         "cells": [
          0,
          0,
          0,
          0,
          29774.0,
          41160.75,
          28826.25,
          12716.0,
          5983.75
         ],
         "total": 118460.75
        },
        {
         "label": "Denver Department of Public Health & Environment",
         "sub": "BEH-25-01-DPH",
         "cells": [
          11812.5,
          9429.5,
          14881.25,
          23471.25,
          8345.0,
          12338.75,
          0,
          4312.5,
          0
         ],
         "total": 84590.75
        },
        {
         "label": "New York State Office of Addiction Services and Supports",
         "sub": "BEH-25-01-NYS",
         "cells": [
          0,
          0,
          25098.75,
          16839.25,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 41938.0
        },
        {
         "label": "Addiction Professionals of North Carolina (APNC)",
         "sub": "THS-26-01-APN",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          30000.0,
          0
         ],
         "total": 30000.0
        },
        {
         "label": "Michigan Dental Association",
         "sub": "no Project Code",
         "cells": [
          2450.0,
          2468.75,
          900.0,
          1075.0,
          0,
          10418.75,
          0,
          5806.25,
          0
         ],
         "total": 23118.75
        },
        {
         "label": "Recovery Link",
         "sub": "no Project Code",
         "cells": [
          6077.59,
          1508.41,
          5848.85,
          0,
          6878.58,
          579.73,
          157.5,
          0,
          0
         ],
         "total": 21050.66
        },
        {
         "label": "Moreton & Company",
         "sub": "PAD-26-01-MOR",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          20000.0,
          0,
          0
         ],
         "total": 20000.0
        },
        {
         "label": "Colorado Department of Human Services",
         "sub": "BEH-26-01-CHS",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          2875.0,
          3000.0,
          1500.0
         ],
         "total": 7375.0
        },
        {
         "label": "National Council for Mental Wellbeing",
         "sub": "BEH-26-01-NCW",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          922.25,
          0,
          5739.03
         ],
         "total": 6661.28
        },
        {
         "label": "Mutual of Omaha",
         "sub": "PAD-26-01-MOO",
         "cells": [
          0,
          0,
          0,
          6160.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 6160.0
        },
        {
         "label": "National Council for Mental Wellbeing",
         "sub": "BEH-24-01-NCM",
         "cells": [
          2140.0,
          0,
          200.0,
          1900.0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 4240.0
        },
        {
         "label": "Chestnut Health Systems",
         "sub": "BEH-26-01-CHT",
         "cells": [
          0,
          0,
          0,
          450.0,
          0,
          0,
          150.0,
          0,
          0
         ],
         "total": 600.0
        },
        {
         "label": "Katz Amsterdam Foundation",
         "sub": "no Project Code",
         "cells": [
          0,
          0,
          0,
          0,
          500.0,
          0,
          0,
          0,
          0
         ],
         "total": 500.0
        }
       ]
      }
     ]
    },
    {
     "label": "43000 - Other Revenue",
     "cells": [
      0,
      445.0,
      4489.63,
      16.28,
      0,
      0,
      450.0,
      0,
      0
     ],
     "total": 5400.91,
     "children": [
      {
       "label": "43200 - Other",
       "cells": [
        0,
        445.0,
        4489.63,
        16.28,
        0,
        0,
        450.0,
        0,
        0
       ],
       "total": 5400.91,
       "children": [
        {
         "label": "Health Plan Alliance",
         "sub": "CMH-25-01-HPA",
         "cells": [
          0,
          0,
          2625.83,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 2625.83
        },
        {
         "label": "Alliance of Community Health Plans",
         "sub": "THS-25-01-ACHP",
         "cells": [
          0,
          0,
          966.8,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 966.8
        },
        {
         "label": "Complete Orthopedics",
         "sub": "no Project Code",
         "cells": [
          0,
          0,
          897.0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 897.0
        },
        {
         "label": "National Association of Addiction Treatment Providers (NAATP)",
         "sub": "PAD-26-01-NAA",
         "cells": [
          0,
          0,
          0,
          0,
          0,
          0,
          450.0,
          0,
          0
         ],
         "total": 450.0
        },
        {
         "label": "Denver Department of Public Health & Environment",
         "sub": "BEH-25-01-DPH",
         "cells": [
          0,
          445.0,
          0,
          0,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 445.0
        },
        {
         "label": "National Council for Mental Wellbeing",
         "sub": "BEH-24-01-NCM",
         "cells": [
          0,
          0,
          0,
          16.28,
          0,
          0,
          0,
          0,
          0
         ],
         "total": 16.28
        }
       ]
      }
     ]
    }
   ]
  }
 ],
 "expense": [
  {
   "label": "61000 - Payroll Expenses",
   "cells": [
    460648.29,
    455077.45,
    438134.87,
    449217.5,
    460258.98,
    495718.87,
    478302.87,
    452555.88,
    474057.47
   ],
   "total": 4163972.18,
   "children": [
    {
     "label": "61100 - Wages",
     "cells": [
      391061.76,
      391928.01,
      374262.5,
      388444.81,
      388444.81,
      400297.46,
      408602.16,
      413792.09,
      420576.83
     ],
     "total": 3577410.43
    },
    {
     "label": "61150 - Payroll Taxes",
     "cells": [
      29665.16,
      30203.24,
      32599.28,
      26353.85,
      27418.14,
      27944.34,
      24659.82,
      27267.68,
      22462.78
     ],
     "total": 248574.29
    },
    {
     "label": "61200 - Wages - Bonus",
     "cells": [
      0,
      0,
      0,
      0,
      15000.0,
      25000.0,
      0,
      0,
      0
     ],
     "total": 40000.0
    },
    {
     "label": "61250 - 401K Fees",
     "cells": [
      1181.25,
      0,
      0,
      0,
      1263.2,
      0,
      1287.5,
      0,
      0
     ],
     "total": 3731.95
    },
    {
     "label": "61300 - 401K Match",
     "cells": [
      16018.22,
      8009.11,
      6905.6,
      7864.88,
      8464.88,
      7927.57,
      7960.37,
      8424.19,
      8462.24
     ],
     "total": 80037.06
    },
    {
     "label": "61350 - Health Insurance/HRA",
     "cells": [
      13431.91,
      22350.57,
      20829.83,
      17878.27,
      17320.27,
      22312.06,
      18618.01,
      18206.37,
      19801.62
     ],
     "total": 170748.91
    },
    {
     "label": "61400 - Cell Phone",
     "cells": [
      1934.72,
      2180.56,
      1991.94,
      1760.0,
      1760.0,
      1840.0,
      1920.0,
      1920.0,
      2000.0
     ],
     "total": 17307.22
    },
    {
     "label": "61600 - Other Employee Related Expenses",
     "cells": [
      7355.27,
      405.96,
      1545.72,
      6915.69,
      587.68,
      10397.44,
      15255.01,
      -17054.45,
      754.0
     ],
     "total": 26162.32,
     "children": [
      {
       "label": "61750 - Reimbursable Expenses",
       "cells": [
        0,
        0,
        595.72,
        124.99,
        37.68,
        10197.44,
        8628.53,
        -17874.45,
        0
       ],
       "total": 1709.91
      },
      {
       "label": "61800 - Wellbeing Benefit",
       "cells": [
        4711.73,
        200.0,
        200.0,
        6074.2,
        200.0,
        200.0,
        6151.48,
        200.0,
        204.0
       ],
       "total": 18141.41
      },
      {
       "label": "61850 - Professional Development",
       "cells": [
        2643.54,
        205.96,
        750.0,
        716.5,
        350.0,
        0,
        475.0,
        620.0,
        550.0
       ],
       "total": 6311.0
      }
     ]
    }
   ]
  },
  {
   "label": "62000 - Business Development Expenses",
   "cells": [
    73.0,
    0,
    2238.48,
    662.4,
    0,
    2238.48,
    0,
    399.11,
    0
   ],
   "total": 5611.47,
   "children": [
    {
     "label": "62100 - Business Development",
     "cells": [
      73.0,
      0,
      2238.48,
      587.4,
      0,
      2238.48,
      0,
      0,
      0
     ],
     "total": 5137.36
    },
    {
     "label": "62300 - Conference Registration",
     "cells": [
      0,
      0,
      0,
      75.0,
      0,
      0,
      0,
      399.11,
      0
     ],
     "total": 474.11
    }
   ]
  },
  {
   "label": "63000 - Professional Fees",
   "cells": [
    29504.7,
    66546.15,
    39147.29,
    36843.2,
    58162.75,
    37051.44,
    58533.58,
    49131.3,
    20355.08
   ],
   "total": 395275.49,
   "children": [
    {
     "label": "63100 - Accounting",
     "cells": [
      2300.0,
      13800.0,
      4600.0,
      4600.0,
      4600.0,
      4600.0,
      4600.0,
      2655.0,
      2655.0
     ],
     "total": 44410.0
    },
    {
     "label": "63200 - IT Support",
     "cells": [
      2698.2,
      2698.2,
      2698.2,
      2698.2,
      2700.83,
      1973.91,
      2700.83,
      2700.83,
      2928.83
     ],
     "total": 23798.03
    },
    {
     "label": "63300 - Legal & Professional Services",
     "cells": [
      1000.0,
      36344.2,
      7601.96,
      0,
      0,
      3290.03,
      0,
      3569.0,
      0
     ],
     "total": 51805.19
    },
    {
     "label": "63800 - Contractors/Advisors",
     "cells": [
      23506.5,
      13703.75,
      24247.13,
      29545.0,
      50861.92,
      27187.5,
      51232.75,
      40206.47,
      14771.25
     ],
     "total": 275262.27,
     "children": [
      {
       "label": "63810 - Data Advisors",
       "cells": [
        21506.5,
        8500.0,
        16679.0,
        8525.0,
        39586.92,
        7025.0,
        8300.0,
        5000.0,
        5000.0
       ],
       "total": 120122.42
      },
      {
       "label": "63820 - Actuarial Advisors",
       "cells": [
        0,
        228.75,
        343.13,
        7995.0,
        0,
        0,
        2728.13,
        4426.88,
        686.25
       ],
       "total": 16408.14
      },
      {
       "label": "63830 - General Advisors",
       "cells": [
        2000.0,
        2000.0,
        2000.0,
        2000.0,
        2000.0,
        5125.0,
        23404.62,
        24004.59,
        1500.0
       ],
       "total": 64034.21
      },
      {
       "label": "63840 - Well-being Coaches",
       "cells": [
        0,
        2975.0,
        5225.0,
        11025.0,
        4475.0,
        6975.0,
        9600.0,
        4375.0,
        4525.0
       ],
       "total": 49175.0
      },
      {
       "label": "63850 - Interns",
       "cells": [
        0,
        0,
        0,
        0,
        4800.0,
        7200.0,
        7200.0,
        2400.0,
        3060.0
       ],
       "total": 24660.0
      },
      {
       "label": "63890 - Design",
       "cells": [
        0,
        0,
        0,
        0,
        0,
        862.5,
        0,
        0,
        0
       ],
       "total": 862.5
      }
     ]
    }
   ]
  },
  {
   "label": "64000 - Company Retreat",
   "cells": [
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    520.0
   ],
   "total": 520.0
  },
  {
   "label": "65000 - Dues & Subscription",
   "cells": [
    137848.62,
    114882.22,
    88716.31,
    182054.79,
    133626.89,
    148152.09,
    143032.3,
    124088.76,
    96230.2
   ],
   "total": 1168632.18,
   "children": [
    {
     "label": "65100 - Technology Resources",
     "cells": [
      0.0,
      0.0,
      0.0,
      0.0,
      241.39,
      458.53,
      794.17,
      912.91,
      1119.25
     ],
     "total": 3526.25
    },
    {
     "label": "65200 - Data Services",
     "cells": [
      127616.41,
      104790.77,
      75946.41,
      168948.98,
      107933.36,
      134031.41,
      128524.46,
      98443.64,
      79046.73
     ],
     "total": 1025282.17
    },
    {
     "label": "65300 - Business Administration",
     "cells": [
      6848.23,
      4877.18,
      4561.07,
      4561.07,
      7695.91,
      4393.38,
      4403.21,
      8685.3,
      10653.85
     ],
     "total": 56679.2
    },
    {
     "label": "65400 - Mindful Learning - Dues/Subs",
     "cells": [
      67.8,
      15.0,
      15.0,
      15.0,
      15.0,
      15.0,
      15.0,
      15.0,
      45.36
     ],
     "total": 218.16
    },
    {
     "label": "65500 - News & Periodicals",
     "cells": [
      81.99,
      77.99,
      576.99,
      77.99,
      77.99,
      142.98,
      109.99,
      269.0,
      109.99
     ],
     "total": 1524.91
    },
    {
     "label": "65600 - Web Services",
     "cells": [
      14.07,
      418.13,
      905.9,
      467.15,
      6374.02,
      670.0,
      0,
      9281.97,
      17.25
     ],
     "total": 18148.49
    },
    {
     "label": "65800 - Subscriptions",
     "cells": [
      3220.12,
      4703.15,
      6710.94,
      7984.6,
      11289.22,
      8440.79,
      9185.47,
      6480.94,
      2737.77
     ],
     "total": 60753.0
    },
    {
     "label": "65900 - Memberships",
     "cells": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2500.0
     ],
     "total": 2500.0
    }
   ]
  },
  {
   "label": "66000 - Uncompensated Travel & Entertainment",
   "cells": [
    6525.43,
    11450.86,
    19985.41,
    8972.06,
    21820.99,
    8173.39,
    15730.2,
    14758.99,
    11306.43
   ],
   "total": 118723.76,
   "children": [
    {
     "label": "66100 - Airfare",
     "cells": [
      2583.69,
      6035.46,
      10792.97,
      4229.31,
      4235.21,
      3866.97,
      7053.1,
      4801.48,
      4682.4
     ],
     "total": 48280.59
    },
    {
     "label": "66200 - Ground Transport",
     "cells": [
      427.1,
      1146.62,
      2787.93,
      1609.32,
      3320.44,
      747.91,
      1021.99,
      3214.29,
      879.59
     ],
     "total": 15155.19
    },
    {
     "label": "66250 - Hotel",
     "cells": [
      2121.45,
      2475.09,
      4403.16,
      2484.31,
      12408.22,
      2132.43,
      5344.29,
      4024.24,
      3826.11
     ],
     "total": 39219.3
    },
    {
     "label": "66300 - Airplane WiFi",
     "cells": [
      0,
      0,
      0,
      0,
      16.0,
      0,
      0,
      16.0,
      0
     ],
     "total": 32.0
    },
    {
     "label": "66350 - Meals & Entertainment",
     "cells": [
      451.8,
      793.96,
      1544.58,
      499.12,
      1524.72,
      836.24,
      1675.9,
      2364.32,
      617.04
     ],
     "total": 10307.68
    },
    {
     "label": "66400 - Meals (Group)",
     "cells": [
      0,
      0,
      456.77,
      150.0,
      0,
      456.21,
      327.71,
      0,
      975.74
     ],
     "total": 2366.43
    },
    {
     "label": "66450 - Business Meals (Client)",
     "cells": [
      152.1,
      874.62,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 1026.72
    },
    {
     "label": "66500 - Mileage",
     "cells": [
      789.29,
      125.11,
      0.0,
      0,
      316.4,
      133.63,
      307.21,
      338.66,
      325.55
     ],
     "total": 2335.85
    }
   ]
  },
  {
   "label": "67000 - Rent & Occupancy",
   "cells": [
    24970.95,
    19960.05,
    19977.21,
    21053.35,
    21967.28,
    20862.13,
    21072.4,
    21097.4,
    20222.4
   ],
   "total": 191183.17,
   "children": [
    {
     "label": "67100 - Rent & Lease",
     "cells": [
      19908.81,
      19023.81,
      19056.81,
      20125.03,
      20125.03,
      20125.03,
      20125.03,
      20125.03,
      19275.03
     ],
     "total": 177889.61
    },
    {
     "label": "67200 - Utilities",
     "cells": [
      5062.14,
      710.02,
      694.18,
      702.1,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 7168.44
    },
    {
     "label": "67400 - Chicago Office Expenses",
     "cells": [
      0,
      226.22,
      226.22,
      226.22,
      1842.25,
      737.1,
      947.37,
      972.37,
      947.37
     ],
     "total": 6125.12
    }
   ]
  },
  {
   "label": "68000 - General Overhead",
   "cells": [
    15903.56,
    5539.76,
    7684.73,
    2982.05,
    8994.01,
    15386.47,
    4262.27,
    6214.78,
    4398.13
   ],
   "total": 71365.76,
   "children": [
    {
     "label": "68100 - Office Supplies",
     "cells": [
      1765.53,
      776.19,
      826.03,
      610.33,
      732.01,
      566.33,
      434.23,
      1738.01,
      461.98
     ],
     "total": 7910.64
    },
    {
     "label": "68250 - Printing",
     "cells": [
      0,
      1283.41,
      0,
      0,
      0,
      325.0,
      0,
      0,
      0
     ],
     "total": 1608.41
    },
    {
     "label": "68350 - Business Insurance",
     "cells": [
      5173.11,
      2272.86,
      6733.43,
      2272.86,
      7834.36,
      12794.36,
      3125.36,
      4007.36,
      3125.36
     ],
     "total": 47339.06
    },
    {
     "label": "68400 - Charitable Contributions",
     "cells": [
      0,
      200.0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
     ],
     "total": 200.0
    },
    {
     "label": "68500 - State Taxes and Fees",
     "cells": [
      0,
      0,
      0,
      0,
      25.0,
      0,
      0,
      0,
      562.68
     ],
     "total": 587.68
    },
    {
     "label": "68550 - Taxes & Licenses",
     "cells": [
      8364.0,
      0,
      0,
      0,
      0,
      297.0,
      548.75,
      0,
      0
     ],
     "total": 9209.75
    },
    {
     "label": "68600 - Bad Debt",
     "cells": [
      0,
      0,
      0,
      0,
      186.67,
      0,
      0,
      0,
      0
     ],
     "total": 186.67
    },
    {
     "label": "68700 - Bank Charges & Fees",
     "cells": [
      600.92,
      1007.3,
      125.27,
      98.86,
      215.97,
      1403.78,
      153.93,
      469.41,
      248.11
     ],
     "total": 4323.55
    }
   ]
  },
  {
   "label": "69000 - Depreciation and Amortization",
   "cells": [
    1726.47,
    1726.47,
    1726.47,
    1726.47,
    1726.47,
    1726.47,
    1726.47,
    1924.9,
    2040.97
   ],
   "total": 16051.16,
   "children": [
    {
     "label": "69100 - Depreciation Expense",
     "cells": [
      370.92,
      370.92,
      370.92,
      370.92,
      370.92,
      370.92,
      370.92,
      569.35,
      685.42
     ],
     "total": 3851.21
    },
    {
     "label": "69200 - Amortization",
     "cells": [
      1355.55,
      1355.55,
      1355.55,
      1355.55,
      1355.55,
      1355.55,
      1355.55,
      1355.55,
      1355.55
     ],
     "total": 12199.95
    }
   ]
  }
 ],
 "otherIncome": [
  {
   "label": "70005 - Other Income & Tax Refunds",
   "cells": [
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    36896.7
   ],
   "total": 36896.7
  }
 ],
 "otherExpense": [
  {
   "label": "70010 - Interest Paid",
   "cells": [
    16485.28,
    6354.18,
    0,
    0,
    12381.74,
    5999.06,
    4725.65,
    7596.88,
    3607.27
   ],
   "total": 57150.06
  },
  {
   "label": "70020 - Interest Accrued",
   "cells": [
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    527.86,
    408.28
   ],
   "total": 936.14
  },
  {
   "label": "70060 - Factoring Fees",
   "cells": [
    6864.05,
    3979.85,
    4537.23,
    2767.54,
    11022.71,
    4736.8,
    5642.08,
    4603.31,
    8984.53
   ],
   "total": 53138.1
  },
  {
   "label": "70070 - Other Expense",
   "cells": [
    0,
    0,
    0,
    0,
    31246.35,
    0,
    0,
    91851.79,
    7824.37
   ],
   "total": 130922.51
  }
 ],
 "totals": {
  "income": {
   "cells": [
    598243.42,
    641348.66,
    608946.73,
    676857.76,
    672743.21,
    780226.12,
    715955.78,
    648720.84,
    647075.07
   ],
   "total": 5990117.59
  },
  "expense": {
   "cells": [
    677201.02,
    675182.96,
    617610.77,
    703511.82,
    706557.37,
    729309.34,
    722660.09,
    670171.12,
    629130.68
   ],
   "total": 6131335.17
  },
  "ordinary": {
   "cells": [
    -78957.6,
    -33834.3,
    -8664.04,
    -26654.06,
    -33814.16,
    50916.78,
    -6704.31,
    -21450.28,
    17944.39
   ],
   "total": -141217.58
  },
  "otherIncome": {
   "cells": [
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    36896.7
   ],
   "total": 36896.7
  },
  "otherExpense": {
   "cells": [
    23349.33,
    10334.03,
    4537.23,
    2767.54,
    54650.8,
    10735.86,
    10367.73,
    104579.84,
    20824.45
   ],
   "total": 242146.81
  },
  "net": {
   "cells": [
    -102306.93,
    -44168.33,
    -13201.27,
    -29421.6,
    -88464.96,
    40180.92,
    -17072.04,
    -126030.12,
    34016.64
   ],
   "total": -346467.69
  }
 },
 "accountCount": 62
};
