// Generated from the live pro forma (SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, 2026 block,
// columns AD to AF) version 4626, saved October 25, 2026, 7:03 PM Central, read October 25, 2026, by the session's build_pf_q4.py. Do not edit by hand; regenerate.
export type Q4Total = { cells: number[]; total: number };
/** A sheet row: every cell a number (the sheet carries zeros, never blanks); assignable to DocRow. */
export type Q4Row = { label: string; sub?: string; flag?: string; cells: number[]; total: number; children?: Q4Row[] };
export type Q4Data = { readOn: string; savedAt: string; version: string; months: string[]; top: { base: Q4Total; forecasted: Q4Total; expenses: Q4Total; net: Q4Total }; sections: (Q4Row & { linesSum: number[] })[]; sectionsSum: Q4Total; expenseCats: Q4Row[]; expenseSum: Q4Total; purple: (Q4Row & { section: string })[]; yellow: (Q4Row & { section: string })[]; purpleTotal: number; yellowTotal: number; lineCount: number };

export const Q4: Q4Data = {
 "readOn": "October 25, 2026",
 "savedAt": "October 25, 2026, 7:03 PM Central",
 "version": "4626",
 "months": [
  "Oct",
  "Nov",
  "Dec"
 ],
 "top": {
  "base": {
   "cells": [
    756878.01,
    768994.68,
    790854.69
   ],
   "total": 2316727.38
  },
  "forecasted": {
   "cells": [
    756878.01,
    768994.68,
    790854.69
   ],
   "total": 2316727.38
  },
  "expenses": {
   "cells": [
    651803.36,
    651671.16,
    651536.86
   ],
   "total": 1955011.38
  },
  "net": {
   "cells": [
    105074.65,
    117323.52,
    139317.83
   ],
   "total": 361716.0
  }
 },
 "sections": [
  {
   "label": "BEH - Behavioral Health",
   "cells": [
    377017.17,
    351217.17,
    344967.17
   ],
   "total": 1073201.51,
   "children": [
    {
     "label": "American Medical Association (Platform)",
     "cells": [
      0.0,
      30000.0,
      30000.0
     ],
     "total": 60000.0,
     "sub": "NEW",
     "flag": "Assumption"
    },
    {
     "label": "Denver Public Health",
     "cells": [
      12500.0,
      12500.0,
      12500.0
     ],
     "total": 37500.0,
     "sub": "BEH-25-01-DPH"
    },
    {
     "label": "Denver Public Health (T&M Extenstion to BEH-25-01-DPH)",
     "cells": [
      0.0,
      15000.0,
      15000.0
     ],
     "total": 30000.0,
     "sub": "NEW",
     "flag": "Assumption"
    },
    {
     "label": "Health Strategies of NH",
     "cells": [
      12500.0,
      12500.0,
      12500.0
     ],
     "total": 37500.0,
     "sub": "BEH-26-01-HSN"
    },
    {
     "label": "Indiana Family and Social Services Admin 2026-2027",
     "cells": [
      45000.0,
      15000.0,
      15000.0
     ],
     "total": 75000.0,
     "sub": "BEH-26-01-IND"
    },
    {
     "label": "Maine Behavioral Health Foundation",
     "cells": [
      12500.0,
      6250.0,
      0.0
     ],
     "total": 18750.0,
     "sub": "BEH-26-01-MBH"
    },
    {
     "label": "National Council for Mental Wellbeing CCBHC TTA",
     "cells": [
      32067.5,
      32067.5,
      32067.5
     ],
     "total": 96202.5,
     "sub": "BEH-26-01-NCW"
    },
    {
     "label": "NFI North",
     "cells": [
      3333.0,
      3333.0,
      3333.0
     ],
     "total": 9999.0,
     "sub": "BEH-26-01-NFI"
    },
    {
     "label": "NORC - NH",
     "cells": [
      34550.0,
      0.0,
      0.0
     ],
     "total": 34550.0,
     "sub": "BEH-26-01-NOR"
    },
    {
     "label": "NYS - OASAS",
     "cells": [
      5000.0,
      5000.0,
      5000.0
     ],
     "total": 15000.0,
     "sub": "BEH-24-01-NYS"
    },
    {
     "label": "Oregon ADPC Extension - Amendment 2",
     "cells": [
      2400.0,
      2400.0,
      2400.0
     ],
     "total": 7200.0,
     "sub": "BEH-25-01-ORE1"
    },
    {
     "label": "Rosecrance (SUPR) - 2026-2027 renewal",
     "cells": [
      9666.67,
      9666.67,
      9666.67
     ],
     "total": 29000.01,
     "sub": "BEH-26-01-ROS"
    },
    {
     "label": "Signal BHN",
     "cells": [
      7500.0,
      7500.0,
      7500.0
     ],
     "total": 22500.0,
     "sub": "BEH-25-01-SIG/BEH-26-01-SIG"
    },
    {
     "label": "TRAC9 - WV RHTP SUD VBP",
     "cells": [
      200000.0,
      200000.0,
      200000.0
     ],
     "total": 600000.0,
     "sub": "BEH-26-01-WVR",
     "flag": "Yellow in the sheet"
    }
   ],
   "linesSum": [
    377017.17,
    351217.17,
    344967.17
   ]
  },
  {
   "label": "PAD - Payment Design & Analytics",
   "cells": [
    46999.67,
    45249.67,
    45249.67
   ],
   "total": 137499.01,
   "children": [
    {
     "label": "Ascension",
     "cells": [
      4000.0,
      8000.0,
      8000.0
     ],
     "total": 20000.0,
     "sub": "PAD-26-01-ARS"
    },
    {
     "label": "ATI Advisory",
     "cells": [
      2000.0,
      0.0,
      0.0
     ],
     "total": 2000.0,
     "sub": "PAD-26-01-ATI"
    },
    {
     "label": "Blue Cross Blue Shield of Michigan",
     "cells": [
      8416.0,
      8416.0,
      8416.0
     ],
     "total": 25248.0,
     "sub": "PAD-24-01-BCM"
    },
    {
     "label": "KPMG - Colorado Medicaid APMs",
     "cells": [
      10000.0,
      10000.0,
      10000.0
     ],
     "total": 30000.0,
     "sub": "PAD-24-01-KCM"
    },
    {
     "label": "Michigan Dental",
     "cells": [
      1000.0,
      1000.0,
      1000.0
     ],
     "total": 3000.0,
     "sub": "PAD-24-01-MID"
    },
    {
     "label": "Moreton USHE - retainer",
     "cells": [
      15000.0,
      15000.0,
      15000.0
     ],
     "total": 45000.0,
     "sub": "PAD-26-01-MOR2"
    },
    {
     "label": "REDi Health",
     "cells": [
      1666.67,
      1666.67,
      1666.67
     ],
     "total": 5000.01,
     "sub": "PAD-26-02-PAD (8.28.2026 - 8.27.2027)"
    },
    {
     "label": "SSNC",
     "cells": [
      9167.0,
      9167.0,
      9167.0
     ],
     "total": 27501.0,
     "sub": "PAD-24-01-SSC"
    },
    {
     "label": "Von Maur",
     "cells": [
      1750.0,
      0.0,
      0.0
     ],
     "total": 1750.0,
     "sub": "PAD-25-01-VON2"
    }
   ],
   "linesSum": [
    52999.67,
    53249.67,
    53249.67
   ]
  },
  {
   "label": "MAR - Market Analytics",
   "cells": [
    228840.66,
    247840.66,
    275950.66
   ],
   "total": 752631.98,
   "children": [
    {
     "label": "Intermountain - DaaS",
     "cells": [
      416.67,
      416.67,
      416.67
     ],
     "total": 1250.01,
     "sub": "PAD-26-01-IMT (5.14.2026 - 5.13.2027)"
    },
    {
     "label": "Intermountain -",
     "cells": [
      6000.0,
      6000.0,
      6000.0
     ],
     "total": 18000.0,
     "sub": "PAD-26-01-IMT2"
    },
    {
     "label": "Marsh & McLennan Agency (Schedule E - Core)",
     "cells": [
      58391.0,
      58391.0,
      0.0
     ],
     "total": 116782.0,
     "sub": "PAD-25-01-MMA; PAD 25-03-MMA"
    },
    {
     "label": "Marsh & McLennan Agency (Schedule E - Enhance)",
     "cells": [
      36250.0,
      36250.0,
      36250.0
     ],
     "total": 108750.0,
     "sub": "PAD 25-03-MMA-REGENT3"
    },
    {
     "label": "Marsh McLennan 2027",
     "cells": [
      0.0,
      0.0,
      125000.0
     ],
     "total": 125000.0,
     "sub": "no Project ID",
     "flag": "Assumption"
    },
    {
     "label": "MJ Insurance",
     "cells": [
      3333.33,
      3333.33,
      3333.33
     ],
     "total": 9999.99,
     "sub": "PAD-26-01-MJI (3.17.2026 - 3.16-2027)"
    },
    {
     "label": "MJ Insurance (Advisory $$)",
     "cells": [
      0.0,
      5000.0,
      5000.0
     ],
     "total": 10000.0,
     "sub": "no Project ID"
    },
    {
     "label": "One Utah Health Collaborative - DaaS",
     "cells": [
      4791.67,
      4791.67,
      4791.67
     ],
     "total": 14375.01,
     "sub": "PAD-26-01-UHC (2.17.2026 - 2.16.2027)"
    },
    {
     "label": "Oxbridge",
     "cells": [
      4000.0,
      8000.0,
      8000.0
     ],
     "total": 20000.0,
     "sub": "PAD-26-01-OBH"
    },
    {
     "label": "Recreate BH",
     "cells": [
      75.0,
      75.0,
      75.0
     ],
     "total": 225.0,
     "sub": "PAD-26-01-RBH (9.1.2026 = 8.31.2027"
    },
    {
     "label": "Sanford",
     "cells": [
      1666.66,
      1666.66,
      1666.66
     ],
     "total": 4999.98,
     "sub": "PAD-26-01-SAN (3.27.2026 - 3.26.2027)"
    },
    {
     "label": "Silver Hill Hospital",
     "cells": [
      1250.0,
      1250.0,
      1250.0
     ],
     "total": 3750.0,
     "sub": "PAD-26-01-SHH (Sept. 1, 2026 - Aug. 31, 2027)"
    },
    {
     "label": "Silver Hill Hospital (Success Fee)",
     "cells": [
      0.0,
      10000.0,
      10000.0
     ],
     "total": 20000.0,
     "sub": "Adjacent"
    },
    {
     "label": "The Kennedy Forum - Parity Index (AMA)",
     "cells": [
      33333.0,
      33333.0,
      33334.0
     ],
     "total": 100000.0,
     "sub": "MAR-24-02-TKF"
    },
    {
     "label": "The Kennedy Forum - BiPolar User Interface",
     "cells": [
      13500.0,
      13500.0,
      0.0
     ],
     "total": 27000.0,
     "sub": "MAR-24-01-TFK9"
    },
    {
     "label": "The Kennedy Forum - BiPolar User Interface - DaaS",
     "cells": [
      833.33,
      833.33,
      833.33
     ],
     "total": 2499.99,
     "sub": "MAR-24-01-TFK9 (6.1.2026 - 5.30.2027)"
    },
    {
     "label": "The Kennedy Forum - Illinois Workforce Tool",
     "cells": [
      40000.0,
      40000.0,
      40000.0
     ],
     "total": 120000.0,
     "sub": "NEW",
     "flag": "Assumption"
    },
    {
     "label": "The Kennedy Forum - URAC",
     "cells": [
      25000.0,
      25000.0,
      0.0
     ],
     "total": 50000.0,
     "sub": "MAR-24-01-TKF10"
    }
   ],
   "linesSum": [
    228840.66,
    247840.66,
    275950.66
   ]
  },
  {
   "label": "WWB - Workplace Well-Being",
   "cells": [
    0.0,
    0.0,
    0.0
   ],
   "total": 0.0,
   "children": [],
   "linesSum": [
    0,
    0,
    0
   ]
  },
  {
   "label": "CMH - Community Health",
   "cells": [
    26687.19,
    47353.86,
    47353.86
   ],
   "total": 121394.91,
   "children": [
    {
     "label": "DCM Foundation",
     "cells": [
      10000.0,
      10000.0,
      10000.0
     ],
     "total": 30000.0,
     "sub": "CMH-26-01-DCM"
    },
    {
     "label": "Food is Medicine Coalition (FIMC)",
     "cells": [
      4353.86,
      4353.86,
      4353.86
     ],
     "total": 13061.58,
     "sub": "CMH-26-01-FIM"
    },
    {
     "label": "National Association of Chronic Disease Directors - 10513",
     "cells": [
      4333.33,
      0.0,
      0.0
     ],
     "total": 4333.33,
     "sub": "CMH-26-01-NAC2"
    },
    {
     "label": "National Association of Chronic Disease Directory - Diabetes Y3",
     "cells": [
      0.0,
      25000.0,
      25000.0
     ],
     "total": 50000.0,
     "sub": "no Project ID"
    },
    {
     "label": "Project Angel Heart - Amendment 2",
     "cells": [
      8000.0,
      8000.0,
      8000.0
     ],
     "total": 24000.0,
     "sub": "BEH-25-01-PAH2"
    }
   ],
   "linesSum": [
    26687.19,
    47353.86,
    47353.86
   ]
  },
  {
   "label": "Third Horizon - General",
   "cells": [
    77333.33,
    77333.33,
    77333.34
   ],
   "total": 232000.0,
   "children": [
    {
     "label": "Alliance of Community Health Plans - AI",
     "cells": [
      7500.0,
      7500.0,
      7500.0
     ],
     "total": 22500.0,
     "sub": "THS-26-01-ACH"
    },
    {
     "label": "Alliance of Community Health Plans - AI 2",
     "cells": [
      30000.0,
      30000.0,
      30000.0
     ],
     "total": 90000.0,
     "sub": "no Project ID"
    },
    {
     "label": "APNC - MSA Schedule 1: Production Modules",
     "cells": [
      38333.33,
      38333.33,
      38333.34
     ],
     "total": 115000.0,
     "sub": "THS-26-02-APN1"
    },
    {
     "label": "APNC - MSA Schedule 2: Strategic Advisory",
     "cells": [
      1500.0,
      1500.0,
      1500.0
     ],
     "total": 4500.0,
     "sub": "THS-26-02-APN2"
    }
   ],
   "linesSum": [
    77333.33,
    77333.33,
    77333.34
   ]
  }
 ],
 "sectionsSum": {
  "cells": [
   756878.02,
   768994.69,
   790854.7
  ],
  "total": 2316727.41
 },
 "expenseCats": [
  {
   "label": "Contractors",
   "cells": [
    45351.54,
    45351.54,
    45351.54
   ],
   "total": 136054.62,
   "children": [
    {
     "label": "Contractors",
     "sub": "the lump",
     "cells": [
      30000.0,
      30000.0,
      30000.0
     ],
     "total": 90000.0
    },
    {
     "label": "Anatomy IT",
     "cells": [
      3000.0,
      3000.0,
      3000.0
     ],
     "total": 9000.0
    },
    {
     "label": "Health Team Works",
     "cells": [
      10851.54,
      10851.54,
      10851.54
     ],
     "total": 32554.62
    },
    {
     "label": "Well-being Coaches",
     "cells": [
      1500.0,
      1500.0,
      1500.0
     ],
     "total": 4500.0
    }
   ]
  },
  {
   "label": "Payroll Expenses",
   "cells": [
    450650.0,
    450650.0,
    450650.0
   ],
   "total": 1351950.0,
   "children": [
    {
     "label": "Payroll Expenses",
     "sub": "the lump",
     "cells": [
      448000.0,
      448000.0,
      448000.0
     ],
     "total": 1344000.0
    },
    {
     "label": "Wellbeing Benefit",
     "cells": [
      2650.0,
      2650.0,
      2650.0
     ],
     "total": 7950.0
    }
   ]
  },
  {
   "label": "Bank Charges & Fees",
   "cells": [
    250.0,
    250.0,
    250.0
   ],
   "total": 750.0
  },
  {
   "label": "Financing Expenses",
   "cells": [
    3000.0,
    3000.0,
    3000.0
   ],
   "total": 9000.0
  },
  {
   "label": "Business Development",
   "cells": [
    4500.0,
    4500.0,
    4500.0
   ],
   "total": 13500.0,
   "children": [
    {
     "label": "Advertising & Marketing",
     "cells": [
      500.0,
      500.0,
      500.0
     ],
     "total": 1500.0
    },
    {
     "label": "Conference Sponsorship",
     "cells": [
      1000.0,
      1000.0,
      1000.0
     ],
     "total": 3000.0
    },
    {
     "label": "Terry Group Contract Purchased (Amortized)",
     "cells": [
      3000.0,
      3000.0,
      3000.0
     ],
     "total": 9000.0
    }
   ]
  },
  {
   "label": "Business Insurance",
   "cells": [
    3333.33,
    3333.33,
    3333.33
   ],
   "total": 9999.99
  },
  {
   "label": "Cell Phone (Verizon Company Account Included)",
   "cells": [
    2000.0,
    2000.0,
    2000.0
   ],
   "total": 6000.0
  },
  {
   "label": "Interest Paid",
   "cells": [
    1732.13,
    1599.93,
    1465.63
   ],
   "total": 4797.69
  },
  {
   "label": "Legal and Professional Services",
   "cells": [
    5000.0,
    5000.0,
    5000.0
   ],
   "total": 15000.0
  },
  {
   "label": "Office Supplies & Technology",
   "cells": [
    875.0,
    875.0,
    875.0
   ],
   "total": 2625.0
  },
  {
   "label": "Professional Development",
   "cells": [
    583.33,
    583.33,
    583.33
   ],
   "total": 1749.99
  },
  {
   "label": "Rent & Lease",
   "cells": [
    20445.03,
    20445.03,
    20445.03
   ],
   "total": 61335.09,
   "children": [
    {
     "label": "Connectiucut",
     "cells": [
      850.0,
      850.0,
      850.0
     ],
     "total": 2550.0
    },
    {
     "label": "Chicago, IL (Including New Office)",
     "cells": [
      19275.03,
      19275.03,
      19275.03
     ],
     "total": 57825.09
    },
    {
     "label": "New Hampshire",
     "cells": [
      320.0,
      320.0,
      320.0
     ],
     "total": 960.0
    }
   ]
  },
  {
   "label": "State Taxes and Fees",
   "cells": [
    83.33,
    83.33,
    83.33
   ],
   "total": 249.99
  },
  {
   "label": "Subscriptions/SaaS Administration Tools",
   "cells": [
    10333.33,
    10333.33,
    10333.33
   ],
   "total": 30999.99
  },
  {
   "label": "Uncompensated Travel",
   "cells": [
    8333.34,
    8333.34,
    8333.34
   ],
   "total": 25000.02
  },
  {
   "label": "Project Starset",
   "cells": [
    95333.0,
    95333.0,
    95333.0
   ],
   "total": 285999.0,
   "children": [
    {
     "label": "Siftia / Extendo (Ongoing Maintenance & Support)",
     "cells": [
      12500.0,
      12500.0,
      12500.0
     ],
     "total": 37500.0
    },
    {
     "label": "Meco Cloud (Google Cloud)",
     "cells": [
      30000.0,
      30000.0,
      30000.0
     ],
     "total": 90000.0
    },
    {
     "label": "Komodo",
     "cells": [
      20833.0,
      20833.0,
      20833.0
     ],
     "total": 62499.0
    },
    {
     "label": "Internology",
     "cells": [
      12000.0,
      12000.0,
      12000.0
     ],
     "total": 36000.0
    },
    {
     "label": "Candor",
     "cells": [
      20000.0,
      20000.0,
      20000.0
     ],
     "total": 60000.0
    }
   ]
  }
 ],
 "expenseSum": {
  "cells": [
   651803.36,
   651671.16,
   651536.86
  ],
  "total": 1955011.38
 },
 "purple": [
  {
   "label": "American Medical Association (Platform)",
   "cells": [
    0.0,
    30000.0,
    30000.0
   ],
   "total": 60000.0,
   "sub": "NEW",
   "flag": "Assumption",
   "section": "BEH - Behavioral Health"
  },
  {
   "label": "Denver Public Health (T&M Extenstion to BEH-25-01-DPH)",
   "cells": [
    0.0,
    15000.0,
    15000.0
   ],
   "total": 30000.0,
   "sub": "NEW",
   "flag": "Assumption",
   "section": "BEH - Behavioral Health"
  },
  {
   "label": "Marsh McLennan 2027",
   "cells": [
    0.0,
    0.0,
    125000.0
   ],
   "total": 125000.0,
   "sub": "no Project ID",
   "flag": "Assumption",
   "section": "MAR - Market Analytics"
  },
  {
   "label": "The Kennedy Forum - Illinois Workforce Tool",
   "cells": [
    40000.0,
    40000.0,
    40000.0
   ],
   "total": 120000.0,
   "sub": "NEW",
   "flag": "Assumption",
   "section": "MAR - Market Analytics"
  }
 ],
 "yellow": [
  {
   "label": "TRAC9 - WV RHTP SUD VBP",
   "cells": [
    200000.0,
    200000.0,
    200000.0
   ],
   "total": 600000.0,
   "sub": "BEH-26-01-WVR",
   "flag": "Yellow in the sheet",
   "section": "BEH - Behavioral Health"
  }
 ],
 "purpleTotal": 335000.0,
 "yellowTotal": 600000.0,
 "lineCount": 50
};
