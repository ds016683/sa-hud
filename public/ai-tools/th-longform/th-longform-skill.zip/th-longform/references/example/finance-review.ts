// =============================================================================
// COMPANY FINANCE REVIEW (/finance-review) , David's working surface for the
// finance review: long-form pages on the th-longform surface (the contents
// rail, the CIP canon), prose-anchored, with the books' tables and charts set
// inline and a Next at the foot of every page. Born 10/25 on a branch of the
// proposals repo; moved to its own surface 10/26. Pages arrive one at a time
// on David's word.
//
// Data: page 1 is the NetSuite income statement (content/finance-review-ns-data.ts,
// pulled over SuiteQL); the pro forma's January to September block
// (content/finance-review-data.ts) stays for page 1's comparison; the October
// to December estimate and the cash worksheet are read live from the
// SharePoint workbook at request time (lib/finance-source.ts), with the
// committed snapshot (content/finance-review-live-snapshot.json) as the
// fallback. Labels are the sources' own; nothing is hand-typed.
// =============================================================================
import type { DocBlock, DocCard, DocPage, DocRow, PlanPerson } from "./doc";
import { NS } from "./finance-review-ns-data";
import { PF } from "./finance-review-data";
import { SNAPSHOT } from "@/lib/finance-source";
import type { FinanceLive, Q4Live, CashLive, LiveSource, LiveRow } from "@/lib/finance-live";
import { CSOG, MICRO } from "./finance-review-micro";
import { CAPITAL } from "./finance-review-capital";

const money = (x: number) => (x < 0 ? `($${Math.abs(x).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })})` : `$${x.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
const whole = (x: number) => (x < 0 ? `($${Math.abs(Math.round(x)).toLocaleString("en-US")})` : `$${Math.round(x).toLocaleString("en-US")}`);
const T = NS.totals;

// David's NetSuite income statement screenshot (Jan to Sep aggregate, 10/25): the
// three lines the API role cannot see, and the report's revenue total.
const SCREEN = { totalIncome: 5991567.5, ticketSales: 1449.91, cellPhone: 17107.23, wellbeing: 18121.76 };
const roleTypes = "checks, credit memos, invoices, journal entries and vendor bills";

const rows: DocRow[] = [
  ...NS.income,
  { label: "Total - Income", cells: T.income.cells, total: T.income.total, style: "total",
    note: `Every income account with activity in the nine closed periods, as the API returns it. The NetSuite income statement report shows ${money(SCREEN.totalIncome)}, which is this figure plus 43400 - Ticket Sales at ${money(SCREEN.ticketSales)}: that account has no transaction lines visible to the integration role, which reads ${roleTypes} only.` },
  ...NS.expense,
  { label: "Total - Expense", cells: T.expense.cells, total: T.expense.total, style: "total",
    note: `Every expense account with activity, parents opening to their accounts. Two lines run above the report by small amounts: 61400 - Cell Phone (${money(17307.22)} here against ${money(SCREEN.cellPhone)} on the report) and 61800 - Wellbeing Benefit (${money(18141.41)} against ${money(SCREEN.wellbeing)}), the shape of vendor credits the integration role cannot read. The other ${26 - 3} lines on the report tie to the penny.` },
  { label: "Net Ordinary Income", cells: T.ordinary.cells, total: T.ordinary.total, style: "net",
    note: "Total Income less Total Expense, month by month: the operating line, before other income and other expense." },
  ...NS.otherIncome,
  ...NS.otherExpense,
  { label: "Net Income", cells: T.net.cells, total: T.net.total, style: "final",
    note: "Net Ordinary Income plus other income, less other expense (interest paid and accrued, factoring fees, other expense)." },
];

const positives = NS.months.filter((_, m) => T.ordinary.cells[m] > 0);
const netPositives = NS.months.filter((_, m) => T.net.cells[m] > 0);
const pfRevenueOver = PF.base.total! - T.income.total;
const pfExpenseUnder = T.expense.total - PF.expenses.total!;


// ---------------------------------------------------------------------------
// Page 2 (David 10/25 night, revised the same night): January through September
// locked from the books, October through December estimated from the pro
// forma's own elements. The estimate is carried at the client-line level (the
// practice-area rows are their lines' sums, so the sheet's PAD formula gap does
// not hide two lines). The purple lines are assumptions: off by default, a
// switch at the top of the page brings them in, and every figure, table and
// chart on the page moves with it.
// ---------------------------------------------------------------------------

/* ---- pages 3 and 4: the cash worksheet from the current October 31 column through June 30, 2027, first with anything
   purple taken out of Cash In, then as the sheet carries it with a switch for the purple items (David 10/26) ---- */
// Every source line reads as a citation: the data source and when it was pulled (David 11/1).
const liveLine = (source: LiveSource, sheet: string) =>
  source.live
    ? `Source: SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet ${sheet}, pulled ${source.readAt}.`
    : `Source: SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet ${sheet}, last pulled ${source.savedAt}.`;

const cents = (x: number) => Math.round(x * 100) / 100;
const addUp = (a: number[]) => cents(a.reduce((s, v) => s + v, 0));

type CashKid = LiveRow & { note?: string };
type CashView = Omit<CashLive, "cashIn"> & { cashIn: LiveRow & { children: CashKid[] } };

/** The cash window with the purple items in (on) or out (off). Off: every purple cell leaves Cash In, a line purple in
 *  full leaves the table, and Cash In, the Anticipated 15-Day Balance and every later Beginning Balance are recomputed
 *  from what remains; Cash Out is the sheet's own either way. Purple is whatever the parser read on the last refresh. */
const cashView = (CASH: CashLive, on: boolean): CashView => {
  const when = (k: LiveRow) =>
    CASH.periods.map((p, i) => (k.purple?.[i] && Math.abs(k.cells[i]) > 0.004 ? `${p.label}, ${p.year} (${whole(k.cells[i])})` : null)).filter((x): x is string => !!x).join("; ");
  if (on) {
    const kids: CashKid[] = (CASH.cashIn.children ?? []).map((k) =>
      !k.purple
        ? k
        : { ...k, note: k.flag === "Assumption" ? `The sheet shows this line in purple, an item not yet confirmed: ${when(k)}. The switch above takes it out.` : `Purple in the sheet for ${when(k)}; the line's other periods are not purple. The switch above takes the purple periods out.` },
    );
    return { ...CASH, cashIn: { ...CASH.cashIn, children: kids } };
  }
  const kids: CashKid[] = [];
  for (const k of CASH.cashIn.children ?? []) {
    if (!k.purple) { kids.push(k); continue; }
    const cells = k.cells.map((v, i) => (k.purple![i] ? 0 : v));
    if (cells.every((v) => Math.abs(v) < 0.005)) continue;
    kids.push({ label: k.label, sub: k.sub, cells, total: addUp(cells), flag: "Purple periods out", note: `Purple in the sheet for ${when(k)}; those cells are out of this line and of Cash In. The line's other periods stand.` });
  }
  const inCells = CASH.periods.map((_, i) => addUp(kids.map((k) => k.cells[i])));
  const beginning: number[] = [], balance: number[] = [];
  CASH.periods.forEach((_, i) => {
    beginning[i] = i === 0 ? CASH.beginning[0] : balance[i - 1];
    balance[i] = cents(beginning[i] + inCells[i] - CASH.cashOut.cells[i]);
  });
  let lo = 0; balance.forEach((v, i) => { if (v < balance[lo]) lo = i; });
  return { ...CASH, beginning, balance, cashIn: { ...CASH.cashIn, cells: inCells, total: addUp(inCells), children: kids }, lowest: { iso: CASH.periods[lo].iso, label: `${CASH.periods[lo].label}, ${CASH.periods[lo].year}`, value: balance[lo] } };
};

const cashRows = (CASH: CashLive, V: CashView, on: boolean): DocRow[] => {
  const n = CASH.purple.length;
  return [
    { label: "Beginning Balance", cells: V.beginning, note: on ? "The sheet's row 3: the balance carried into each period, the prior period's Anticipated 15-Day Balance." : `The first period's balance is the sheet's own, ${whole(CASH.beginning[0])}; every later one is the prior period's recomputed Anticipated 15-Day Balance.` },
    { ...V.cashIn, style: "total", note: on ? "The sheet's Cash In row, the client lines beneath it added up. Each line carries its Project Code as the sheet does; a line in purple carries an Assumption chip and opens to the periods in purple." : `Cash In recomputed from the lines that remain once every purple cell is out: ${whole(CASH.purpleTotal)} across ${n} purple items leaves the sheet's ${whole(CASH.cashIn.total)}, so ${whole(V.cashIn.total)} stands for the window.` },
    { ...CASH.cashOut, style: "total", note: "The sheet's Cash Out row: Compensation, Vendors, Debt, Office and Recurring Expenses, each opening to its lines. The purple rule does not touch it." },
    { label: "Anticipated 15-Day Balance", cells: V.balance, style: "final", note: on ? "Beginning Balance plus Cash In less Cash Out, as the sheet computes it for each period." : "Beginning Balance plus the recomputed Cash In less Cash Out, period by period, each ending balance carried into the next period." },
  ];
};

/** The cash window as one table, purple in or out; pages 3, 4 and 5 share it. */
const cashTableBlock = (CASH: CashLive, source: LiveSource, on: boolean, id: string): DocBlock => {
  const V = cashView(CASH, on);
  const p0 = CASH.periods[0], pN = CASH.periods[CASH.periods.length - 1];
  const span = `${p0.label}, ${p0.year} to ${pN.label}, ${pN.year}`;
  return {
    kind: "table",
    id,
    caption: `Cash Tracker 2026 · ${span} · Dollars · ${on ? "Purple In" : "Purple Out"} · ${source.live ? "Live" : "Snapshot"}`,
    columns: CASH.periods.map((p) => p.label),
    columnSubs: CASH.periods.map((p) => String(p.year)),
    rows: cashRows(CASH, V, on),
    source: `Source: SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet Cash Tracker 2026, pulled ${source.readAt}.`,
  };
};

const cashBlocks = (CASH: CashLive, source: LiveSource, on: boolean): DocBlock[] => {
  const V = cashView(CASH, on);
  const p0 = CASH.periods[0], pN = CASH.periods[CASH.periods.length - 1];
  const yearSubs = CASH.periods.map((p) => String(p.year));
  const span = `${p0.label}, ${p0.year} to ${pN.label}, ${pN.year}`;
  const n = CASH.purple.length, wholeN = CASH.purple.filter((p) => p.whole).length, partN = n - wholeN;
  const endBal = V.balance[V.balance.length - 1];
  const removed: DocBlock[] = on ? [] : [
    { kind: "h2", text: "What Left The Table" },
    { kind: "para", text: `${n} Cash In lines carry purple in the window, ${wholeN} in full and ${partN} in some periods, ${whole(CASH.purpleTotal)} in all. Each is listed with what left it.` },
    { kind: "list", items: CASH.purple.map((p) => `${p.label}${p.sub && p.sub !== "no Project Code" ? ` (${p.sub})` : ""}: ${whole(p.total)}${p.whole ? ", the whole line" : `, ${p.cells.filter((v) => Math.abs(v) > 0.004).length} of its periods`}`) },
  ];
  return [
    {
      kind: "lead",
      bold: on ? "The cash worksheet as the Finance Binder carries it, the purple items in." : "The cash worksheet with anything in purple taken out of Cash In.",
      text: on
        ? `A carbon copy of the Cash Tracker 2026 sheet from the current October 31 column through June 30, 2027: ${CASH.periods.length} semi-monthly periods, the Beginning Balance, Cash In by client with its Project Code, Cash Out by the sheet's five sections and their lines, and the Anticipated 15-Day Balance. ${n} Cash In lines carry purple in the window, ${whole(CASH.purpleTotal)} of the sheet's ${whole(CASH.cashIn.total)}; each carries an Assumption chip and opens to the periods in purple. The switch above takes them out and recomputes the balances, the picture on page 3. The sheet's own year labels drift; the dates here are repaired by position.`
        : `The Cash Tracker 2026 sheet from the current October 31 column through June 30, 2027, ${CASH.periods.length} semi-monthly periods, read as the sheet reads except for one rule: a purple cell in a Cash In line is an item not yet confirmed, and it is out. A line purple in full leaves the table; a line purple in some periods keeps its other periods. Cash In, the Anticipated 15-Day Balance and every later Beginning Balance are recomputed from what remains; Cash Out is the sheet's own. Purple is read from the sheet on every refresh, any shade of it, so a line that turns purple in SharePoint leaves this page within a minute and one that turns black comes back.`,
    },
    { kind: "source", text: liveLine(source, "Cash Tracker 2026") },
    {
      kind: "stats",
      items: [
        { k: `Beginning Balance · ${p0.label}`, v: whole(CASH.beginning[0]), sub: "carried into the first period of the window, the sheet's own" },
        { k: `Cash In · ${span}`, v: whole(V.cashIn.total), sub: on ? `${V.cashIn.children.length} client lines, ${n} with purple` : `${V.cashIn.children.length} lines remain; ${whole(CASH.purpleTotal)} of purple out` },
        { k: `Cash Out · ${span}`, v: whole(CASH.cashOut.total), sub: `${CASH.cashOut.children?.length ?? 0} sections, the sheet's own` },
        { k: `Anticipated Balance · ${pN.label}, ${pN.year}`, v: whole(endBal), tone: endBal < 0 ? "neg" : "pos", sub: `lowest in the window ${whole(V.lowest.value)} on ${V.lowest.label}` },
      ],
    },
    { kind: "h2", text: "The Worksheet" },
    {
      kind: "para",
      text: on
        ? `Semi-monthly columns, the 15th and the end of each month. Cash In opens to every client line with a figure in the window; Cash Out opens to the sections and each section to its lines. The balance row is the sheet's own formula, period by period.`
        : `Semi-monthly columns, the 15th and the end of each month. Cash In opens to the lines that remain; a line that lost some periods to the rule carries a chip and opens to say which. Cash Out opens to the sections and each section to its lines. The balance row is recomputed, period by period.`,
    },
    cashTableBlock(CASH, source, on, on ? "cash-tracker" : "cash-tracker-purple-out"),
    {
      kind: "chart",
      id: on ? "cash-monthly" : "cash-monthly-purple-out",
      title: on ? "Cash In Against Cash Out, by Period" : "Cash In Without the Purple Against Cash Out, by Period",
      categories: CASH.periods.map((p) => p.label),
      bars: [
        { name: "Cash In", values: V.cashIn.cells, tone: "accent" },
        { name: "Cash Out", values: CASH.cashOut.cells, tone: "mid" },
      ],
      line: { name: "Balance", values: V.balance },
      caption: liveLine(source, "Cash Tracker 2026"),
    },
    ...removed,
  ];
};

const cashPages = (CASH: CashLive, source: LiveSource): [DocPage, DocPage] => {
  const OFF = cashBlocks(CASH, source, false), ON = cashBlocks(CASH, source, true);
  const n = CASH.purple.length, t = whole(CASH.purpleTotal);
  return [
    { slug: "cash-oct-jun", ref: "3", title: "The Cash Picture, *Anything Purple Removed.*", kicker: "3 · The Cash Worksheet, Purple Out", blocks: OFF },
    {
      slug: "cash-oct-jun-purple-in",
      ref: "4",
      title: "The Cash Picture, *The Purple Items Back In.*",
      kicker: "4 · The Cash Worksheet, Purple In",
      blocks: OFF,
      toggle: {
        label: "Purple items",
        defaultOn: true,
        onNote: `On: the ${n} purple items, ${t} of Cash In in the window, are in every figure on this page, as the sheet carries them.`,
        offNote: `Off: the ${n} purple items, ${t}, are out of Cash In and the balances are recomputed from what remains, the picture on page 3.`,
        blocksOn: ON,
      },
    },
  ];
};

/* ---- page 5, basics only (David 10/26): the 2027 pro forma as currently modeled, purple in and purple out, locked at the
   snapshot version; then the cash window purple in and purple out, live. Placeholder prose while the narrative is staged. ---- */
const LOREM = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";
const LOREM2 = "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.";
const LOREM3 = "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.";

/** A month block of the pro forma as one table: the sheet's Base Revenue row and practice areas opening to client lines (purple in), or the practice areas rebuilt from their non-purple lines (purple out). */
const blockTable = (B: Q4Live, on: boolean, id: string, caption: string, source: string): DocBlock => {
  const M = B.months.map((_, m) => m);
  const sections = B.sections
    .map((s) => {
      const kids = (s.children ?? []).filter((k) => on || k.flag !== "Assumption");
      const cells = M.map((m) => addUp(kids.map((k) => k.cells[m])));
      // the sheet's practice-area row when it carries figures (2026), else the lines added (the 2027 block leaves those rows empty)
      const sheetHas = s.cells.some((v) => Math.abs(v) > 0.004);
      const all = M.map((m) => addUp((s.children ?? []).map((k) => k.cells[m])));
      return { label: s.label, sheetCells: sheetHas ? s.cells : all, sheetTotal: sheetHas ? s.total : addUp(all), cells, total: addUp(cells), kids };
    })
    .filter((s) => (on ? s.kids.length || s.sheetCells.some((v) => Math.abs(v) > 0.004) : s.kids.length));
  const lines = M.map((m) => addUp(sections.map((s) => s.cells[m])));
  const purple = M.map((m) => addUp(B.purple.map((p) => p.cells[m])));
  const rows: DocRow[] = on
    ? [
        { label: "Base Revenue, the sheet's row", cells: B.top.base.cells, total: B.top.base.total, style: "total" },
        ...sections.map((s) => ({ label: s.label, cells: s.sheetCells, total: s.sheetTotal, style: "indent" as const, children: s.kids.map((k) => ({ label: k.label, sub: k.sub, flag: k.flag, cells: k.cells, total: k.total })) })),
        { label: "Client lines, added", cells: lines, total: addUp(lines), style: "net" },
        { label: "of which purple", cells: purple, total: B.purpleTotal },
      ]
    : [
        ...sections.map((s) => ({ label: s.label, cells: s.cells, total: s.total, style: "indent" as const, children: s.kids.map((k) => ({ label: k.label, sub: k.sub, cells: k.cells, total: k.total })) })),
        { label: "Client lines without the purple", cells: lines, total: addUp(lines), style: "total" },
      ];
  return { kind: "table", id, caption, columns: B.months, totalLabel: "2027", rows, source };
};

const picturePage = (B: Q4Live, CASH: CashLive, source: LiveSource): DocPage => {
  const locked = `Source: SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, the 2027 block, January through December. Locked at version ${SNAPSHOT.source.version}, saved ${SNAPSHOT.source.savedAt}; this picture does not refresh. The sheet carries no 2027 expenses: its Expenses and Net Income rows are empty in the 2027 block. Labels are the sheet's own.`;
  return {
    slug: "picture-2027",
    ref: "5",
    title: "2027, *As Currently Modeled.*",
    kicker: "5 · The 2027 Picture",
    blocks: [
      { kind: "lead", bold: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", text: `${LOREM} ${LOREM2}` },
      { kind: "h2", text: "Pro Forma 2027, Purple In" },
      { kind: "para", text: LOREM3 },
      blockTable(B, true, "pf-2027-purple-in", `Pro Forma 2027 · January to December · Dollars · Purple In · Locked at Version ${SNAPSHOT.source.version}`, locked),
      { kind: "h2", text: "Pro Forma 2027, Purple Out" },
      { kind: "para", text: LOREM2 },
      blockTable(B, false, "pf-2027-purple-out", `Pro Forma 2027 · January to December · Dollars · Purple Out · Locked at Version ${SNAPSHOT.source.version}`, `${locked} Purple lines are out; each practice area and the total are the remaining lines added.`),
      { kind: "h2", text: "Cash Through June 30, 2027, Purple In" },
      { kind: "para", text: LOREM3 },
      { kind: "source", text: liveLine(source, "Cash Tracker 2026") },
      cashTableBlock(CASH, source, true, "cash-2027-purple-in"),
      { kind: "h2", text: "Cash Through June 30, 2027, Purple Out" },
      { kind: "para", text: LOREM },
      cashTableBlock(CASH, source, false, "cash-2027-purple-out"),
    ],
  };
};


/* ---- page 6 (David 10/31): the Micro, his focus map for November 2026 through October 2027, carried onto the
   surface as a plan on a spine in the shape of the Mission Card's domain flow (Strategy, Operations, Budget).
   His lines verbatim; placeholder prose while the narrative is staged; the open slots fill as we work it. ---- */
const PAGE7: DocPage = {
  slug: "capital-raise",
  ref: "7",
  title: "The Capital Raise, *Targets And The Road.*",
  kicker: "7 · Capital",
  blocks: [
    { kind: "lead", bold: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", text: `${LOREM} ${LOREM2}` },
    CAPITAL,
  ],
};

const PAGE6: DocPage = {
  slug: "micro-focus",
  ref: "6",
  title: "The Micro, *November 2026 Through October 2027.*",
  kicker: "6 · The Micro Plan",
  blocks: [
    { kind: "lead", bold: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", text: `${LOREM} ${LOREM2}` },
    { kind: "para", text: LOREM3 },
    MICRO,
  ],
};

/* ---- the purple lines as cards (David 11/3): who brings each in, who leads the work, a pithy status on the face ----
   The seed below is David's own assignment of 11/3; the live copy (assignments, statuses, the updates typed into the
   modal) lives in the Ledger artifact `purple-pipeline` under the Finance.Review project, where Lumen reads the updates
   and writes the one-line status. The reader merges the live copy over this seed. */
const PURPLE_PEOPLE: PlanPerson[] = [
  ...CSOG,
  { key: "mindy", name: "Mindy Klowden", src: "/people/mindy.webp" },
  { key: "tym", name: "Tym Rourke", src: "/people/tym.webp" },
  { key: "erica", name: "Erica Bauer", src: "/people/erica.webp" },
  { key: "topher", name: "Topher Rasmussen", role: "Director of AI Enablement", src: "/people/topher.webp" },
  { key: "rich", name: "Rich" },
];
const slugOf = (label: string) => label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60);
const PURPLE_SEED: { match: string; seed: Partial<DocCard> }[] = [
  { match: "american medical", seed: { key: "ama", owner: "david", leads: ["bo"], status: "Back channel says this is a lock; hoping to go into contracting this week.", link: { label: "The proposal, $125,000", href: "https://proposals.thirdhorizon.com/ama" } } },
  { match: "denver public", seed: { key: "denver-public-health", owner: "mindy", leads: ["mindy"], status: "Update on the next call." } },
  { match: "oregon", seed: { key: "oregon-adpc", owner: "tym", leads: ["tym"] } },
  { match: "moreton", seed: { key: "moreton-ushe", owner: "bo", leads: ["bo"] } },
  { match: "marsh", seed: { key: "marsh-mclennan-2027", owner: "cheryl", leads: ["david"] } },
  { match: "mj insurance", seed: { key: "mj-insurance", owner: "cheryl", leads: ["cheryl"], status: "$10K for Cheryl to bring in and bill in November and December." } },
  { match: "silver hill", seed: { key: "silver-hill", owner: "greg", leads: ["greg"], status: "Greg needs to collect on the service fee revenue here." } },
  { match: "kennedy", seed: { key: "kennedy-forum-illinois", owner: "greg", leads: ["greg"] } },
  { match: "chronic disease", seed: { key: "nacdd-diabetes-y3", owner: "bo", leads: ["erica"] } },
  { match: "alliance of community", seed: { key: "achp-ai-2", owner: "david", leads: ["topher", "rich"] } },
];
const purpleSeed = (label: string): Partial<DocCard> => PURPLE_SEED.find((x) => label.toLowerCase().includes(x.match))?.seed ?? {};


export function buildFinanceReviewPages(live: FinanceLive): DocPage[] {
  const Q4: Q4Live = live.q4;
  const source: LiveSource = live.source;

const q4 = (c: number[]) => c.reduce((a, b) => a + b, 0);
  const YEAR_MONTHS = [...NS.months, ...Q4.months];
  const belowLine = T.otherIncome.total - T.otherExpense.total;
  const allLinesCells = [0, 1, 2].map((m) => Q4.sections.reduce((a, s) => a + s.linesSum[m], 0));
  const allLinesTotal = q4(allLinesCells);
  const purpleCells = [0, 1, 2].map((m) => Q4.purple.reduce((a, p) => a + p.cells[m], 0));
  const sectionGaps = Q4.sections.map((s) => ({ label: s.label, gap: q4(s.linesSum) - s.total })).filter((g) => Math.abs(g.gap) > 0.5);
  const padGap = allLinesTotal - Q4.top.base.total;
  const expenseGap = Q4.expenseSum.total - Q4.top.expenses.total;
  
  type View = {
    sections: { label: string; cells: number[]; total: number; sheetCells: number[]; sheetTotal: number; children: (typeof Q4.sections)[number]["children"] }[];
    revCells: number[]; revTotal: number; netCells: number[]; netTotal: number;
    fyRevenue: number; fyExpense: number; fyOrdinary: number; fyNet: number;
  };
  const view = (on: boolean): View => {
    const sections = Q4.sections
      .map((s) => {
        // off: a purple name drops the whole line; purple amount cells drop out of a line whose name is black, the locked cells stay
        const kids = (s.children ?? [])
          .map((k) => (on || k.flag !== "Assumption" ? k : { ...k, flag: undefined, cells: k.cells.map((v, i) => ((k.purple?.[i] ?? true) ? 0 : v)) }))
          .map((k) => ({ ...k, total: q4(k.cells) }))
          .filter((k) => on || Math.abs(k.total) > 0.5);
        const cells = [0, 1, 2].map((m) => kids.reduce((a, k) => a + k.cells[m], 0));
        return { label: s.label, cells, total: q4(cells), sheetCells: s.cells, sheetTotal: s.total, children: kids };
      })
      .filter((s) => s.children && s.children.length);
    const revCells = [0, 1, 2].map((m) => sections.reduce((a, s) => a + s.cells[m], 0));
    const revTotal = q4(revCells);
    const netCells = [0, 1, 2].map((m) => revCells[m] - Q4.expenseSum.cells[m]);
    const netTotal = q4(netCells);
    return { sections, revCells, revTotal, netCells, netTotal, fyRevenue: T.income.total + revTotal, fyExpense: T.expense.total + Q4.expenseSum.total, fyOrdinary: T.ordinary.total + netTotal, fyNet: T.net.total + netTotal };
  };
  
  const assumptionItems = Q4.purple.map((p) => `${p.label}${p.sub ? ` (${p.sub})` : ""}, ${p.section}: ${whole(p.total)} across ${Q4.months.filter((_, m) => Math.abs(p.cells[m]) > 0.5).join(", ")}.`);
  
  const topLineRows: DocRow[] = [
    { label: "Base Revenue, the sheet's row", cells: Q4.top.base.cells, total: Q4.top.base.total, style: "total", note: "Typed into the sheet as the sum of its six practice-area rows; Forecasted Revenue equals it in these months, since no pipeline is added." },
    { label: "Practice-area rows, as the sheet carries them", cells: Q4.sectionsSum.cells, total: Q4.sectionsSum.total },
    { label: "Client lines under them, added", cells: allLinesCells, total: allLinesTotal, style: "net",
      note: sectionGaps.length ? `${whole(padGap)} more than the sheet's row. The gap sits in ${sectionGaps.map((g) => `${g.label} (${whole(g.gap)})`).join(" and ")}: that section row's formula does not reach every line beneath it, so the lines, not the row, are what this page carries.` : "Equal to the sheet's row." },
    { label: "of which purple assumptions", cells: purpleCells, total: Q4.purpleTotal, note: `The four revenue lines set in purple on the sheet: ${Q4.purple.map((p) => p.label).join("; ")}. Off by default on this page; the switch at the top brings them in.` },
    { label: "Client lines without the assumptions", cells: allLinesCells.map((v, m) => v - purpleCells[m]), total: allLinesTotal - Q4.purpleTotal, style: "net", note: "What the page carries as revenue for the quarter with the switch off." },
    { label: "Expenses, the sheet's row", cells: Q4.top.expenses.cells, total: Q4.top.expenses.total, style: "total" },
    { label: "Category lumps and lines, added", cells: Q4.expenseSum.cells, total: Q4.expenseSum.total, style: "net", note: expenseGap === 0 ? "Equal to the sheet's row: what the page carries as expense for the quarter." : `Off the sheet's row by ${money(expenseGap)}.` },
  ];
  
  const page2Blocks = (on: boolean): DocBlock[] => {
    const v = view(on);
    // the sheet's purple lines, client by client, first under Revenue in the after picture (David 11/1), in purple so the prose can point to them
    const assumptionRows: DocRow[] = (on ? Q4.purple : []).map((pl) => ({
      label: pl.label, sub: pl.sub, cells: [null, ...pl.cells, pl.total], total: pl.total, style: "assume" as const, flag: "Assumption",
      note: `Set in purple on the sheet under ${pl.section}: ${whole(pl.total)} across ${Q4.months.filter((_, m) => Math.abs(pl.cells[m]) > 0.5).join(", ")}. Counted in this picture, not in the locked one.`,
    }));
    const yearRows: DocRow[] = [
      { label: "Revenue", cells: [T.income.total, ...v.revCells, v.revTotal], total: v.fyRevenue, style: "total",
        note: `January through September is the books' Total Income (page 1). October through December is the pro forma's client lines added up by practice area${on ? ", the purple assumptions included" : ", the purple assumptions switched off"}. The two sources sit on different structures (accounts in the books, practice areas in the sheet), so the practice areas below carry the estimate months only.`,
        children: [...assumptionRows, ...v.sections.map((sec) => ({ label: sec.label, cells: [null, ...sec.cells, sec.total], total: sec.total,
          children: (sec.children ?? []).map((k) => ({ label: k.label, sub: k.sub, flag: k.flag, cells: [null, ...k.cells, k.total], total: k.total })) }))] },
      { label: "Expenses", cells: [T.expense.total, ...Q4.expenseSum.cells, Q4.expenseSum.total], total: v.fyExpense, style: "total",
        note: "January through September is the books' Total Expense. October through December is the pro forma's expense elements, the category lumps and their lines added together, which is what its Expenses row carries for those months. The sheet keeps Interest Paid inside Expenses, where the books carry interest below the operating line.",
        children: Q4.expenseCats.map((c) => ({ label: c.label, cells: [null, ...c.cells, c.total], total: c.total })) },
      { label: "Net Ordinary Income", cells: [T.ordinary.total, ...v.netCells, v.netTotal], total: v.fyOrdinary, style: "net",
        note: "Revenue less Expenses on each side: the books' operating line for the closed months, revenue carried less the sheet's expense elements for the estimate months." },
      { label: "Other Income and Expense, Books", cells: [belowLine, null, null, null, null], total: belowLine,
        note: `The books' line below operating income for January through September: ${money(T.otherIncome.total)} of other income less ${money(T.otherExpense.total)} of other expense. The pro forma carries nothing below its Net Income row, so the estimate months show no figure here.` },
      { label: "Net Income", cells: [T.net.total, ...v.netCells, v.netTotal], total: v.fyNet, style: "final",
        note: "The books' Net Income for the closed months plus the estimate months' revenue carried less expenses." },
    ];
    const revenueRows: DocRow[] = [
      // the sheet's purple lines, client by client, above the practice areas (David 11/1), in the accent so the prose can point to them
      ...v.sections.map((s) => ({ label: s.label, cells: s.cells, total: s.total, children: s.children, style: "indent" as const,
        note: Math.abs(s.total - (on ? q4(Q4.sections.find((x) => x.label === s.label)!.linesSum) : s.total)) > 0.5 || Math.abs(q4(Q4.sections.find((x) => x.label === s.label)!.linesSum) - s.sheetTotal) > 0.5
          ? `The sheet's row for this practice area reads ${whole(s.sheetTotal)} for the quarter; its lines add to ${whole(q4(Q4.sections.find((x) => x.label === s.label)!.linesSum))}${on ? "" : `, ${whole(q4(Q4.sections.find((x) => x.label === s.label)!.linesSum) - s.total)} of which are purple assumptions switched off here`}. ${Math.abs(q4(Q4.sections.find((x) => x.label === s.label)!.linesSum) - s.sheetTotal) > 0.5 ? "The row's formula does not reach every line beneath it; this page carries the lines." : ""}`.trim()
          : undefined })),
      { label: "Revenue carried, October to December", cells: v.revCells, total: v.revTotal, style: "total",
        note: `The client lines added up${on ? ", the purple assumptions included" : ", without the purple assumptions"}. The sheet's own Base Revenue row for these months reads ${whole(Q4.top.base.total)}.` },
    ];
    const expenseRows: DocRow[] = [
      ...Q4.expenseCats.map((c) => ({ ...c, style: "indent" as const })),
      { label: "Expenses", cells: Q4.top.expenses.cells, total: Q4.top.expenses.total, style: "total", note: "The sheet's own row for these months, the category lumps and their lines added together." },
    ];
    const onOff = on ? "with the purple assumptions switched on" : "with the purple assumptions switched off";
    return [
      {
        kind: "lead",
        bold: "The first set of numbers below shows what we have locked.",
        text: "Not what we \"believe\" is about to contract, but firmly locked. The picture says we generally hold the line steady. The silver lining, by all accounts and in my judgment, is that our revenue production has almost caught up with our current expense load. Regrettably, we have come close to running out of gas and have officially hit fumes.",
      },
      { kind: "source", text: liveLine(source, "PRO FORMA 2026") },
      {
        kind: "stats",
        items: [
          { k: "Revenue · FY 2026", v: whole(v.fyRevenue), sub: on ? `${whole(Q4.purpleTotal)} of purple assumptions included` : "nothing assumed" },
          { k: "Expenses · FY 2026", v: whole(v.fyExpense), sub: "the books through September, the sheet after" },
          { k: "Net Ordinary Income · FY 2026", v: whole(v.fyOrdinary), tone: v.fyOrdinary < 0 ? "neg" : "pos", sub: "revenue less expenses" },
          { k: "Net Income · FY 2026", v: whole(v.fyNet), tone: v.fyNet < 0 ? "neg" : "pos", sub: `after ${whole(belowLine)} below the line in the closed months` },
        ],
      },
      { kind: "h2", text: "What David Currently Estimates" },
      {
        kind: "para",
        text: "The P&L below includes the hard NetSuite numbers from the previous page and the projections for October through December from above, and folds in the contracts we have high confidence in, shown in the table below.",
      },
      {
        kind: "table",
        id: "year-2026",
        caption: `2026 · January to September Closed, October to December Estimated · ${on ? "Assumptions On" : "Assumptions Off"} · Dollars`,
        columns: ["Jan to Sep", ...Q4.months, "Oct to Dec"],
        columnSubs: ["Closed · Books", "Estimate", "Estimate", "Estimate", "Estimate · Sheet"],
        totalLabel: "FY 2026",
        legend: on ? [{ color: "#B48CF2", text: "Purple on the pro forma, an assumption not yet locked" }] : undefined,
        rows: yearRows,
        source: `Source: NetSuite, pulled ${NS.readOn}; SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, pulled ${source.readAt}.`,
      },
      {
        kind: "chart",
        id: "year-monthly",
        title: `Revenue Against Expenses, Closed and Estimated, by Month · ${on ? "Assumptions On" : "Assumptions Off"}`,
        categories: YEAR_MONTHS,
        bars: [
          { name: "Revenue", values: [...T.income.cells, ...v.revCells], tone: "accent" },
          { name: "Expenses", values: [...T.expense.cells, ...Q4.expenseSum.cells], tone: "mid" },
        ],
        line: { name: "Net Ordinary", values: [...T.ordinary.cells, ...v.netCells] },
        estimateFrom: NS.months.length,
        estimateLabel: "Estimate, the sheet",
        caption: `Source: NetSuite, pulled ${NS.readOn}; SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, pulled ${source.readAt}.`,
      },
      { kind: "h2", text: "The Top Lines Against The Lines" },
      {
        kind: "para",
        text: `For October through December the sheet's Base Revenue row equals its six practice-area rows to the dollar, Forecasted Revenue equals Base Revenue (no pipeline is added in these months), and its Expenses row equals the category lumps and their lines to the dollar${expenseGap === 0 ? "" : ` (off by ${money(expenseGap)})`}. The one place the sheet's top line is not what its lines say is revenue one level down: the client lines beneath the practice-area rows add to ${whole(allLinesTotal)}, ${whole(padGap)} more than the Base Revenue row, because ${sectionGaps.map((g) => `the ${g.label} row carries ${whole(g.gap)} less than its lines`).join(" and ")}. This page carries the lines. With the purple assumptions off, that is ${whole(allLinesTotal - Q4.purpleTotal)} for the quarter; with them on, ${whole(allLinesTotal)}.`,
      },
      {
        kind: "table",
        id: "top-lines",
        caption: "October to December · The Sheet's Typed Rows Against Its Elements · Dollars",
        columns: Q4.months,
        columnSubs: ["Estimate", "Estimate", "Estimate"],
        totalLabel: "Oct to Dec",
        rows: topLineRows,
      },
      { kind: "h2", text: "Revenue, October Through December" },
      {
        kind: "para",
        text: on
          ? `The six practice areas and every client line with a figure in the quarter (${Q4.lineCount} lines), the four purple lines included and carrying the Assumption flag, ${whole(Q4.purpleTotal)} of the quarter's ${whole(v.revTotal)}. One line is highlighted yellow on the sheet and is flagged as such.`
          : `The six practice areas and every client line with a figure in the quarter, without the four purple lines (${whole(Q4.purpleTotal)}, listed beneath as the work to do). One line is highlighted yellow on the sheet and is flagged as such; it stays in.`,
      },
      {
        kind: "table",
        id: "q4-revenue",
        caption: `Revenue Estimate · October to December · By Practice Area and Client Line · ${on ? "Assumptions On" : "Assumptions Off"} · Dollars`,
        columns: Q4.months,
        columnSubs: ["Estimate", "Estimate", "Estimate"],
        totalLabel: "Oct to Dec",
        rows: revenueRows,
      },
      {
        kind: "callout",
        eyebrow: on ? "Assumptions, Switched On" : "Assumptions, Switched Off",
        text: on
          ? `The purple lines on the sheet, ${whole(Q4.purpleTotal)} across the quarter, are in the figures above. Each needs its basis set down before it stands as more than an assumption.`
          : `The purple lines on the sheet, ${whole(Q4.purpleTotal)} across the quarter, are out of every figure above. Switch them on at the top of the page to see the year as the sheet models it. Each needs its basis set down before it stands as more than an assumption.`,
      },
      { kind: "list", items: assumptionItems },
      {
        kind: "para",
        text: `Highlighted yellow on the sheet, not purple: ${Q4.yellow.map((y) => `${y.label} (${y.sub ?? "no Project Code"}), ${y.section}, ${whole(y.total)} across the quarter`).join("; ")}. The sheet does not say what the yellow means, so it is shown with its own flag and stays in the figures either way.`,
      },
      { kind: "h2", text: "Expenses, October Through December" },
      {
        kind: "para",
        text: `The sheet's expense categories, each opening to its lump and its lines where it has both (Contractors, Payroll Expenses, Business Development, Rent & Lease and Project Starset carry lines; the rest are a single figure a month). Payroll Expenses is ${whole(Q4.expenseCats.find((c) => c.label === "Payroll Expenses")?.total ?? 0)} of the quarter's ${whole(Q4.expenseSum.total)}; Project Starset ${whole(Q4.expenseCats.find((c) => c.label === "Project Starset")?.total ?? 0)}. The switch does not touch expenses.`,
      },
      {
        kind: "table",
        id: "q4-expense",
        caption: "Expense Estimate · October to December · By Category · Dollars",
        columns: Q4.months,
        columnSubs: ["Estimate", "Estimate", "Estimate"],
        totalLabel: "Oct to Dec",
        rows: expenseRows,
      },
      {
        kind: "source",
        text: `Source: SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, pulled ${source.readAt}.`,
      },
    ];
  };
  
  const PAGE2_OFF = page2Blocks(false);
  const PAGE2_ON = page2Blocks(true);
  // Before, then after (David 11/1): the locked picture first, assumptions out; then the same picture
  // with the sheet's purple contracts folded in and highlighted, so the prose can point to what changed.
  const pick = (arr: DocBlock[], kind: DocBlock["kind"], nth = 0) => arr.filter((b) => b.kind === kind)[nth];
  const PAGE2_BLOCKS: DocBlock[] = [
    PAGE2_ON[0],
    { kind: "h2", text: "What We Have Locked" },
    { kind: "para", text: "The closed months from the books and the sheet's October through December with nothing assumed. No purple." },
    pick(PAGE2_OFF, "stats"),
    pick(PAGE2_OFF, "table"),
    { kind: "h2", text: "What David Currently Estimates" },
    pick(PAGE2_ON, "para"),
    pick(PAGE2_ON, "stats"),
    pick(PAGE2_ON, "table"),
    { kind: "h2", text: "Landing The Purple Items" },
    { kind: "para", text: LOREM },
    {
      kind: "cards",
      id: "purple-items",
      people: PURPLE_PEOPLE,
      accent: "#B48CF2",
      store: "purple-pipeline",
      items: Q4.purple.map((pl) => ({ key: slugOf(pl.label), title: pl.label, code: pl.sub ?? "No Project Code", practice: pl.section, goal: pl.total, ...purpleSeed(pl.label) })),
    },
  ];
  const [PAGE3, PAGE4] = cashPages(live.cash, source);
  const PAGE5 = picturePage(SNAPSHOT.fy27, live.cash, source);
  return [

  {
    slug: "cover",
    ref: "",
    title: "Company Finance Review",
    kicker: "Third Horizon · Working Review · October 2026",
    cover: {
      heading: "Company Finance Review",
      sub: "A tool that assesses short term cash needs and the short/medium term decisions required for business structure. This includes a tactical sequencing of what needs to happen to execute both strategies.",
      note: "Prepared for David Smith",
      date: `NetSuite read ${NS.readOn}`,
    },
    blocks: [{ kind: "contents" }],
  },
  {
    slug: "income-statement-jan-sep",
    ref: "1",
    title: "Performance Through September 2026",
    kicker: "1 · The Income Statement",
    blocks: [
      {
        kind: "lead",
        bold: "We carried a loss tail from 2025 that put us in the hole, on an accrual basis, from January of this year.",
        text: "From there the story of 2026 has mostly been break-even, staring down a big trough in Q3 and Q4.",
      },
      {
        kind: "para",
        text: "This is the most accurate year we have for accounting on record, both for process and for how revenues and expenses are assigned. That is the result of substantial work led by Jordana, with Greg, Aisha and me assisting. The truth is that on Net Ordinary Income the business is performing better than it did in 2025, and candidly, even base Net Income is running ahead of the 2025 trend. The key for us is how October through December close out.",
      },
      {
        kind: "para",
        text: "The numbers below come directly from NetSuite and are the company's actual financials. Everything here is sensitive.",
      },
      {
        kind: "stats",
        items: [
          { k: "Total Income · Jan to Sep", v: whole(T.income.total), sub: "every income account the API returns; the report adds Ticket Sales" },
          { k: "Total Expense · Jan to Sep", v: whole(T.expense.total), sub: `${NS.accountCount} accounts with activity across income and expense` },
          { k: "Net Ordinary Income", v: whole(T.ordinary.total), tone: T.ordinary.total < 0 ? "neg" : "pos", sub: `${positives.length} of 9 months positive: ${positives.join(", ")}` },
          { k: "Net Income", v: whole(T.net.total), tone: T.net.total < 0 ? "neg" : "pos", sub: `after ${whole(T.otherIncome.total)} of other income and ${whole(T.otherExpense.total)} of other expense` },
        ],
      },
      {
        kind: "source",
        text: `Source: NetSuite, pulled ${NS.readOn}.`,
      },
      { kind: "h2", text: "Detailed P&L, January To September 2026, Closed" },
      {
        kind: "para",
        text: "You can expand the rows below if you would like additional detail. If you have questions, direct them to Aisha or Jordana.",
      },
      {
        kind: "table",
        id: "ns-income-statement",
        caption: "Income Statement · 2026 · January to September · Dollars · Accounting-Period Basis",
        columns: NS.months,
        columnSubs: NS.closed.map((c) => (c ? "Closed" : "Open")),
        totalLabel: "Jan to Sep",
        rows,
        source: `Source: NetSuite, pulled ${NS.readOn}.`,
      },
      {
        kind: "chart",
        id: "ns-monthly",
        title: "Total Income Against Total Expense, By Period",
        categories: NS.months,
        bars: [
          { name: "Total Income", values: T.income.cells, tone: "accent" },
          { name: "Total Expense", values: T.expense.cells, tone: "mid" },
        ],
        line: { name: "Net Income", values: T.net.cells },
        caption: `Source: NetSuite, pulled ${NS.readOn}.`,
      },
      { kind: "h2", text: "Below The Line" },
      {
        kind: "para",
        text: `Other income of ${whole(T.otherIncome.total)} and other expense of ${whole(T.otherExpense.total)} turn the operating result of ${whole(T.ordinary.total)} into net income of ${whole(T.net.total)}. The other expense is interest paid (${whole(57150.06)}), interest accrued (${whole(936.14)}), factoring fees (${whole(53138.1)}) and other expense (${whole(130922.51)}). ${netPositives.length} of the nine months close positive at the bottom line: ${netPositives.join(", ")}.`,
      },
      {
        kind: "para",
        text: "Honestly, half of this is clean-up or carry-forward from earlier events that does not reflect operating performance, and a good chunk is the cost we have paid to factor, the mechanism that has let us keep cash flowing.",
      },
    ],
  },
  {
    slug: "estimate-oct-dec",
    ref: "2",
    title: "October Through December, *What David Sees.*",
    kicker: "2 · The Estimate",
    blocks: PAGE2_BLOCKS,
  },

  PAGE3,
  PAGE4,
  PAGE5,
  PAGE6,
  PAGE7,
  ];
}

export const FINANCE_REVIEW_PAGES: DocPage[] = buildFinanceReviewPages(SNAPSHOT);
