// =============================================================================
// COMPANY FINANCE REVIEW (/finance-review) , David's working surface for the
// finance review: long-form pages on the th-longform surface (the contents
// rail, the CIP canon), prose-anchored, with the books' tables and charts set
// inline and a Next at the foot of every page. Born 10/25 on a branch of the
// proposals repo; moved to its own surface 10/26. Pages arrive one at a time
// on David's word.
//
// Data: page 1 is the NetSuite income statement (content/finance-review-ns-data.ts,
// pulled over SuiteQL); the pro forma's January to September block
// (content/finance-review-data.ts) stays for page 1's comparison; the October
// to December estimate and the cash worksheet are read live from the
// SharePoint workbook at request time (lib/finance-source.ts), with the
// committed snapshot (content/finance-review-live-snapshot.json) as the
// fallback. Labels are the sources' own; nothing is hand-typed.
// =============================================================================
import type { DocBlock, DocPage, DocRow } from "./doc";
import { NS } from "./finance-review-ns-data";
import { PF } from "./finance-review-data";
import { SNAPSHOT } from "@/lib/finance-source";
import type { FinanceLive, Q4Live, CashLive, LiveSource, LiveRow } from "@/lib/finance-live";

const money = (x: number) => (x < 0 ? `($${Math.abs(x).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })})` : `$${x.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
const whole = (x: number) => (x < 0 ? `($${Math.abs(Math.round(x)).toLocaleString("en-US")})` : `$${Math.round(x).toLocaleString("en-US")}`);
const T = NS.totals;

// David's NetSuite income statement screenshot (Jan to Sep aggregate, 10/25): the
// three lines the API role cannot see, and the report's revenue total.
const SCREEN = { totalIncome: 5991567.5, ticketSales: 1449.91, cellPhone: 17107.23, wellbeing: 18121.76 };
const roleTypes = "checks, credit memos, invoices, journal entries and vendor bills";

const rows: DocRow[] = [
  ...NS.income,
  { label: "Total - Income", cells: T.income.cells, total: T.income.total, style: "total",
    note: `Every income account with activity in the nine closed periods, as the API returns it. The NetSuite income statement report shows ${money(SCREEN.totalIncome)}, which is this figure plus 43400 - Ticket Sales at ${money(SCREEN.ticketSales)}: that account has no transaction lines visible to the integration role, which reads ${roleTypes} only.` },
  ...NS.expense,
  { label: "Total - Expense", cells: T.expense.cells, total: T.expense.total, style: "total",
    note: `Every expense account with activity, parents opening to their accounts. Two lines run above the report by small amounts: 61400 - Cell Phone (${money(17307.22)} here against ${money(SCREEN.cellPhone)} on the report) and 61800 - Wellbeing Benefit (${money(18141.41)} against ${money(SCREEN.wellbeing)}), the shape of vendor credits the integration role cannot read. The other ${26 - 3} lines on the report tie to the penny.` },
  { label: "Net Ordinary Income", cells: T.ordinary.cells, total: T.ordinary.total, style: "net",
    note: "Total Income less Total Expense, month by month: the operating line, before other income and other expense." },
  ...NS.otherIncome,
  ...NS.otherExpense,
  { label: "Net Income", cells: T.net.cells, total: T.net.total, style: "final",
    note: "Net Ordinary Income plus other income, less other expense (interest paid and accrued, factoring fees, other expense)." },
];

const positives = NS.months.filter((_, m) => T.ordinary.cells[m] > 0);
const netPositives = NS.months.filter((_, m) => T.net.cells[m] > 0);
const pfRevenueOver = PF.base.total! - T.income.total;
const pfExpenseUnder = T.expense.total - PF.expenses.total!;


// ---------------------------------------------------------------------------
// Page 2 (David 10/25 night, revised the same night): January through September
// locked from the books, October through December estimated from the pro
// forma's own elements. The estimate is carried at the client-line level (the
// practice-area rows are their lines' sums, so the sheet's PAD formula gap does
// not hide two lines). The purple lines are assumptions: off by default, a
// switch at the top of the page brings them in, and every figure, table and
// chart on the page moves with it.
// ---------------------------------------------------------------------------

/* ---- pages 3 and 4: the cash worksheet from the current October 31 column through June 30, 2027, first with anything
   purple taken out of Cash In, then as the sheet carries it with a switch for the purple items (David 10/26) ---- */
const liveLine = (source: LiveSource, what: string) =>
  source.live
    ? `${what}: live from the Finance Binder, version ${source.version ?? "?"}, saved ${source.savedAt}${source.savedBy ? ` by ${source.savedBy}` : ""}, read ${source.readAt}. The page checks SharePoint for a new save every minute.`
    : `${what}: the committed snapshot, version ${source.version ?? "?"}, saved ${source.savedAt}; SharePoint was not read on this request, so the figures are the last pull.`;

const cents = (x: number) => Math.round(x * 100) / 100;
const addUp = (a: number[]) => cents(a.reduce((s, v) => s + v, 0));

type CashKid = LiveRow & { note?: string };
type CashView = Omit<CashLive, "cashIn"> & { cashIn: LiveRow & { children: CashKid[] } };

/** The cash window with the purple items in (on) or out (off). Off: every purple cell leaves Cash In, a line purple in
 *  full leaves the table, and Cash In, the Anticipated 15-Day Balance and every later Beginning Balance are recomputed
 *  from what remains; Cash Out is the sheet's own either way. Purple is whatever the parser read on the last refresh. */
const cashView = (CASH: CashLive, on: boolean): CashView => {
  const when = (k: LiveRow) =>
    CASH.periods.map((p, i) => (k.purple?.[i] && Math.abs(k.cells[i]) > 0.004 ? `${p.label}, ${p.year} (${whole(k.cells[i])})` : null)).filter((x): x is string => !!x).join("; ");
  if (on) {
    const kids: CashKid[] = (CASH.cashIn.children ?? []).map((k) =>
      !k.purple
        ? k
        : { ...k, note: k.flag === "Assumption" ? `The sheet shows this line in purple, an item not yet confirmed: ${when(k)}. The switch above takes it out.` : `Purple in the sheet for ${when(k)}; the line's other periods are not purple. The switch above takes the purple periods out.` },
    );
    return { ...CASH, cashIn: { ...CASH.cashIn, children: kids } };
  }
  const kids: CashKid[] = [];
  for (const k of CASH.cashIn.children ?? []) {
    if (!k.purple) { kids.push(k); continue; }
    const cells = k.cells.map((v, i) => (k.purple![i] ? 0 : v));
    if (cells.every((v) => Math.abs(v) < 0.005)) continue;
    kids.push({ label: k.label, sub: k.sub, cells, total: addUp(cells), flag: "Purple periods out", note: `Purple in the sheet for ${when(k)}; those cells are out of this line and of Cash In. The line's other periods stand.` });
  }
  const inCells = CASH.periods.map((_, i) => addUp(kids.map((k) => k.cells[i])));
  const beginning: number[] = [], balance: number[] = [];
  CASH.periods.forEach((_, i) => {
    beginning[i] = i === 0 ? CASH.beginning[0] : balance[i - 1];
    balance[i] = cents(beginning[i] + inCells[i] - CASH.cashOut.cells[i]);
  });
  let lo = 0; balance.forEach((v, i) => { if (v < balance[lo]) lo = i; });
  return { ...CASH, beginning, balance, cashIn: { ...CASH.cashIn, cells: inCells, total: addUp(inCells), children: kids }, lowest: { iso: CASH.periods[lo].iso, label: `${CASH.periods[lo].label}, ${CASH.periods[lo].year}`, value: balance[lo] } };
};

const cashBlocks = (CASH: CashLive, source: LiveSource, on: boolean): DocBlock[] => {
  const V = cashView(CASH, on);
  const p0 = CASH.periods[0], pN = CASH.periods[CASH.periods.length - 1];
  const yearSubs = CASH.periods.map((p) => String(p.year));
  const span = `${p0.label}, ${p0.year} to ${pN.label}, ${pN.year}`;
  const n = CASH.purple.length, wholeN = CASH.purple.filter((p) => p.whole).length, partN = n - wholeN;
  const endBal = V.balance[V.balance.length - 1];
  const rows: DocRow[] = [
    { label: "Beginning Balance", cells: V.beginning, note: on ? "The sheet's row 3: the balance carried into each period, the prior period's Anticipated 15-Day Balance." : `The first period's balance is the sheet's own, ${whole(CASH.beginning[0])}; every later one is the prior period's recomputed Anticipated 15-Day Balance.` },
    { ...V.cashIn, style: "total", note: on ? "The sheet's Cash In row, the client lines beneath it added up. Each line carries its Project Code as the sheet does; a line in purple carries an Assumption chip and opens to the periods in purple." : `Cash In recomputed from the lines that remain once every purple cell is out: ${whole(CASH.purpleTotal)} across ${n} purple items leaves the sheet's ${whole(CASH.cashIn.total)}, so ${whole(V.cashIn.total)} stands for the window.` },
    { ...CASH.cashOut, style: "total", note: "The sheet's Cash Out row: Compensation, Vendors, Debt, Office and Recurring Expenses, each opening to its lines. The purple rule does not touch it." },
    { label: "Anticipated 15-Day Balance", cells: V.balance, style: "final", note: on ? "Beginning Balance plus Cash In less Cash Out, as the sheet computes it for each period." : "Beginning Balance plus the recomputed Cash In less Cash Out, period by period, each ending balance carried into the next period." },
  ];
  const removed: DocBlock[] = on ? [] : [
    { kind: "h2", text: "What Left the Table" },
    { kind: "para", text: `${n} Cash In lines carry purple in the window, ${wholeN} in full and ${partN} in some periods, ${whole(CASH.purpleTotal)} in all. Each is listed with what left it.` },
    { kind: "list", items: CASH.purple.map((p) => `${p.label}${p.sub && p.sub !== "no Project Code" ? ` (${p.sub})` : ""}: ${whole(p.total)}${p.whole ? ", the whole line" : `, ${p.cells.filter((v) => Math.abs(v) > 0.004).length} of its periods`}`) },
  ];
  return [
    {
      kind: "lead",
      bold: on ? "The cash worksheet as the Finance Binder carries it, the purple items in." : "The cash worksheet with anything in purple taken out of Cash In.",
      text: on
        ? `A carbon copy of the Cash Tracker 2026 sheet from the current October 31 column through June 30, 2027: ${CASH.periods.length} semi-monthly periods, the Beginning Balance, Cash In by client with its Project Code, Cash Out by the sheet's five sections and their lines, and the Anticipated 15-Day Balance. ${n} Cash In lines carry purple in the window, ${whole(CASH.purpleTotal)} of the sheet's ${whole(CASH.cashIn.total)}; each carries an Assumption chip and opens to the periods in purple. The switch above takes them out and recomputes the balances, the picture on page 3. The sheet's own year labels drift; the dates here are repaired by position.`
        : `The Cash Tracker 2026 sheet from the current October 31 column through June 30, 2027, ${CASH.periods.length} semi-monthly periods, read as the sheet reads except for one rule: a purple cell in a Cash In line is an item not yet confirmed, and it is out. A line purple in full leaves the table; a line purple in some periods keeps its other periods. Cash In, the Anticipated 15-Day Balance and every later Beginning Balance are recomputed from what remains; Cash Out is the sheet's own. Purple is read from the sheet on every refresh, any shade of it, so a line that turns purple in SharePoint leaves this page within a minute and one that turns black comes back.`,
    },
    { kind: "source", text: liveLine(source, "The cash worksheet") },
    {
      kind: "stats",
      items: [
        { k: `Beginning Balance · ${p0.label}`, v: whole(CASH.beginning[0]), sub: "carried into the first period of the window, the sheet's own" },
        { k: `Cash In · ${span}`, v: whole(V.cashIn.total), sub: on ? `${V.cashIn.children.length} client lines, ${n} with purple` : `${V.cashIn.children.length} lines remain; ${whole(CASH.purpleTotal)} of purple out` },
        { k: `Cash Out · ${span}`, v: whole(CASH.cashOut.total), sub: `${CASH.cashOut.children?.length ?? 0} sections, the sheet's own` },
        { k: `Anticipated Balance · ${pN.label}, ${pN.year}`, v: whole(endBal), tone: endBal < 0 ? "neg" : "pos", sub: `lowest in the window ${whole(V.lowest.value)} on ${V.lowest.label}` },
      ],
    },
    { kind: "h2", text: "The Worksheet" },
    {
      kind: "para",
      text: on
        ? `Semi-monthly columns, the 15th and the end of each month. Cash In opens to every client line with a figure in the window; Cash Out opens to the sections and each section to its lines. The balance row is the sheet's own formula, period by period.`
        : `Semi-monthly columns, the 15th and the end of each month. Cash In opens to the lines that remain; a line that lost some periods to the rule carries a chip and opens to say which. Cash Out opens to the sections and each section to its lines. The balance row is recomputed, period by period.`,
    },
    {
      kind: "table",
      id: on ? "cash-tracker" : "cash-tracker-purple-out",
      caption: `Cash Tracker 2026 · ${span} · Dollars · ${on ? "Purple In" : "Purple Out"} · ${source.live ? "Live" : "Snapshot"}`,
      columns: CASH.periods.map((p) => p.label),
      columnSubs: yearSubs,
      rows,
      expandHint: "Cash In opens to client lines; Cash Out opens to sections and their lines. Rows open to their reading.",
      source: `Source: SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet Cash Tracker 2026, columns ${p0.label} ${p0.year} through ${pN.label} ${pN.year}. Labels are the sheet's own.${on ? "" : " Purple cells in the Cash In lines are out; Cash In and the balances are recomputed."}`,
    },
    {
      kind: "chart",
      id: on ? "cash-monthly" : "cash-monthly-purple-out",
      title: on ? "Cash In Against Cash Out, by Period" : "Cash In Without the Purple Against Cash Out, by Period",
      categories: CASH.periods.map((p) => p.label),
      bars: [
        { name: "Cash In", values: V.cashIn.cells, tone: "accent" },
        { name: "Cash Out", values: CASH.cashOut.cells, tone: "mid" },
      ],
      line: { name: "Balance", values: V.balance },
      caption: "Dollars by period from the same rows as the table; the strip beneath is the Anticipated 15-Day Balance. Hover a period to read its figures.",
    },
    ...removed,
  ];
};

const cashPages = (CASH: CashLive, source: LiveSource): [DocPage, DocPage] => {
  const OFF = cashBlocks(CASH, source, false), ON = cashBlocks(CASH, source, true);
  const n = CASH.purple.length, t = whole(CASH.purpleTotal);
  return [
    { slug: "cash-oct-jun", ref: "3", title: "The cash picture, *anything purple removed.*", kicker: "3 · The Cash Worksheet, Purple Out", blocks: OFF },
    {
      slug: "cash-oct-jun-purple-in",
      ref: "4",
      title: "The cash picture, *the purple items back in.*",
      kicker: "4 · The Cash Worksheet, Purple In",
      blocks: OFF,
      toggle: {
        label: "Purple items",
        defaultOn: true,
        onNote: `On: the ${n} purple items, ${t} of Cash In in the window, are in every figure on this page, as the sheet carries them.`,
        offNote: `Off: the ${n} purple items, ${t}, are out of Cash In and the balances are recomputed from what remains, the picture on page 3.`,
        blocksOn: ON,
      },
    },
  ];
};

export function buildFinanceReviewPages(live: FinanceLive): DocPage[] {
  const Q4: Q4Live = live.q4;
  const source: LiveSource = live.source;

const q4 = (c: number[]) => c.reduce((a, b) => a + b, 0);
  const YEAR_MONTHS = [...NS.months, ...Q4.months];
  const belowLine = T.otherIncome.total - T.otherExpense.total;
  const allLinesCells = [0, 1, 2].map((m) => Q4.sections.reduce((a, s) => a + s.linesSum[m], 0));
  const allLinesTotal = q4(allLinesCells);
  const purpleCells = [0, 1, 2].map((m) => Q4.purple.reduce((a, p) => a + p.cells[m], 0));
  const sectionGaps = Q4.sections.map((s) => ({ label: s.label, gap: q4(s.linesSum) - s.total })).filter((g) => Math.abs(g.gap) > 0.5);
  const padGap = allLinesTotal - Q4.top.base.total;
  const expenseGap = Q4.expenseSum.total - Q4.top.expenses.total;
  
  type View = {
    sections: { label: string; cells: number[]; total: number; sheetCells: number[]; sheetTotal: number; children: (typeof Q4.sections)[number]["children"] }[];
    revCells: number[]; revTotal: number; netCells: number[]; netTotal: number;
    fyRevenue: number; fyExpense: number; fyOrdinary: number; fyNet: number;
  };
  const view = (on: boolean): View => {
    const sections = Q4.sections
      .map((s) => {
        const kids = (s.children ?? []).filter((k) => on || k.flag !== "Assumption");
        const cells = [0, 1, 2].map((m) => kids.reduce((a, k) => a + k.cells[m], 0));
        return { label: s.label, cells, total: q4(cells), sheetCells: s.cells, sheetTotal: s.total, children: kids };
      })
      .filter((s) => s.children && s.children.length);
    const revCells = [0, 1, 2].map((m) => sections.reduce((a, s) => a + s.cells[m], 0));
    const revTotal = q4(revCells);
    const netCells = [0, 1, 2].map((m) => revCells[m] - Q4.expenseSum.cells[m]);
    const netTotal = q4(netCells);
    return { sections, revCells, revTotal, netCells, netTotal, fyRevenue: T.income.total + revTotal, fyExpense: T.expense.total + Q4.expenseSum.total, fyOrdinary: T.ordinary.total + netTotal, fyNet: T.net.total + netTotal };
  };
  
  const assumptionItems = Q4.purple.map((p) => `${p.label}${p.sub ? ` (${p.sub})` : ""}, ${p.section}: ${whole(p.total)} across ${Q4.months.filter((_, m) => Math.abs(p.cells[m]) > 0.5).join(", ")}.`);
  
  const topLineRows: DocRow[] = [
    { label: "Base Revenue, the sheet's row", cells: Q4.top.base.cells, total: Q4.top.base.total, style: "total", note: "Typed into the sheet as the sum of its six practice-area rows; Forecasted Revenue equals it in these months, since no pipeline is added." },
    { label: "Practice-area rows, as the sheet carries them", cells: Q4.sectionsSum.cells, total: Q4.sectionsSum.total },
    { label: "Client lines under them, added", cells: allLinesCells, total: allLinesTotal, style: "net",
      note: sectionGaps.length ? `${whole(padGap)} more than the sheet's row. The gap sits in ${sectionGaps.map((g) => `${g.label} (${whole(g.gap)})`).join(" and ")}: that section row's formula does not reach every line beneath it, so the lines, not the row, are what this page carries.` : "Equal to the sheet's row." },
    { label: "of which purple assumptions", cells: purpleCells, total: Q4.purpleTotal, note: `The four revenue lines set in purple on the sheet: ${Q4.purple.map((p) => p.label).join("; ")}. Off by default on this page; the switch at the top brings them in.` },
    { label: "Client lines without the assumptions", cells: allLinesCells.map((v, m) => v - purpleCells[m]), total: allLinesTotal - Q4.purpleTotal, style: "net", note: "What the page carries as revenue for the quarter with the switch off." },
    { label: "Expenses, the sheet's row", cells: Q4.top.expenses.cells, total: Q4.top.expenses.total, style: "total" },
    { label: "Category lumps and lines, added", cells: Q4.expenseSum.cells, total: Q4.expenseSum.total, style: "net", note: expenseGap === 0 ? "Equal to the sheet's row: what the page carries as expense for the quarter." : `Off the sheet's row by ${money(expenseGap)}.` },
  ];
  
  const page2Blocks = (on: boolean): DocBlock[] => {
    const v = view(on);
    const yearRows: DocRow[] = [
      { label: "Revenue", cells: [T.income.total, ...v.revCells, v.revTotal], total: v.fyRevenue, style: "total",
        note: `January through September is the books' Total Income (page 1). October through December is the pro forma's client lines added up by practice area${on ? ", the purple assumptions included" : ", the purple assumptions switched off"}. The two sources sit on different structures (accounts in the books, practice areas in the sheet), so the practice areas below carry the estimate months only.`,
        children: v.sections.map((sec) => ({ label: sec.label, cells: [null, ...sec.cells, sec.total], total: sec.total,
          children: (sec.children ?? []).map((k) => ({ label: k.label, sub: k.sub, flag: k.flag, cells: [null, ...k.cells, k.total], total: k.total })) })) },
      { label: "Expenses", cells: [T.expense.total, ...Q4.expenseSum.cells, Q4.expenseSum.total], total: v.fyExpense, style: "total",
        note: "January through September is the books' Total Expense. October through December is the pro forma's expense elements, the category lumps and their lines added together, which is what its Expenses row carries for those months. The sheet keeps Interest Paid inside Expenses, where the books carry interest below the operating line.",
        children: Q4.expenseCats.map((c) => ({ label: c.label, cells: [null, ...c.cells, c.total], total: c.total })) },
      { label: "Net Ordinary Income", cells: [T.ordinary.total, ...v.netCells, v.netTotal], total: v.fyOrdinary, style: "net",
        note: "Revenue less Expenses on each side: the books' operating line for the closed months, revenue carried less the sheet's expense elements for the estimate months." },
      { label: "Other Income and Expense, Books", cells: [belowLine, null, null, null, null], total: belowLine,
        note: `The books' line below operating income for January through September: ${money(T.otherIncome.total)} of other income less ${money(T.otherExpense.total)} of other expense. The pro forma carries nothing below its Net Income row, so the estimate months show no figure here.` },
      { label: "Net Income", cells: [T.net.total, ...v.netCells, v.netTotal], total: v.fyNet, style: "final",
        note: "The books' Net Income for the closed months plus the estimate months' revenue carried less expenses." },
    ];
    const revenueRows: DocRow[] = [
      ...v.sections.map((s) => ({ label: s.label, cells: s.cells, total: s.total, children: s.children, style: "indent" as const,
        note: Math.abs(s.total - (on ? q4(Q4.sections.find((x) => x.label === s.label)!.linesSum) : s.total)) > 0.5 || Math.abs(q4(Q4.sections.find((x) => x.label === s.label)!.linesSum) - s.sheetTotal) > 0.5
          ? `The sheet's row for this practice area reads ${whole(s.sheetTotal)} for the quarter; its lines add to ${whole(q4(Q4.sections.find((x) => x.label === s.label)!.linesSum))}${on ? "" : `, ${whole(q4(Q4.sections.find((x) => x.label === s.label)!.linesSum) - s.total)} of which are purple assumptions switched off here`}. ${Math.abs(q4(Q4.sections.find((x) => x.label === s.label)!.linesSum) - s.sheetTotal) > 0.5 ? "The row's formula does not reach every line beneath it; this page carries the lines." : ""}`.trim()
          : undefined })),
      { label: "Revenue carried, October to December", cells: v.revCells, total: v.revTotal, style: "total",
        note: `The client lines added up${on ? ", the purple assumptions included" : ", without the purple assumptions"}. The sheet's own Base Revenue row for these months reads ${whole(Q4.top.base.total)}.` },
    ];
    const expenseRows: DocRow[] = [
      ...Q4.expenseCats.map((c) => ({ ...c, style: "indent" as const })),
      { label: "Expenses", cells: Q4.top.expenses.cells, total: Q4.top.expenses.total, style: "total", note: "The sheet's own row for these months, the category lumps and their lines added together." },
    ];
    const onOff = on ? "with the purple assumptions switched on" : "with the purple assumptions switched off";
    return [
      {
        kind: "lead",
        bold: "January through September is locked; October through December is an estimate built from the pro forma's own elements.",
        text: `The closed months are the books from page 1. The estimate months are the live pro forma as you saved it on ${source.savedAt} (version ${source.version}), carried at the client line: each practice area is its lines added up, and each line shows its client and Project Code. Revenue lines set in purple on the sheet are assumptions. They are off by default, so the page reads ${onOff}; the switch at the top of the page brings them in and moves every figure with them. The sheet's typed top lines are checked against what its lines add to.`,
      },
      { kind: "source", text: liveLine(source, "October through December") },
      {
        kind: "stats",
        items: [
          { k: "Revenue · Jan to Sep · Closed", v: whole(T.income.total), sub: "the books' Total Income" },
          { k: "Revenue · Oct to Dec · Estimate", v: whole(v.revTotal), sub: on ? `the client lines, ${whole(Q4.purpleTotal)} of purple assumptions included` : `the client lines; ${whole(Q4.purpleTotal)} of purple assumptions switched off` },
          { k: "Revenue · FY 2026 · Outlook", v: whole(v.fyRevenue), sub: "closed plus estimate" },
          { k: "Net Ordinary Income · FY 2026", v: whole(v.fyOrdinary), tone: v.fyOrdinary < 0 ? "neg" : "pos", sub: `${whole(T.ordinary.total)} closed, ${whole(v.netTotal)} estimated` },
        ],
      },
      {
        kind: "stats",
        items: [
          { k: "Expenses · Jan to Sep · Closed", v: whole(T.expense.total), sub: "the books' Total Expense" },
          { k: "Expenses · Oct to Dec · Estimate", v: whole(Q4.expenseSum.total), sub: "the sheet's category lumps and lines" },
          { k: "Expenses · FY 2026 · Outlook", v: whole(v.fyExpense), sub: "closed plus estimate" },
          { k: "Net Income · FY 2026", v: whole(v.fyNet), tone: v.fyNet < 0 ? "neg" : "pos", sub: `after ${whole(belowLine)} below the line in the closed months` },
        ],
      },
      { kind: "h2", text: "Locked and Estimated" },
      {
        kind: "para",
        text: `The closed column is the books on the accounting-period basis, by account. The estimate columns are the sheet, by practice area and client line for revenue and by category for expense. The two do not share a structure, so the year table opens the estimate months to the sheet's elements and leaves the closed column to the books' totals. One basis difference to hold in mind: the sheet keeps *Interest Paid* inside Expenses (${whole(q4(Q4.expenseCats.find((c) => c.label === "Interest Paid")?.cells ?? [0]))} for the quarter), where the books carry interest below the operating line.`,
      },
      {
        kind: "table",
        id: "year-2026",
        caption: `2026 · January to September Closed, October to December Estimated · ${on ? "Assumptions On" : "Assumptions Off"} · Dollars`,
        columns: ["Jan to Sep", ...Q4.months, "Oct to Dec"],
        columnSubs: ["Closed · Books", "Estimate", "Estimate", "Estimate", "Estimate · Sheet"],
        totalLabel: "FY 2026",
        rows: yearRows,
        expandHint: "Revenue opens to the practice areas, and each practice area to its client lines with their Project Codes; Expenses opens to the sheet's categories. The closed column stays with the books' totals. Totals open to their reading.",
        source: `Closed: NetSuite over SuiteQL, read ${NS.readOn}, page 1. Estimate: SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, columns Oct to Dec, version ${source.version} saved ${source.savedAt}, read ${source.readAt}.`,
      },
      {
        kind: "chart",
        id: "year-monthly",
        title: `Revenue Against Expenses, Closed and Estimated, by Month · ${on ? "Assumptions On" : "Assumptions Off"}`,
        categories: YEAR_MONTHS,
        bars: [
          { name: "Revenue", values: [...T.income.cells, ...v.revCells], tone: "accent" },
          { name: "Expenses", values: [...T.expense.cells, ...Q4.expenseSum.cells], tone: "mid" },
        ],
        line: { name: "Net Ordinary", values: [...T.ordinary.cells, ...v.netCells] },
        estimateFrom: NS.months.length,
        estimateLabel: "Estimate, the sheet",
        caption: "Closed months are solid, from the books; estimate months are outlined, from the sheet. The strip beneath is revenue less expenses on each side. Hover a month to read its figures.",
      },
      { kind: "h2", text: "The Top Lines Against the Lines" },
      {
        kind: "para",
        text: `For October through December the sheet's Base Revenue row equals its six practice-area rows to the dollar, Forecasted Revenue equals Base Revenue (no pipeline is added in these months), and its Expenses row equals the category lumps and their lines to the dollar${expenseGap === 0 ? "" : ` (off by ${money(expenseGap)})`}. The one place the sheet's top line is not what its lines say is revenue one level down: the client lines beneath the practice-area rows add to ${whole(allLinesTotal)}, ${whole(padGap)} more than the Base Revenue row, because ${sectionGaps.map((g) => `the ${g.label} row carries ${whole(g.gap)} less than its lines`).join(" and ")}. This page carries the lines. With the purple assumptions off, that is ${whole(allLinesTotal - Q4.purpleTotal)} for the quarter; with them on, ${whole(allLinesTotal)}.`,
      },
      {
        kind: "table",
        id: "top-lines",
        caption: "October to December · The Sheet's Typed Rows Against Its Elements · Dollars",
        columns: Q4.months,
        columnSubs: ["Estimate", "Estimate", "Estimate"],
        totalLabel: "Oct to Dec",
        rows: topLineRows,
        expandHint: "Each row opens to its reading.",
      },
      { kind: "h2", text: "Revenue, October through December" },
      {
        kind: "para",
        text: on
          ? `The six practice areas and every client line with a figure in the quarter (${Q4.lineCount} lines), the four purple lines included and carrying the Assumption flag, ${whole(Q4.purpleTotal)} of the quarter's ${whole(v.revTotal)}. One line is highlighted yellow on the sheet and is flagged as such.`
          : `The six practice areas and every client line with a figure in the quarter, without the four purple lines (${whole(Q4.purpleTotal)}, listed beneath as the work to do). One line is highlighted yellow on the sheet and is flagged as such; it stays in.`,
      },
      {
        kind: "table",
        id: "q4-revenue",
        caption: `Revenue Estimate · October to December · By Practice Area and Client Line · ${on ? "Assumptions On" : "Assumptions Off"} · Dollars`,
        columns: Q4.months,
        columnSubs: ["Estimate", "Estimate", "Estimate"],
        totalLabel: "Oct to Dec",
        rows: revenueRows,
        expandHint: "Practice areas open to their client lines; flags are the sheet's own colors. Practice-area figures are their lines added up.",
      },
      {
        kind: "callout",
        eyebrow: on ? "Assumptions, Switched On" : "Assumptions, Switched Off",
        text: on
          ? `The purple lines on the sheet, ${whole(Q4.purpleTotal)} across the quarter, are in the figures above. Each needs its basis set down before it stands as more than an assumption.`
          : `The purple lines on the sheet, ${whole(Q4.purpleTotal)} across the quarter, are out of every figure above. Switch them on at the top of the page to see the year as the sheet models it. Each needs its basis set down before it stands as more than an assumption.`,
      },
      { kind: "list", items: assumptionItems },
      {
        kind: "para",
        text: `Highlighted yellow on the sheet, not purple: ${Q4.yellow.map((y) => `${y.label} (${y.sub ?? "no Project Code"}), ${y.section}, ${whole(y.total)} across the quarter`).join("; ")}. The sheet does not say what the yellow means, so it is shown with its own flag and stays in the figures either way.`,
      },
      { kind: "h2", text: "Expenses, October through December" },
      {
        kind: "para",
        text: `The sheet's expense categories, each opening to its lump and its lines where it has both (Contractors, Payroll Expenses, Business Development, Rent & Lease and Project Starset carry lines; the rest are a single figure a month). Payroll Expenses is ${whole(Q4.expenseCats.find((c) => c.label === "Payroll Expenses")?.total ?? 0)} of the quarter's ${whole(Q4.expenseSum.total)}; Project Starset ${whole(Q4.expenseCats.find((c) => c.label === "Project Starset")?.total ?? 0)}. The switch does not touch expenses.`,
      },
      {
        kind: "table",
        id: "q4-expense",
        caption: "Expense Estimate · October to December · By Category · Dollars",
        columns: Q4.months,
        columnSubs: ["Estimate", "Estimate", "Estimate"],
        totalLabel: "Oct to Dec",
        rows: expenseRows,
        expandHint: "Categories open to their lump and their lines.",
      },
      {
        kind: "source",
        text: `Estimate source: SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, 2026 block, columns Oct to Dec, version ${source.version} saved ${source.savedAt}, read ${source.readAt}. Labels are the sheet's own; Assumption marks a revenue line set in purple on the sheet; Yellow in the sheet marks a line with a yellow fill. Revenue is carried at the client line, the practice-area rows being their lines added up. Page 1's pro forma comparison reads the earlier save (version 4625) and is left in place.`,
      },
    ];
  };
  
  const PAGE2_OFF = page2Blocks(false);
  const PAGE2_ON = page2Blocks(true);
  const [PAGE3, PAGE4] = cashPages(live.cash, source);
  return [

  {
    slug: "cover",
    ref: "",
    title: "Company Finance Review",
    kicker: "Third Horizon · Working Review · October 2026",
    cover: {
      heading: "Company Finance Review",
      sub: "A tool that assesses short term cash needs and the short/medium term decisions required for business structure. This includes a tactical sequencing of what needs to happen to execute both strategies.",
      note: "Prepared for David Smith",
      date: `NetSuite read ${NS.readOn}`,
    },
    blocks: [{ kind: "contents" }],
  },
  {
    slug: "income-statement-jan-sep",
    ref: "1",
    title: "January through September, *as the books closed.*",
    kicker: "1 · The Income Statement",
    blocks: [
      {
        kind: "lead",
        bold: "The income statement for January through September 2026 is the first exhibit, pulled straight from NetSuite.",
        text: `It comes over the NetSuite API on ${NS.readOn}: every profit and loss account with activity in the nine accounting periods, posting transactions only, on the accounting-period basis the books close on. All nine periods are closed. The table is laid out as NetSuite lays it out: parents open to their accounts, and each revenue account opens to its client lines with the Project Code on every line; click any total to read how it is built and where it differs from the printed report.`,
      },
      {
        kind: "stats",
        items: [
          { k: "Total Income · Jan to Sep", v: whole(T.income.total), sub: "every income account the API returns; the report adds Ticket Sales" },
          { k: "Total Expense · Jan to Sep", v: whole(T.expense.total), sub: `${NS.accountCount} accounts with activity across income and expense` },
          { k: "Net Ordinary Income", v: whole(T.ordinary.total), tone: T.ordinary.total < 0 ? "neg" : "pos", sub: `${positives.length} of 9 months positive: ${positives.join(", ")}` },
          { k: "Net Income", v: whole(T.net.total), tone: T.net.total < 0 ? "neg" : "pos", sub: `after ${whole(T.otherIncome.total)} of other income and ${whole(T.otherExpense.total)} of other expense` },
        ],
      },
      { kind: "h2", text: "The Statement" },
      {
        kind: "para",
        text: `Nine columns, one per accounting period, and a Jan to Sep column that sums them. Revenue sits in three families: *recurring* (${whole(794351.8)}, the non-subscription retainers plus DaaS subscriptions and member dues), *non-recurring* (${whole(5190364.88)}, fixed fee and time and materials) and *other* (${whole(5400.91)}). Payroll is ${whole(4163972.18)} of the ${whole(T.expense.total)} of expense; dues and subscriptions, carried mostly by data services, are the next ${whole(1168632.18)}.`,
      },
      {
        kind: "table",
        id: "ns-income-statement",
        caption: "Income Statement · 2026 · January to September · Dollars · Accounting-Period Basis",
        columns: NS.months,
        columnSubs: NS.closed.map((c) => (c ? "Closed" : "Open")),
        totalLabel: "Jan to Sep",
        rows,
        expandHint: "Parents open to their accounts; revenue accounts open to their client lines with Project Codes (a line with no customer on the entry carries its Project Code alone). Totals open to their reading.",
        source: `Source: NetSuite, SuiteQL over the REST API, read ${NS.readOn}. Posting transactions in the nine 2026 accounting periods January through September, every account of type Income, Other Income, Expense, Cost of Goods Sold and Other Expense. Labels are NetSuite's account numbers and names. Closed is the period's own flag.`,
      },
      {
        kind: "chart",
        id: "ns-monthly",
        title: "Total Income Against Total Expense, by Period",
        categories: NS.months,
        bars: [
          { name: "Total Income", values: T.income.cells, tone: "accent" },
          { name: "Total Expense", values: T.expense.cells, tone: "mid" },
        ],
        line: { name: "Net Income", values: T.net.cells },
        caption: "Dollars by accounting period from the same rows as the table; the net income strip beneath the periods is the bottom line after other income and expense. Hover a period to read its figures.",
      },
      { kind: "h2", text: "Below the Line" },
      {
        kind: "para",
        text: `Other income of ${whole(T.otherIncome.total)} and other expense of ${whole(T.otherExpense.total)} turn the operating result of ${whole(T.ordinary.total)} into net income of ${whole(T.net.total)}. The other expense is interest paid (${whole(57150.06)}), interest accrued (${whole(936.14)}), factoring fees (${whole(53138.1)}) and other expense (${whole(130922.51)}). ${netPositives.length} of the nine months close positive at the bottom line: ${netPositives.join(", ")}.`,
      },
      { kind: "h2", text: "Against the Pro Forma" },
      {
        kind: "stats",
        items: [
          { k: "Pro Forma Base Revenue", v: whole(PF.base.total!), sub: `${whole(pfRevenueOver)} above the books' Total Income` },
          { k: "Pro Forma Expenses", v: whole(PF.expenses.total!), sub: `${whole(pfExpenseUnder)} below the books' Total Expense` },
          { k: "Pro Forma Net Income", v: whole(PF.net.total!), tone: PF.net.total! < 0 ? "neg" : "pos", sub: `against ${whole(T.ordinary.total)} on the books' operating line` },
        ],
      },
      {
        kind: "para",
        text: `The live pro forma in the Finance Binder (2025 Pro Forma.xlsx, sheet PRO FORMA 2026, read ${PF.readOn}) carries the same nine months as Base Revenue of ${whole(PF.base.total!)}, Expenses of ${whole(PF.expenses.total!)} and Net Income of ${whole(PF.net.total!)}. Its Base Revenue row is typed values that run ${whole(pfRevenueOver)} above the books, while its six practice-area rows sum to ${whole(PF.sectionsTotal)}, ${whole(T.income.total - PF.sectionsTotal)} under the books' Total Income. Its Expenses line sits ${whole(pfExpenseUnder)} under the books, and it carries nothing below the operating line.`,
      },
      {
        kind: "callout",
        eyebrow: "For the Review",
        text: `Which revenue figure the review carries forward: the books' Total Income of ${whole(T.income.total)}, which the pro forma's practice-area lines track, or the pro forma's Base Revenue row, which runs ${whole(pfRevenueOver)} above it for the nine months.`,
      },
      {
        kind: "source",
        text: `Tie-out to David's NetSuite income statement (Jan to Sep aggregate, 10/25): 23 of the 26 account lines on the report tie to the penny. Three do not, all consistent with transaction types the integration role cannot read (it sees ${roleTypes}): 43400 - Ticket Sales (${money(SCREEN.ticketSales)} on the report, no visible lines here), 61400 - Cell Phone (${money(SCREEN.cellPhone)} on the report, ${money(17307.22)} here) and 61800 - Wellbeing Benefit (${money(SCREEN.wellbeing)} on the report, ${money(18141.41)} here). The report's Total Income is ${money(SCREEN.totalIncome)}; this page's is ${money(T.income.total)}.`,
      },
    ],
  },
  {
    slug: "estimate-oct-dec",
    ref: "2",
    title: "October through December, *what we think we know.*",
    kicker: "2 · The Estimate",
    blocks: PAGE2_OFF,
    toggle: {
      label: "Purple assumptions",
      offNote: `Off: the four purple lines, ${whole(Q4.purpleTotal)} for the quarter, are out of every figure on this page.`,
      onNote: `On: the four purple lines, ${whole(Q4.purpleTotal)} for the quarter, are in every figure on this page.`,
      blocksOn: PAGE2_ON,
    },
  },

  PAGE3,
  PAGE4,
  ];
}

export const FINANCE_REVIEW_PAGES: DocPage[] = buildFinanceReviewPages(SNAPSHOT);
