// =============================================================================
// COMPANY FINANCE REVIEW (/finance-review) — David's working surface for the
// finance review, built 10/25 as the first document on the proposals chassis:
// long-form pages on the AMA proposal's frame (the contents rail, the canon),
// prose-anchored, with the pro forma's tables and charts set inline and a
// Next at the foot of every page. Pages arrive one at a time on David's word;
// page 2 is pending.
//
// Data: content/finance-review-data.ts, generated from the live pro forma
// (SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026) on
// the date it carries. Row labels are the sheet's own. Figures from the
// September financial package are the NetSuite income statement through
// September 30, 2026, as the prior cut of this page carried them.
// =============================================================================
import type { DocPage, DocRow } from "./doc";
import { PF } from "./finance-review-data";

const money = (x: number) => (x < 0 ? `($${Math.abs(x).toLocaleString("en-US")})` : `$${x.toLocaleString("en-US")}`);

// The September financial package (NetSuite income statement through 9/30/2026).
const PKG = { revenue: 5991568, expenses: 6128452, operating: -136885, netOther: -182567, net: -319452 };
const gap = PF.base.total! - PF.sectionsTotal;
const aboveOperating = PF.net.total! - PKG.operating;
const revenueAbove = PF.base.total! - PKG.revenue;
const expensesBelow = PKG.expenses - PF.expenses.total!;
const positives = PF.months.filter((_, m) => PF.net.cells[m]! > 0);
const actuals = PF.labels.filter((l) => l === "Actual").length;

const rows: DocRow[] = [
  ...PF.sections.map((sec) => ({ ...sec, style: "indent" as const })),
  {
    ...PF.base,
    style: "total" as const,
    note: `The sheet's own Base Revenue row, typed values rather than a sum. The six practice-area rows above it add to ${money(PF.sectionsTotal)} for January through September, ${money(gap)} under this row. The practice-area rows' monthly sums track the NetSuite revenue close (January ${money(598242)} against the package's ${money(598243)}).`,
  },
  {
    ...PF.forecasted,
    style: "net" as const,
    note: "Base Revenue plus the pipeline. Through September the pipeline adds nothing, so this row equals Base Revenue; the two part ways in October through December.",
  },
  {
    ...PF.expenses,
    style: "total" as const,
    note: `The sheet's Expenses line, which carries the closed months through September (September ${money(PF.expenses.cells[8]!)} equals the NetSuite close). The expense category rows beneath it in the sheet, Contractors, Payroll Expenses, Rent & Lease, Project Starset and the rest, are plan values that do not add to this line in the closed months, so they stay off this table.`,
  },
  {
    ...PF.net,
    style: "final" as const,
    note: "Base Revenue less Expenses, month by month, as the sheet computes it.",
  },
];

export const FINANCE_REVIEW_PAGES: DocPage[] = [
  {
    slug: "cover",
    ref: "",
    title: "Company Finance Review",
    kicker: "Third Horizon · Working Review · October 2026",
    cover: {
      heading: "Company Finance Review",
      sub: "A tool that assesses short term cash needs and the short/medium term decisions required for business structure. This includes a tactical sequencing of what needs to happen to execute both strategies.",
      note: "Prepared for David Smith",
      date: `Read from the Finance Binder ${PF.readOn}`,
    },
    blocks: [{ kind: "contents" }],
  },
  {
    slug: "pro-forma-jan-sep",
    ref: "1",
    title: "January through September, *as the books closed.*",
    kicker: "1 · The Pro Forma",
    blocks: [
      {
        kind: "lead",
        bold: "The pro forma's January through September columns are the first exhibit.",
        text: `They are read straight from the live workbook in the Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, on ${PF.readOn}, with every row label as the sheet carries it. The table opens by practice area: click a practice area to see the client lines beneath it, and click any total to read how the sheet arrives at it.`,
      },
      {
        kind: "stats",
        items: [
          { k: "Base Revenue · Jan to Sep", v: money(PF.base.total!), sub: "the sheet's own row; equals Forecasted Revenue through September" },
          { k: "Expenses · Jan to Sep", v: money(PF.expenses.total!), sub: "the closed months, September to the dollar" },
          { k: "Net Income · Jan to Sep", v: money(PF.net.total!), tone: PF.net.total! < 0 ? "neg" : "pos", sub: `${positives.length} of 9 months positive: ${positives.join(", ")}` },
          { k: "Months Labeled Actual", v: `${actuals} of 9`, sub: "January through April; May through September read Projected" },
        ],
      },
      { kind: "h2", text: "The Columns" },
      {
        kind: "para",
        text: "The sheet labels January through April *Actual* and May through September *Projected*, although the May through September expense line sits within a dollar of the NetSuite close in four of the five months. The Jan to Sep column is this document's, the sum of the nine monthly cells; the sheet itself carries only a 2026 total.",
      },
      {
        kind: "table",
        id: "pf-jan-sep",
        caption: "Profit & Loss Pro Forma · 2026 · January to September · Dollars",
        columns: PF.months,
        columnSubs: PF.labels,
        totalLabel: "Jan to Sep",
        rows,
        expandHint: `Practice areas open to their client lines (${PF.kidsCount} lines with a figure in the nine months). Totals open to their reading.`,
        source: `Source: SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, 2026 block, read ${PF.readOn}. Actual and Projected are the sheet's own column labels. The practice-area rows are the sheet's section rows; Base Revenue, Forecasted Revenue, Expenses and Net Income are its own rows.`,
      },
      {
        kind: "chart",
        id: "pf-monthly",
        title: "Base Revenue Against Expenses, by Month",
        categories: PF.months,
        bars: [
          { name: "Base Revenue", values: PF.base.cells.map((v) => v ?? 0), tone: "accent" },
          { name: "Expenses", values: PF.expenses.cells.map((v) => v ?? 0), tone: "mid" },
        ],
        line: { name: "Net Income", values: PF.net.cells.map((v) => v ?? 0) },
        caption: "Dollars by month from the same rows as the table; the net income strip beneath the months reads Base Revenue less Expenses. Hover a month to read its figures.",
      },
      { kind: "h2", text: "What the Columns Say" },
      {
        kind: "para",
        text: `Three months closed positive, ${positives.join(", ")}, and the nine months net to ${money(PF.net.total!)}. The September financial package reads the same months as an operating loss of ${money(Math.abs(PKG.operating))} and a net loss of ${money(Math.abs(PKG.net))} after ${money(Math.abs(PKG.netOther))} of net other expense below the operating line. The pro forma lands ${money(aboveOperating)} above the package's operating line: its Base Revenue runs ${money(revenueAbove)} above the package's revenue (${money(PF.base.total!)} against ${money(PKG.revenue)}) and its Expenses ${money(expensesBelow)} below (${money(PF.expenses.total!)} against ${money(PKG.expenses)}).`,
      },
      {
        kind: "callout",
        eyebrow: "For the Review",
        text: `Which revenue figure the review carries forward: the practice-area lines, which track the NetSuite close, or the Base Revenue row, which runs ${money(gap)} above them for the nine months.`,
      },
      {
        kind: "source",
        text: "September financial package figures: NetSuite income statement through September 30, 2026 (revenue $5,991,568; total expenses $6,128,452; operating loss $136,885; net other expense $182,567; net loss $319,452). September's $50,300 of other income is one-time: a prior-period adjustment from the 2025 accounting system migration and two tax refunds.",
      },
    ],
  },
];
