// =============================================================================
// COMPANY FINANCE REVIEW (/finance-review) — David's working surface for the
// finance review, built 10/25 as the first document on the proposals chassis:
// long-form pages on the AMA proposal's frame (the contents rail, the canon),
// prose-anchored, with the books' tables and charts set inline and a Next at
// the foot of every page. Pages arrive one at a time on David's word; page 2
// is pending.
//
// Data (10/25, second cut): content/finance-review-ns-data.ts, the NetSuite
// income statement for the nine 2026 periods January through September,
// pulled over SuiteQL (posting transactions, accounting-period basis) and laid
// out as NetSuite lays it out. The pro forma (content/finance-review-data.ts,
// the live Finance Binder sheet) stays for the comparison at the foot of the
// page. Labels are the books' own; nothing is hand-typed.
// =============================================================================
import type { DocPage, DocRow } from "./doc";
import { NS } from "./finance-review-ns-data";
import { PF } from "./finance-review-data";
import { Q4 } from "./finance-review-q4-data";

const money = (x: number) => (x < 0 ? `($${Math.abs(x).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })})` : `$${x.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
const whole = (x: number) => (x < 0 ? `($${Math.abs(Math.round(x)).toLocaleString("en-US")})` : `$${Math.round(x).toLocaleString("en-US")}`);
const T = NS.totals;

// David's NetSuite income statement screenshot (Jan to Sep aggregate, 10/25): the
// three lines the API role cannot see, and the report's revenue total.
const SCREEN = { totalIncome: 5991567.5, ticketSales: 1449.91, cellPhone: 17107.23, wellbeing: 18121.76 };
const roleTypes = "checks, credit memos, invoices, journal entries and vendor bills";

const rows: DocRow[] = [
  ...NS.income,
  { label: "Total - Income", cells: T.income.cells, total: T.income.total, style: "total",
    note: `Every income account with activity in the nine closed periods, as the API returns it. The NetSuite income statement report shows ${money(SCREEN.totalIncome)}, which is this figure plus 43400 - Ticket Sales at ${money(SCREEN.ticketSales)}: that account has no transaction lines visible to the integration role, which reads ${roleTypes} only.` },
  ...NS.expense,
  { label: "Total - Expense", cells: T.expense.cells, total: T.expense.total, style: "total",
    note: `Every expense account with activity, parents opening to their accounts. Two lines run above the report by small amounts: 61400 - Cell Phone (${money(17307.22)} here against ${money(SCREEN.cellPhone)} on the report) and 61800 - Wellbeing Benefit (${money(18141.41)} against ${money(SCREEN.wellbeing)}), the shape of vendor credits the integration role cannot read. The other ${26 - 3} lines on the report tie to the penny.` },
  { label: "Net Ordinary Income", cells: T.ordinary.cells, total: T.ordinary.total, style: "net",
    note: "Total Income less Total Expense, month by month: the operating line, before other income and other expense." },
  ...NS.otherIncome,
  ...NS.otherExpense,
  { label: "Net Income", cells: T.net.cells, total: T.net.total, style: "final",
    note: "Net Ordinary Income plus other income, less other expense (interest paid and accrued, factoring fees, other expense)." },
];

const positives = NS.months.filter((_, m) => T.ordinary.cells[m] > 0);
const netPositives = NS.months.filter((_, m) => T.net.cells[m] > 0);
const pfRevenueOver = PF.base.total! - T.income.total;
const pfExpenseUnder = T.expense.total - PF.expenses.total!;


// ---------------------------------------------------------------------------
// Page 2 (David 10/25 night): January through September locked from the books,
// October through December estimated from the pro forma's own elements, purple
// lines flagged as assumptions (the work list), and the sheet's typed top lines
// checked against what its lines add to.
// ---------------------------------------------------------------------------
const q4 = (c: number[]) => c.reduce((a, b) => a + b, 0);
const YEAR_MONTHS = [...NS.months, ...Q4.months];
const yearRevenue = [...T.income.cells, ...Q4.sectionsSum.cells];
const yearExpense = [...T.expense.cells, ...Q4.expenseSum.cells];
const yearOrdinary = [...T.ordinary.cells, ...Q4.top.net.cells];
const belowLine = T.otherIncome.total - T.otherExpense.total;
const fyRevenue = T.income.total + Q4.sectionsSum.total;
const fyExpense = T.expense.total + Q4.expenseSum.total;
const fyOrdinary = T.ordinary.total + Q4.top.net.total;
const fyNet = T.net.total + Q4.top.net.total;
const linesTotal = Q4.sections.reduce((a, s) => a + q4(s.linesSum), 0);
const linesCells = [0, 1, 2].map((m) => Q4.sections.reduce((a, s) => a + s.linesSum[m], 0));
const sectionGaps = Q4.sections.map((s) => ({ label: s.label, gap: q4(s.linesSum) - s.total })).filter((g) => Math.abs(g.gap) > 0.5);
const topLineGap = linesTotal - Q4.top.base.total;
const expenseGap = Q4.expenseSum.total - Q4.top.expenses.total;

const yearRows: DocRow[] = [
  { label: "Revenue", cells: [T.income.total, ...Q4.sectionsSum.cells, Q4.sectionsSum.total], total: fyRevenue, style: "total",
    note: `January through September is the books' Total Income (page 1). October through December is the pro forma's six practice-area rows, which are what its Base Revenue and Forecasted Revenue rows carry for those months. The two sources sit on different structures (accounts in the books, practice areas in the sheet), so the practice areas below carry the estimate months only.`,
    children: Q4.sections.filter((sec) => sec.children && sec.children.length).map((sec) => ({ label: sec.label, cells: [null, ...sec.cells, sec.total], total: sec.total,
      children: (sec.children ?? []).map((k) => ({ label: k.label, sub: k.sub, flag: k.flag, cells: [null, ...k.cells, k.total], total: k.total })) })) },
  { label: "Expenses", cells: [T.expense.total, ...Q4.expenseSum.cells, Q4.expenseSum.total], total: fyExpense, style: "total",
    note: `January through September is the books' Total Expense. October through December is the pro forma's expense elements, the category lumps and their lines added together, which is what its Expenses row carries for those months. Note the sheet keeps Interest Paid inside Expenses, where the books carry interest below the operating line.`,
    children: Q4.expenseCats.map((c) => ({ label: c.label, cells: [null, ...c.cells, c.total], total: c.total })) },
  { label: "Net Ordinary Income", cells: [T.ordinary.total, ...Q4.top.net.cells, Q4.top.net.total], total: fyOrdinary, style: "net",
    note: "Revenue less Expenses on each side: the books' operating line for the closed months, the sheet's Net Income row for the estimate months." },
  { label: "Other Income and Expense, Books", cells: [belowLine, null, null, null, null], total: belowLine,
    note: `The books' line below operating income for January through September: ${money(T.otherIncome.total)} of other income less ${money(T.otherExpense.total)} of other expense. The pro forma carries nothing below its Net Income row, so the estimate months show no figure here.` },
  { label: "Net Income", cells: [T.net.total, ...Q4.top.net.cells, Q4.top.net.total], total: fyNet, style: "final",
    note: "The books' Net Income for the closed months plus the sheet's Net Income for the estimate months." },
];

const topLineRows: DocRow[] = [
  { label: "Base Revenue, the sheet's row", cells: Q4.top.base.cells, total: Q4.top.base.total, style: "total" },
  { label: "Forecasted Revenue, the sheet's row", cells: Q4.top.forecasted.cells, total: Q4.top.forecasted.total },
  { label: "Practice-area rows, added", cells: Q4.sectionsSum.cells, total: Q4.sectionsSum.total },
  { label: "Client lines under them, added", cells: linesCells, total: linesTotal },
  { label: "Lines less the Base Revenue row", cells: linesCells.map((v, m) => v - Q4.top.base.cells[m]), total: topLineGap, style: "net",
    note: sectionGaps.length ? `The gap sits in ${sectionGaps.map((g) => `${g.label} (${money(g.gap)})`).join(" and ")}: that section row's formula does not reach every line beneath it.` : "No gap: every section row reaches all of its lines." },
  { label: "Expenses, the sheet's row", cells: Q4.top.expenses.cells, total: Q4.top.expenses.total, style: "total" },
  { label: "Category lumps and lines, added", cells: Q4.expenseSum.cells, total: Q4.expenseSum.total },
  { label: "Elements less the Expenses row", cells: Q4.expenseSum.cells.map((v, m) => v - Q4.top.expenses.cells[m]), total: expenseGap, style: "net" },
];

const revenueRows: DocRow[] = [
  ...Q4.sections.filter((s) => s.children && s.children.length).map((s) => ({ label: s.label, cells: s.cells, total: s.total, children: s.children, style: "indent" as const,
    note: Math.abs(q4(s.linesSum) - s.total) > 0.5 ? `This section row carries ${money(s.total)} while its lines add to ${money(q4(s.linesSum))}: the row's formula does not reach every line beneath it.` : undefined })),
  { label: "Base Revenue", cells: Q4.top.base.cells, total: Q4.top.base.total, style: "total", note: "The sheet's own row for these months, the sum of the six practice-area rows." },
];

const expenseRows: DocRow[] = [
  ...Q4.expenseCats.map((c) => ({ ...c, style: "indent" as const })),
  { label: "Expenses", cells: Q4.top.expenses.cells, total: Q4.top.expenses.total, style: "total", note: "The sheet's own row for these months, the category lumps and their lines added together." },
];

const assumptionItems = Q4.purple.map((p) => `${p.label}${p.sub ? ` (${p.sub})` : ""}, ${p.section}: ${whole(p.total)} across ${Q4.months.filter((_, m) => Math.abs(p.cells[m]) > 0.5).join(", ")}.`);

export const FINANCE_REVIEW_PAGES: DocPage[] = [
  {
    slug: "cover",
    ref: "",
    title: "Company Finance Review",
    kicker: "Third Horizon · Working Review · October 2026",
    cover: {
      heading: "Company Finance Review",
      sub: "A tool that assesses short term cash needs and the short/medium term decisions required for business structure. This includes a tactical sequencing of what needs to happen to execute both strategies.",
      note: "Prepared for David Smith",
      date: `NetSuite read ${NS.readOn}`,
    },
    blocks: [{ kind: "contents" }],
  },
  {
    slug: "income-statement-jan-sep",
    ref: "1",
    title: "January through September, *as the books closed.*",
    kicker: "1 · The Income Statement",
    blocks: [
      {
        kind: "lead",
        bold: "The income statement for January through September 2026 is the first exhibit, pulled straight from NetSuite.",
        text: `It comes over the NetSuite API on ${NS.readOn}: every profit and loss account with activity in the nine accounting periods, posting transactions only, on the accounting-period basis the books close on. All nine periods are closed. The table is laid out as NetSuite lays it out, parents opening to their accounts; click any total to read how it is built and where it differs from the printed report.`,
      },
      {
        kind: "stats",
        items: [
          { k: "Total Income · Jan to Sep", v: whole(T.income.total), sub: "every income account the API returns; the report adds Ticket Sales" },
          { k: "Total Expense · Jan to Sep", v: whole(T.expense.total), sub: `${NS.accountCount} accounts with activity across income and expense` },
          { k: "Net Ordinary Income", v: whole(T.ordinary.total), tone: T.ordinary.total < 0 ? "neg" : "pos", sub: `${positives.length} of 9 months positive: ${positives.join(", ")}` },
          { k: "Net Income", v: whole(T.net.total), tone: T.net.total < 0 ? "neg" : "pos", sub: `after ${whole(T.otherIncome.total)} of other income and ${whole(T.otherExpense.total)} of other expense` },
        ],
      },
      { kind: "h2", text: "The Statement" },
      {
        kind: "para",
        text: `Nine columns, one per accounting period, and a Jan to Sep column that sums them. Revenue sits in three families: *recurring* (${whole(794351.8)}, the non-subscription retainers plus DaaS subscriptions and member dues), *non-recurring* (${whole(5190364.88)}, fixed fee and time and materials) and *other* (${whole(5400.91)}). Payroll is ${whole(4163972.18)} of the ${whole(T.expense.total)} of expense; dues and subscriptions, carried mostly by data services, are the next ${whole(1168632.18)}.`,
      },
      {
        kind: "table",
        id: "ns-income-statement",
        caption: "Income Statement · 2026 · January to September · Dollars · Accounting-Period Basis",
        columns: NS.months,
        columnSubs: NS.closed.map((c) => (c ? "Closed" : "Open")),
        totalLabel: "Jan to Sep",
        rows,
        expandHint: "Parents open to their accounts. Totals open to their reading.",
        source: `Source: NetSuite, SuiteQL over the REST API, read ${NS.readOn}. Posting transactions in the nine 2026 accounting periods January through September, every account of type Income, Other Income, Expense, Cost of Goods Sold and Other Expense. Labels are NetSuite's account numbers and names. Closed is the period's own flag.`,
      },
      {
        kind: "chart",
        id: "ns-monthly",
        title: "Total Income Against Total Expense, by Period",
        categories: NS.months,
        bars: [
          { name: "Total Income", values: T.income.cells, tone: "accent" },
          { name: "Total Expense", values: T.expense.cells, tone: "mid" },
        ],
        line: { name: "Net Income", values: T.net.cells },
        caption: "Dollars by accounting period from the same rows as the table; the net income strip beneath the periods is the bottom line after other income and expense. Hover a period to read its figures.",
      },
      { kind: "h2", text: "Below the Line" },
      {
        kind: "para",
        text: `Other income of ${whole(T.otherIncome.total)} and other expense of ${whole(T.otherExpense.total)} turn the operating result of ${whole(T.ordinary.total)} into net income of ${whole(T.net.total)}. The other expense is interest paid (${whole(57150.06)}), interest accrued (${whole(936.14)}), factoring fees (${whole(53138.1)}) and other expense (${whole(130922.51)}). ${netPositives.length} of the nine months close positive at the bottom line: ${netPositives.join(", ")}.`,
      },
      { kind: "h2", text: "Against the Pro Forma" },
      {
        kind: "stats",
        items: [
          { k: "Pro Forma Base Revenue", v: whole(PF.base.total!), sub: `${whole(pfRevenueOver)} above the books' Total Income` },
          { k: "Pro Forma Expenses", v: whole(PF.expenses.total!), sub: `${whole(pfExpenseUnder)} below the books' Total Expense` },
          { k: "Pro Forma Net Income", v: whole(PF.net.total!), tone: PF.net.total! < 0 ? "neg" : "pos", sub: `against ${whole(T.ordinary.total)} on the books' operating line` },
        ],
      },
      {
        kind: "para",
        text: `The live pro forma in the Finance Binder (2025 Pro Forma.xlsx, sheet PRO FORMA 2026, read ${PF.readOn}) carries the same nine months as Base Revenue of ${whole(PF.base.total!)}, Expenses of ${whole(PF.expenses.total!)} and Net Income of ${whole(PF.net.total!)}. Its Base Revenue row is typed values that run ${whole(pfRevenueOver)} above the books, while its six practice-area rows sum to ${whole(PF.sectionsTotal)}, ${whole(T.income.total - PF.sectionsTotal)} under the books' Total Income. Its Expenses line sits ${whole(pfExpenseUnder)} under the books, and it carries nothing below the operating line.`,
      },
      {
        kind: "callout",
        eyebrow: "For the Review",
        text: `Which revenue figure the review carries forward: the books' Total Income of ${whole(T.income.total)}, which the pro forma's practice-area lines track, or the pro forma's Base Revenue row, which runs ${whole(pfRevenueOver)} above it for the nine months.`,
      },
      {
        kind: "source",
        text: `Tie-out to David's NetSuite income statement (Jan to Sep aggregate, 10/25): 23 of the 26 account lines on the report tie to the penny. Three do not, all consistent with transaction types the integration role cannot read (it sees ${roleTypes}): 43400 - Ticket Sales (${money(SCREEN.ticketSales)} on the report, no visible lines here), 61400 - Cell Phone (${money(SCREEN.cellPhone)} on the report, ${money(17307.22)} here) and 61800 - Wellbeing Benefit (${money(SCREEN.wellbeing)} on the report, ${money(18141.41)} here). The report's Total Income is ${money(SCREEN.totalIncome)}; this page's is ${money(T.income.total)}.`,
      },
    ],
  },
  {
    slug: "estimate-oct-dec",
    ref: "2",
    title: "October through December, *what we think we know.*",
    kicker: "2 · The Estimate",
    blocks: [
      {
        kind: "lead",
        bold: "January through September is locked; October through December is an estimate built from the pro forma's own elements.",
        text: `The closed months are the books from page 1. The estimate months are the live pro forma as you saved it on ${Q4.savedAt} (version ${Q4.version}): its practice-area rows and the client lines beneath them for revenue, its category lumps and their lines for expense. Revenue lines in purple on the sheet are flagged as assumptions and listed as the work to do. The sheet's typed top lines are checked against what its lines add to, so what this tool carries forward is known to be, or not be, what the sheet shows.`,
      },
      {
        kind: "stats",
        items: [
          { k: "Revenue · Jan to Sep · Closed", v: whole(T.income.total), sub: "the books' Total Income" },
          { k: "Revenue · Oct to Dec · Estimate", v: whole(Q4.sectionsSum.total), sub: `the sheet's practice-area rows; ${whole(Q4.purpleTotal)} of it flagged as assumptions` },
          { k: "Revenue · FY 2026 · Outlook", v: whole(fyRevenue), sub: "closed plus estimate" },
          { k: "Net Ordinary Income · FY 2026", v: whole(fyOrdinary), tone: fyOrdinary < 0 ? "neg" : "pos", sub: `${whole(T.ordinary.total)} closed, ${whole(Q4.top.net.total)} estimated` },
        ],
      },
      {
        kind: "stats",
        items: [
          { k: "Expenses · Jan to Sep · Closed", v: whole(T.expense.total), sub: "the books' Total Expense" },
          { k: "Expenses · Oct to Dec · Estimate", v: whole(Q4.expenseSum.total), sub: "the sheet's category lumps and lines" },
          { k: "Expenses · FY 2026 · Outlook", v: whole(fyExpense), sub: "closed plus estimate" },
          { k: "Net Income · FY 2026", v: whole(fyNet), tone: fyNet < 0 ? "neg" : "pos", sub: `after ${whole(belowLine)} below the line in the closed months` },
        ],
      },
      { kind: "h2", text: "Locked and Estimated" },
      {
        kind: "para",
        text: `The closed column is the books on the accounting-period basis, by account. The estimate columns are the sheet, by practice area and by expense category. The two do not share a structure, so the year table opens the estimate months to the sheet's elements and leaves the closed column to the books' totals. One basis difference to hold in mind: the sheet keeps *Interest Paid* inside Expenses (${whole(q4(Q4.expenseCats.find((c) => c.label === "Interest Paid")?.cells ?? [0]))} for the quarter), where the books carry interest below the operating line.`,
      },
      {
        kind: "table",
        id: "year-2026",
        caption: "2026 · January to September Closed, October to December Estimated · Dollars",
        columns: ["Jan to Sep", ...Q4.months, "Oct to Dec"],
        columnSubs: ["Closed · Books", "Estimate", "Estimate", "Estimate", "Estimate · Sheet"],
        totalLabel: "FY 2026",
        rows: yearRows,
        expandHint: "Revenue opens to the practice areas, and each practice area to its client lines with their Project IDs; Expenses opens to the sheet's categories. The closed column stays with the books' totals. Totals open to their reading.",
        source: `Closed: NetSuite over SuiteQL, read ${NS.readOn}, page 1. Estimate: SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, columns Oct to Dec, version ${Q4.version} saved ${Q4.savedAt}, read ${Q4.readOn}.`,
      },
      {
        kind: "chart",
        id: "year-monthly",
        title: "Revenue Against Expenses, Closed and Estimated, by Month",
        categories: YEAR_MONTHS,
        bars: [
          { name: "Revenue", values: yearRevenue, tone: "accent" },
          { name: "Expenses", values: yearExpense, tone: "mid" },
        ],
        line: { name: "Net Ordinary", values: yearOrdinary },
        estimateFrom: NS.months.length,
        estimateLabel: "Estimate, the sheet",
        caption: "Closed months are solid, from the books; estimate months are outlined, from the sheet. The strip beneath is revenue less expenses on each side. Hover a month to read its figures.",
      },
      { kind: "h2", text: "The Top Lines Against the Lines" },
      {
        kind: "para",
        text: topLineGap === 0 && expenseGap === 0
          ? `For October through December the sheet's top lines are exactly what the tool carries: Base Revenue and Forecasted Revenue equal the practice-area rows and their lines to the dollar, and Expenses equals the category lumps and lines to the dollar.`
          : `For October through December the sheet's Base Revenue row equals its six practice-area rows to the dollar, and Forecasted Revenue equals Base Revenue (no pipeline is added in these months). Its Expenses row equals the category lumps and their lines to the dollar${expenseGap === 0 ? "" : ` (off by ${money(expenseGap)})`}. The one place the sheet's top line is not what its lines say is revenue one level down: the client lines beneath the practice-area rows add to ${whole(linesTotal)}, ${whole(topLineGap)} more than the Base Revenue row, because ${sectionGaps.map((g) => `the ${g.label} row carries ${whole(g.gap)} less than its lines`).join(" and ")}. If the tool builds the estimate from the lines, that is the difference it will carry.`,
      },
      {
        kind: "table",
        id: "top-lines",
        caption: "October to December · The Sheet's Typed Rows Against Its Elements · Dollars",
        columns: Q4.months,
        columnSubs: ["Estimate", "Estimate", "Estimate"],
        totalLabel: "Oct to Dec",
        rows: topLineRows,
        expandHint: "The gap row opens to where the gap sits.",
      },
      { kind: "h2", text: "Revenue, October through December" },
      {
        kind: "para",
        text: `The six practice areas and every client line with a figure in the quarter (${Q4.lineCount} lines). Lines in purple on the sheet carry the Assumption flag; one line is highlighted yellow on the sheet and is flagged as such. Together the four purple lines are ${whole(Q4.purpleTotal)} of the quarter's ${whole(Q4.sectionsSum.total)}.`,
      },
      {
        kind: "table",
        id: "q4-revenue",
        caption: "Revenue Estimate · October to December · By Practice Area and Client Line · Dollars",
        columns: Q4.months,
        columnSubs: ["Estimate", "Estimate", "Estimate"],
        totalLabel: "Oct to Dec",
        rows: revenueRows,
        expandHint: "Practice areas open to their client lines; flags are the sheet's own colors.",
      },
      {
        kind: "callout",
        eyebrow: "Assumptions to Work",
        text: `The purple lines on the sheet, ${whole(Q4.purpleTotal)} across the quarter. Each needs its basis set down before it stands as more than an assumption.`,
      },
      { kind: "list", items: assumptionItems },
      {
        kind: "para",
        text: `Highlighted yellow on the sheet, not purple: ${Q4.yellow.map((y) => `${y.label} (${y.sub ?? "no contract id"}), ${y.section}, ${whole(y.total)} across the quarter`).join("; ")}. The sheet does not say what the yellow means, so it is shown with its own flag and left to you.`,
      },
      { kind: "h2", text: "Expenses, October through December" },
      {
        kind: "para",
        text: `The sheet's expense categories, each opening to its lump and its lines where it has both (Contractors, Payroll Expenses, Business Development, Rent & Lease and Project Starset carry lines; the rest are a single figure a month). Payroll Expenses is ${whole(Q4.expenseCats.find((c) => c.label === "Payroll Expenses")?.total ?? 0)} of the quarter's ${whole(Q4.expenseSum.total)}; Project Starset ${whole(Q4.expenseCats.find((c) => c.label === "Project Starset")?.total ?? 0)}.`,
      },
      {
        kind: "table",
        id: "q4-expense",
        caption: "Expense Estimate · October to December · By Category · Dollars",
        columns: Q4.months,
        columnSubs: ["Estimate", "Estimate", "Estimate"],
        totalLabel: "Oct to Dec",
        rows: expenseRows,
        expandHint: "Categories open to their lump and their lines.",
      },
      {
        kind: "source",
        text: `Estimate source: SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, 2026 block, columns Oct to Dec, version ${Q4.version} saved ${Q4.savedAt}, read ${Q4.readOn}. Labels are the sheet's own; Assumption marks a revenue line set in purple on the sheet; Yellow in the sheet marks a line with a yellow fill. Page 1's pro forma comparison reads the earlier save (version 4625) and is left in place.`,
      },
    ],
  },
];
