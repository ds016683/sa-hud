// =============================================================================
// COMPANY FINANCE REVIEW (/finance-review) — David's working surface for the
// finance review, built 10/25 as the first document on the proposals chassis:
// long-form pages on the AMA proposal's frame (the contents rail, the canon),
// prose-anchored, with the books' tables and charts set inline and a Next at
// the foot of every page. Pages arrive one at a time on David's word; page 2
// is pending.
//
// Data (10/25, second cut): content/finance-review-ns-data.ts, the NetSuite
// income statement for the nine 2026 periods January through September,
// pulled over SuiteQL (posting transactions, accounting-period basis) and laid
// out as NetSuite lays it out. The pro forma (content/finance-review-data.ts,
// the live Finance Binder sheet) stays for the comparison at the foot of the
// page. Labels are the books' own; nothing is hand-typed.
// =============================================================================
import type { DocPage, DocRow } from "./doc";
import { NS } from "./finance-review-ns-data";
import { PF } from "./finance-review-data";

const money = (x: number) => (x < 0 ? `($${Math.abs(x).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })})` : `$${x.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
const whole = (x: number) => (x < 0 ? `($${Math.abs(Math.round(x)).toLocaleString("en-US")})` : `$${Math.round(x).toLocaleString("en-US")}`);
const T = NS.totals;

// David's NetSuite income statement screenshot (Jan to Sep aggregate, 10/25): the
// three lines the API role cannot see, and the report's revenue total.
const SCREEN = { totalIncome: 5991567.5, ticketSales: 1449.91, cellPhone: 17107.23, wellbeing: 18121.76 };
const roleTypes = "checks, credit memos, invoices, journal entries and vendor bills";

const rows: DocRow[] = [
  ...NS.income,
  { label: "Total - Income", cells: T.income.cells, total: T.income.total, style: "total",
    note: `Every income account with activity in the nine closed periods, as the API returns it. The NetSuite income statement report shows ${money(SCREEN.totalIncome)}, which is this figure plus 43400 - Ticket Sales at ${money(SCREEN.ticketSales)}: that account has no transaction lines visible to the integration role, which reads ${roleTypes} only.` },
  ...NS.expense,
  { label: "Total - Expense", cells: T.expense.cells, total: T.expense.total, style: "total",
    note: `Every expense account with activity, parents opening to their accounts. Two lines run above the report by small amounts: 61400 - Cell Phone (${money(17307.22)} here against ${money(SCREEN.cellPhone)} on the report) and 61800 - Wellbeing Benefit (${money(18141.41)} against ${money(SCREEN.wellbeing)}), the shape of vendor credits the integration role cannot read. The other ${26 - 3} lines on the report tie to the penny.` },
  { label: "Net Ordinary Income", cells: T.ordinary.cells, total: T.ordinary.total, style: "net",
    note: "Total Income less Total Expense, month by month: the operating line, before other income and other expense." },
  ...NS.otherIncome,
  ...NS.otherExpense,
  { label: "Net Income", cells: T.net.cells, total: T.net.total, style: "final",
    note: "Net Ordinary Income plus other income, less other expense (interest paid and accrued, factoring fees, other expense)." },
];

const positives = NS.months.filter((_, m) => T.ordinary.cells[m] > 0);
const netPositives = NS.months.filter((_, m) => T.net.cells[m] > 0);
const pfRevenueOver = PF.base.total! - T.income.total;
const pfExpenseUnder = T.expense.total - PF.expenses.total!;

export const FINANCE_REVIEW_PAGES: DocPage[] = [
  {
    slug: "cover",
    ref: "",
    title: "Company Finance Review",
    kicker: "Third Horizon · Working Review · October 2026",
    cover: {
      heading: "Company Finance Review",
      sub: "A tool that assesses short term cash needs and the short/medium term decisions required for business structure. This includes a tactical sequencing of what needs to happen to execute both strategies.",
      note: "Prepared for David Smith",
      date: `NetSuite read ${NS.readOn}`,
    },
    blocks: [{ kind: "contents" }],
  },
  {
    slug: "income-statement-jan-sep",
    ref: "1",
    title: "January through September, *as the books closed.*",
    kicker: "1 · The Income Statement",
    blocks: [
      {
        kind: "lead",
        bold: "The income statement for January through September 2026 is the first exhibit, pulled straight from NetSuite.",
        text: `It comes over the NetSuite API on ${NS.readOn}: every profit and loss account with activity in the nine accounting periods, posting transactions only, on the accounting-period basis the books close on. All nine periods are closed. The table is laid out as NetSuite lays it out, parents opening to their accounts; click any total to read how it is built and where it differs from the printed report.`,
      },
      {
        kind: "stats",
        items: [
          { k: "Total Income · Jan to Sep", v: whole(T.income.total), sub: "every income account the API returns; the report adds Ticket Sales" },
          { k: "Total Expense · Jan to Sep", v: whole(T.expense.total), sub: `${NS.accountCount} accounts with activity across income and expense` },
          { k: "Net Ordinary Income", v: whole(T.ordinary.total), tone: T.ordinary.total < 0 ? "neg" : "pos", sub: `${positives.length} of 9 months positive: ${positives.join(", ")}` },
          { k: "Net Income", v: whole(T.net.total), tone: T.net.total < 0 ? "neg" : "pos", sub: `after ${whole(T.otherIncome.total)} of other income and ${whole(T.otherExpense.total)} of other expense` },
        ],
      },
      { kind: "h2", text: "The Statement" },
      {
        kind: "para",
        text: `Nine columns, one per accounting period, and a Jan to Sep column that sums them. Revenue sits in three families: *recurring* (${whole(794351.8)}, the non-subscription retainers plus DaaS subscriptions and member dues), *non-recurring* (${whole(5190364.88)}, fixed fee and time and materials) and *other* (${whole(5400.91)}). Payroll is ${whole(4163972.18)} of the ${whole(T.expense.total)} of expense; dues and subscriptions, carried mostly by data services, are the next ${whole(1168632.18)}.`,
      },
      {
        kind: "table",
        id: "ns-income-statement",
        caption: "Income Statement · 2026 · January to September · Dollars · Accounting-Period Basis",
        columns: NS.months,
        columnSubs: NS.closed.map((c) => (c ? "Closed" : "Open")),
        totalLabel: "Jan to Sep",
        rows,
        expandHint: "Parents open to their accounts. Totals open to their reading.",
        source: `Source: NetSuite, SuiteQL over the REST API, read ${NS.readOn}. Posting transactions in the nine 2026 accounting periods January through September, every account of type Income, Other Income, Expense, Cost of Goods Sold and Other Expense. Labels are NetSuite's account numbers and names. Closed is the period's own flag.`,
      },
      {
        kind: "chart",
        id: "ns-monthly",
        title: "Total Income Against Total Expense, by Period",
        categories: NS.months,
        bars: [
          { name: "Total Income", values: T.income.cells, tone: "accent" },
          { name: "Total Expense", values: T.expense.cells, tone: "mid" },
        ],
        line: { name: "Net Income", values: T.net.cells },
        caption: "Dollars by accounting period from the same rows as the table; the net income strip beneath the periods is the bottom line after other income and expense. Hover a period to read its figures.",
      },
      { kind: "h2", text: "Below the Line" },
      {
        kind: "para",
        text: `Other income of ${whole(T.otherIncome.total)} and other expense of ${whole(T.otherExpense.total)} turn the operating result of ${whole(T.ordinary.total)} into net income of ${whole(T.net.total)}. The other expense is interest paid (${whole(57150.06)}), interest accrued (${whole(936.14)}), factoring fees (${whole(53138.1)}) and other expense (${whole(130922.51)}). ${netPositives.length} of the nine months close positive at the bottom line: ${netPositives.join(", ")}.`,
      },
      { kind: "h2", text: "Against the Pro Forma" },
      {
        kind: "stats",
        items: [
          { k: "Pro Forma Base Revenue", v: whole(PF.base.total!), sub: `${whole(pfRevenueOver)} above the books' Total Income` },
          { k: "Pro Forma Expenses", v: whole(PF.expenses.total!), sub: `${whole(pfExpenseUnder)} below the books' Total Expense` },
          { k: "Pro Forma Net Income", v: whole(PF.net.total!), tone: PF.net.total! < 0 ? "neg" : "pos", sub: `against ${whole(T.ordinary.total)} on the books' operating line` },
        ],
      },
      {
        kind: "para",
        text: `The live pro forma in the Finance Binder (2025 Pro Forma.xlsx, sheet PRO FORMA 2026, read ${PF.readOn}) carries the same nine months as Base Revenue of ${whole(PF.base.total!)}, Expenses of ${whole(PF.expenses.total!)} and Net Income of ${whole(PF.net.total!)}. Its Base Revenue row is typed values that run ${whole(pfRevenueOver)} above the books, while its six practice-area rows sum to ${whole(PF.sectionsTotal)}, ${whole(T.income.total - PF.sectionsTotal)} under the books' Total Income. Its Expenses line sits ${whole(pfExpenseUnder)} under the books, and it carries nothing below the operating line.`,
      },
      {
        kind: "callout",
        eyebrow: "For the Review",
        text: `Which revenue figure the review carries forward: the books' Total Income of ${whole(T.income.total)}, which the pro forma's practice-area lines track, or the pro forma's Base Revenue row, which runs ${whole(pfRevenueOver)} above it for the nine months.`,
      },
      {
        kind: "source",
        text: `Tie-out to David's NetSuite income statement (Jan to Sep aggregate, 10/25): 23 of the 26 account lines on the report tie to the penny. Three do not, all consistent with transaction types the integration role cannot read (it sees ${roleTypes}): 43400 - Ticket Sales (${money(SCREEN.ticketSales)} on the report, no visible lines here), 61400 - Cell Phone (${money(SCREEN.cellPhone)} on the report, ${money(17307.22)} here) and 61800 - Wellbeing Benefit (${money(SCREEN.wellbeing)} on the report, ${money(18141.41)} here). The report's Total Income is ${money(SCREEN.totalIncome)}; this page's is ${money(T.income.total)}.`,
      },
    ],
  },
];
