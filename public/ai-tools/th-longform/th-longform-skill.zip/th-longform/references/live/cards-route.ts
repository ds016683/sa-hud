import { NextResponse, type NextRequest } from "next/server";
import { cookies } from "next/headers";
import { cookieName, verifyGateToken, PRIVATE_CACHE_CONTROL } from "@/lib/gate";
import { findDocument, documentCode } from "@/lib/documents";

// The purple cards' live store (David 11/3): assignments, the one-line status and the updates typed into the
// card modal live in a Ledger artifact, `<project>/artifacts/<store>.json` in the project-files bucket, the same
// place the HUD keeps its artifacts, so Lumen reads the updates and writes the status. Readers must hold the
// document's session cookie. The Ledger URL and key come from the environment (LEDGER_URL, LEDGER_SERVICE_KEY);
// without them the route answers 503 and the reader shows the content seed.

export const dynamic = "force-dynamic";

const SLUG = "finance-review";
const PROJECT = "024c66f7-17a0-47f6-b9c1-65632c789d85"; // Finance.Review in the Ledger
const BUCKET = "project-files";
const ID = /^[a-z0-9][a-z0-9-]{0,60}$/;

type Update = { at: string; by?: string; text: string };
type Item = { title?: string; owner?: string; leads?: string[]; status?: string; updates?: Update[]; updated?: string };
type Store = { kind: string; title: string; project: string; updated: string; items: Record<string, Item> };

function ledger() {
  const url = process.env.LEDGER_URL, key = process.env.LEDGER_SERVICE_KEY;
  return url && key ? { url: url.replace(/\/$/, ""), key } : null;
}
async function authorized(): Promise<boolean> {
  const document = findDocument(SLUG);
  if (!document) return false;
  const token = (await cookies()).get(cookieName(SLUG))?.value;
  return verifyGateToken(SLUG, documentCode(document), token);
}
const objectPath = (store: string) => `${PROJECT}/artifacts/${store}.json`;

async function readStore(store: string): Promise<Store> {
  const l = ledger()!;
  const res = await fetch(`${l.url}/storage/v1/object/${BUCKET}/${objectPath(store)}`, { headers: { apikey: l.key, Authorization: `Bearer ${l.key}` }, cache: "no-store" });
  if (res.status === 400 || res.status === 404) return { kind: "purple-pipeline", title: "Landing The Purple Items", project: PROJECT, updated: "", items: {} };
  if (!res.ok) throw new Error(`store read ${res.status}`);
  const j = (await res.json()) as Partial<Store>;
  return { kind: j.kind ?? "purple-pipeline", title: j.title ?? "Landing The Purple Items", project: PROJECT, updated: j.updated ?? "", items: j.items ?? {} };
}
async function writeStore(store: string, data: Store): Promise<void> {
  const l = ledger()!;
  const res = await fetch(`${l.url}/storage/v1/object/${BUCKET}/${objectPath(store)}`, {
    method: "POST",
    headers: { apikey: l.key, Authorization: `Bearer ${l.key}`, "Content-Type": "application/json", "x-upsert": "true" },
    body: JSON.stringify(data, null, 1),
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`store write ${res.status}`);
}
const reply = (body: unknown, status = 200) => {
  const res = NextResponse.json(body, { status });
  res.headers.set("Cache-Control", PRIVATE_CACHE_CONTROL);
  return res;
};

export async function GET(request: NextRequest) {
  if (!(await authorized())) return reply({ error: "unauthorized" }, 401);
  if (!ledger()) return reply({ error: "store not configured", items: {} }, 503);
  const store = request.nextUrl.searchParams.get("store") ?? "";
  if (!ID.test(store)) return reply({ error: "bad store" }, 400);
  try {
    const data = await readStore(store);
    return reply({ items: data.items, updated: data.updated });
  } catch (e) {
    return reply({ error: e instanceof Error ? e.message : String(e) }, 502);
  }
}

export async function POST(request: NextRequest) {
  if (!(await authorized())) return reply({ error: "unauthorized" }, 401);
  if (!ledger()) return reply({ error: "store not configured" }, 503);
  let body: { store?: string; key?: string; title?: string; owner?: string; leads?: string[]; status?: string; update?: string };
  try { body = await request.json(); } catch { return reply({ error: "bad json" }, 400); }
  const store = String(body.store ?? ""), key = String(body.key ?? "");
  if (!ID.test(store) || !ID.test(key)) return reply({ error: "bad id" }, 400);
  const clean = (x: unknown, max: number) => (typeof x === "string" ? x.trim().slice(0, max) : "");
  const keys = (x: unknown) => (Array.isArray(x) ? x.map((k) => clean(k, 40)).filter((k) => ID.test(k)).slice(0, 3) : undefined);
  try {
    const data = await readStore(store);
    const now = new Date().toISOString();
    const cur: Item = data.items[key] ?? {};
    const next: Item = { ...cur, updated: now };
    if (body.title) next.title = clean(body.title, 160);
    if ("owner" in body) { const o = clean(body.owner, 40); next.owner = o && ID.test(o) ? o : undefined; }
    if ("leads" in body) next.leads = keys(body.leads) ?? [];
    if ("status" in body) next.status = clean(body.status, 160) || undefined;
    const text = clean(body.update, 2000);
    if (text) next.updates = [...(cur.updates ?? []), { at: now, by: "Reader", text }].slice(-50);
    data.items[key] = next;
    data.updated = now;
    await writeStore(store, data);
    return reply({ items: data.items, updated: data.updated });
  } catch (e) {
    return reply({ error: e instanceof Error ? e.message : String(e) }, 502);
  }
}
