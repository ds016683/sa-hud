// The live pro forma (10/26): the October to December estimate and the cash
// worksheet read straight from the SharePoint workbook, so a change saved in
// SharePoint reaches the page within a minute. One parser, used three ways:
// at request time (an eTag check every 60 seconds, the workbook re-read only
// when it changed), by the one-minute refresh route the cron calls, and by the
// snapshot script that writes the committed fallback. Server only.
import ExcelJS from "exceljs";
import type { DocRow } from "@/content/doc";

export type LiveTotal = { cells: number[]; total: number };
export type LiveRow = { label: string; sub?: string; flag?: string; cells: number[]; total: number; children?: LiveRow[]; /** Per period, true where the sheet shows the cell in purple (an item not yet confirmed). */ purple?: boolean[] };
/** A Cash In line with purple in the window: `cells` carries the purple amounts by period (zero elsewhere); `whole` when the line is purple in full. */
export type CashPurpleItem = { label: string; sub?: string; whole: boolean; cells: number[]; total: number };

export type Q4Live = {
  months: string[];
  top: { base: LiveTotal; forecasted: LiveTotal; expenses: LiveTotal; net: LiveTotal };
  sections: (LiveRow & { linesSum: number[] })[];
  sectionsSum: LiveTotal;
  expenseCats: LiveRow[];
  expenseSum: LiveTotal;
  purple: (LiveRow & { section: string })[];
  yellow: (LiveRow & { section: string })[];
  purpleTotal: number;
  yellowTotal: number;
  lineCount: number;
};

export type CashLive = {
  /** Column labels, "Oct 31" style, dates repaired by position (the sheet's year labels drift). */
  periods: { label: string; year: number; iso: string }[];
  beginning: number[];
  cashIn: LiveRow;
  cashOut: LiveRow;
  balance: number[];
  lowest: { iso: string; label: string; value: number };
  /** The Cash In lines with purple in the window, read from the sheet on every refresh. */
  purple: CashPurpleItem[];
  purpleTotal: number;
};

export type LiveSource = { version: string | null; savedAt: string; savedBy: string; readAt: string; eTag: string; live: boolean };
export type FinanceLive = { source: LiveSource; q4: Q4Live; cash: CashLive; /** The 2027 block of the pro forma, the same shape as the October to December block. */ fy27: Q4Live };

const YELLOW = "FFFFFF00";

/* ---- "any purple" (David 10/26): a cell is purple when its font or its fill reads purple by hue, whatever the shade ----
   The color may be a direct ARGB (the sheet's FF7030A0), a theme color (resolved from the workbook's theme part) or a
   legacy indexed color. Hue 255 to 325 with some saturation and a readable lightness counts; blues, reds and pinks do not. */
const THEME_ORDER = ["lt1", "dk1", "lt2", "dk2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "hlink", "folHlink"];
const INDEXED = ["000000", "FFFFFF", "FF0000", "00FF00", "0000FF", "FFFF00", "FF00FF", "00FFFF", "000000", "FFFFFF", "FF0000", "00FF00", "0000FF", "FFFF00", "FF00FF", "00FFFF", "800000", "008000", "000080", "808000", "800080", "008080", "C0C0C0", "808080", "9999FF", "993366", "FFFFCC", "CCFFFF", "660066", "FF8080", "0066CC", "CCCCFF", "000080", "FF00FF", "FFFF00", "00FFFF", "800080", "800000", "008080", "0000FF", "00CCFF", "CCFFFF", "CCFFCC", "FFFF99", "99CCFF", "FF99CC", "CC99FF", "FFCC99", "3366FF", "33CCCC", "99CC00", "FFCC00", "FF9900", "FF6600", "666699", "969696", "003366", "339966", "003300", "333300", "993300", "993366", "333399", "333333"];
type ColorRef = { argb?: string; theme?: number; indexed?: number } | undefined;
function themeHexes(wb: ExcelJS.Workbook): string[] {
  const xml = (wb.model as unknown as { themes?: Record<string, string> }).themes?.theme1 ?? "";
  return THEME_ORDER.map((n) => { const m = xml.match(new RegExp(`<a:${n}>\\s*<a:(?:srgbClr|sysClr)[^>]*?(?:val|lastClr)="([0-9A-Fa-f]{6})"`)); return m ? m[1].toUpperCase() : ""; });
}
const hexOf = (c: ColorRef, themes: string[]): string =>
  !c ? "" : c.argb ? c.argb.slice(-6).toUpperCase() : typeof c.theme === "number" ? themes[c.theme] ?? "" : typeof c.indexed === "number" ? INDEXED[c.indexed] ?? "" : "";
export function isPurpleHex(hex: string): boolean {
  if (!/^[0-9A-F]{6}$/i.test(hex)) return false;
  const r = parseInt(hex.slice(0, 2), 16) / 255, g = parseInt(hex.slice(2, 4), 16) / 255, b = parseInt(hex.slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
  if (d < 0.04) return false;
  const l = (max + min) / 2;
  if (l < 0.1 || l > 0.95) return false;
  if (d / (1 - Math.abs(2 * l - 1)) < 0.12) return false;
  const h = ((max === r ? (g - b) / d : max === g ? (b - r) / d + 2 : (r - g) / d + 4) * 60 + 360) % 360;
  return h >= 255 && h <= 325;
}
const cellPurple = (c: Cell, themes: string[]): boolean => {
  if (isPurpleHex(hexOf(c.font?.color as ColorRef, themes))) return true;
  const f = c.fill as { type?: string; fgColor?: ColorRef } | undefined;
  return f?.type === "pattern" ? isPurpleHex(hexOf(f.fgColor, themes)) : false;
};
const r2 = (x: number) => Math.round(x * 100) / 100;
const sum = (a: number[]) => r2(a.reduce((s, v) => s + v, 0));

type Cell = ExcelJS.Cell;
const text = (c: Cell): string => {
  const v = c.value as unknown;
  if (v == null) return "";
  if (typeof v === "object" && v !== null && "richText" in (v as object)) return ((v as { richText: { text: string }[] }).richText || []).map((t) => t.text).join("");
  if (typeof v === "object" && v !== null && "result" in (v as object)) return String((v as { result: unknown }).result ?? "");
  return String(v);
};
const num = (c: Cell): number | null => {
  const v = c.value as unknown;
  if (v == null || v === "") return null;
  if (typeof v === "number") return v;
  if (typeof v === "object" && v !== null && "result" in (v as object)) { const r = (v as { result: unknown }).result; return typeof r === "number" ? r : null; }
  return null;
};
const bold = (c: Cell): boolean => !!c.font?.bold;
const fillColor = (c: Cell): string => { const f = c.fill as { type?: string; fgColor?: { argb?: string } } | undefined; return f?.type === "pattern" ? f.fgColor?.argb ?? "" : ""; };

/* ---- the pro forma's month blocks: October to December of 2026 (as build_pf_q4.py reads it) and all of 2027 ---- */
function proForma(wb: ExcelJS.Workbook): ExcelJS.Worksheet {
  const ws = wb.getWorksheet("PRO FORMA 2026");
  if (!ws) throw new Error("sheet PRO FORMA 2026 missing");
  return ws;
}
const janColumns = (ws: ExcelJS.Worksheet): number[] => { const jans: number[] = []; ws.getRow(4).eachCell((c, col) => { if (text(c).trim() === "Jan") jans.push(col); }); return jans; };
/** October to December: the second "Jan" on row 4 starts the 2026 block; Oct to Dec sit nine to eleven columns right of it. */
export function parseQ4(wb: ExcelJS.Workbook): Q4Live {
  const ws = proForma(wb), jans = janColumns(ws);
  if (jans.length < 2) throw new Error("2026 block not found");
  return parseBlock(wb, ws, jans[1] + 9, 3, "Oct,Nov,Dec", true);
}
/** 2027: the third "Jan" on row 4, twelve months. The sheet labels the block's total column "2026 Total"; the total here is computed. */
export function parseFY27(wb: ExcelJS.Workbook): Q4Live {
  const ws = proForma(wb), jans = janColumns(ws);
  if (jans.length < 3) throw new Error("2027 block not found");
  return parseBlock(wb, ws, jans[2], 12, "Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec", false);
}
function parseBlock(wb: ExcelJS.Workbook, ws: ExcelJS.Worksheet, FIRST: number, count: number, expect: string, keepZeroPurple: boolean): Q4Live {
  const themes = themeHexes(wb);
  const M = Array.from({ length: count }, (_, m) => m);
  const months = M.map((m) => text(ws.getCell(4, FIRST + m)).trim());
  if (months.join() !== expect) throw new Error(`months not where expected: ${months.join()}`);
  const cells = (r: number) => M.map((m) => r2(num(ws.getCell(r, FIRST + m)) ?? 0));
  const has = (r: number) => cells(r).some((v) => Math.abs(v) > 0.004);
  const label = (r: number) => text(ws.getCell(r, 2)).trim();
  const code = (r: number) => { const t = text(ws.getCell(r, 3)).trim(); return t || null; };
  const isBold = (r: number) => bold(ws.getCell(r, 2));
  const findRow = (want: string, from = 1, to = 400) => { for (let r = from; r <= to; r++) if (label(r).toLowerCase() === want) return r; throw new Error(`row ${want} missing`); };
  const BASE = findRow("base revenue"), FORE = findRow("forecasted revenue"), EXP = findRow("expenses"), NET = findRow("net income");

  // sections: the bold practice-area rows between Forecasted Revenue and Expenses, each running to the next bold header
  const heads: number[] = [];
  for (let r = FORE + 1; r < EXP; r++) if (isBold(r) && label(r) && !/total$/i.test(label(r))) heads.push(r);
  const sections: Q4Live["sections"] = []; const purple: Q4Live["purple"] = []; const yellow: Q4Live["yellow"] = [];
  heads.forEach((head, i) => {
    const next = i + 1 < heads.length ? heads[i + 1] : EXP;
    const kids: LiveRow[] = [];
    for (let r = head + 1; r < next; r++) {
      if (!label(r) || isBold(r)) continue;
      const isPurple = cellPurple(ws.getCell(r, 2), themes);
      if (!has(r) && !(isPurple && keepZeroPurple)) continue;
      const k: LiveRow = { label: label(r), sub: code(r) ?? "no Project Code", cells: cells(r), total: sum(cells(r)) };
      if (isPurple) k.flag = "Assumption";
      else if (fillColor(ws.getCell(r, 2)) === YELLOW) k.flag = "Yellow in the sheet";
      if (k.flag === "Assumption") purple.push({ ...k, section: label(head) });
      if (k.flag === "Yellow in the sheet") yellow.push({ ...k, section: label(head) });
      kids.push(k);
    }
    sections.push({ label: label(head), cells: cells(head), total: sum(cells(head)), children: kids, linesSum: M.map((m) => r2(kids.reduce((s, k) => s + k.cells[m], 0))) });
  });
  const sectionsSum = M.map((m) => r2(sections.reduce((s, x) => s + x.cells[m], 0)));

  // expenses: bold category rows between Expenses and Net Income with the lines beneath them, both additive
  const cats: LiveRow[] = [];
  let cur: { label: string; own: number[]; kids: LiveRow[] } | null = null;
  const flush = () => {
    if (!cur) return;
    const ownHas = cur.own.some((v) => Math.abs(v) > 0.004);
    if (!ownHas && !cur.kids.length) { cur = null; return; }
    const kids = [...cur.kids];
    if (ownHas && kids.length) kids.unshift({ label: cur.label, sub: "the lump", cells: cur.own, total: sum(cur.own) });
    const tot = M.map((m) => r2(cur!.own[m] + cur!.kids.reduce((s, k) => s + k.cells[m], 0)));
    const d: LiveRow = { label: cur.label, cells: tot, total: sum(tot) };
    if (kids.length) d.children = kids;
    cats.push(d); cur = null;
  };
  for (let r = EXP + 2; r < NET; r++) {
    if (!label(r)) continue;
    if (isBold(r)) { flush(); cur = { label: label(r), own: cells(r), kids: [] }; continue; }
    if (!cur || !has(r)) continue;
    const k: LiveRow = { label: label(r), cells: cells(r), total: sum(cells(r)) };
    if (code(r)) k.sub = code(r)!;
    cur.kids.push(k);
  }
  flush();
  const expenseSum = M.map((m) => r2(cats.reduce((s, c) => s + c.cells[m], 0)));
  const tot = (r: number): LiveTotal => ({ cells: cells(r), total: sum(cells(r)) });
  return {
    months, top: { base: tot(BASE), forecasted: tot(FORE), expenses: tot(EXP), net: tot(NET) },
    sections, sectionsSum: { cells: sectionsSum, total: sum(sectionsSum) },
    expenseCats: cats, expenseSum: { cells: expenseSum, total: sum(expenseSum) },
    purple, yellow, purpleTotal: sum(purple.map((p) => p.total)), yellowTotal: sum(yellow.map((y) => y.total)),
    lineCount: sections.reduce((s, x) => s + (x.children?.length ?? 0), 0),
  };
}

/* ---- the cash worksheet, from the current October 31 column through June 30, 2027 ---- */
const MONTH = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
export function parseCash(wb: ExcelJS.Workbook, startIso = "2026-10-31", endIso = "2027-06-30"): CashLive {
  const ws = wb.getWorksheet("Cash Tracker 2026");
  if (!ws) throw new Error("sheet Cash Tracker 2026 missing");
  const themes = themeHexes(wb);
  // the date header on row 1: years drift in the sheet, so repair them by position (a month smaller than the one before rolls the year)
  const row1 = ws.getRow(1);
  const cols: { col: number; month: number; day: number; year: number }[] = [];
  let year = 0, lastMonth = 0;
  row1.eachCell((c, col) => {
    const v = c.value as unknown;
    const d = v instanceof Date ? v : typeof v === "object" && v !== null && "result" in (v as object) && (v as { result: unknown }).result instanceof Date ? ((v as { result: Date }).result) : null;
    if (!d) return;
    const month = d.getUTCMonth() + 1, day = d.getUTCDate();
    if (!cols.length) year = d.getUTCFullYear();
    else if (month < lastMonth) year += 1;
    lastMonth = month;
    cols.push({ col, month, day, year });
  });
  const iso = (x: { year: number; month: number; day: number }) => `${x.year}-${String(x.month).padStart(2, "0")}-${String(x.day).padStart(2, "0")}`;
  const win = cols.filter((x) => iso(x) >= startIso && iso(x) <= endIso);
  if (!win.length) throw new Error("cash window not found");
  const periods = win.map((x) => ({ label: `${MONTH[x.month - 1]} ${x.day}`, year: x.year, iso: iso(x) }));
  const vals = (r: number) => win.map((x) => r2(num(ws.getCell(r, x.col)) ?? 0));
  const any = (r: number) => win.some((x) => num(ws.getCell(r, x.col)) != null);
  const label = (r: number) => text(ws.getCell(r, 1)).trim();
  const code = (r: number) => text(ws.getCell(r, 2)).trim();
  const isBold = (r: number) => bold(ws.getCell(r, 1)) || bold(ws.getCell(r, 2));
  const findRow = (want: string) => { for (let r = 1; r <= ws.rowCount; r++) if (label(r).toLowerCase() === want) return r; throw new Error(`cash row ${want} missing`); };
  const IN = findRow("cash in"), OUT = findRow("cash out"), BAL = findRow("anticipated 15-day balance");
  const beginning = vals(3);
  const inKids: LiveRow[] = [];
  const purpleItems: CashPurpleItem[] = [];
  for (let r = 4; r < IN; r++) {
    if (!label(r) || !any(r)) continue;
    const k: LiveRow = { label: label(r), sub: code(r) || "no Project Code", cells: vals(r), total: sum(vals(r)) };
    // any purple: a purple label or Project Code makes the whole line purple; otherwise each purple cell on its own
    const rowPurple = cellPurple(ws.getCell(r, 1), themes) || cellPurple(ws.getCell(r, 2), themes);
    const purple = win.map((x) => rowPurple || cellPurple(ws.getCell(r, x.col), themes));
    const purpleAmounts = k.cells.map((v, i) => (purple[i] ? v : 0));
    if (purpleAmounts.some((v) => Math.abs(v) > 0.004)) {
      const whole = k.cells.every((v, i) => purple[i] || Math.abs(v) < 0.005);
      k.purple = purple;
      k.flag = whole ? "Assumption" : "Assumption in part";
      purpleItems.push({ label: k.label, sub: k.sub, whole, cells: purpleAmounts, total: sum(purpleAmounts) });
    }
    inKids.push(k);
  }
  const outKids: LiveRow[] = [];
  let sec: LiveRow | null = null;
  for (let r = IN + 1; r < OUT; r++) {
    if (!label(r)) continue;
    if (isBold(r)) { if (sec) outKids.push(sec); sec = { label: label(r), cells: win.map(() => 0), total: 0, children: [] }; continue; }
    if (!sec || !any(r)) continue;
    const k: LiveRow = { label: label(r), cells: vals(r), total: sum(vals(r)) };
    sec.children!.push(k);
    sec.cells = sec.cells.map((v, i) => r2(v + k.cells[i])); sec.total = sum(sec.cells);
  }
  if (sec) outKids.push(sec);
  const cashIn: LiveRow = { label: label(IN), cells: vals(IN), total: sum(vals(IN)), children: inKids };
  const cashOut: LiveRow = { label: label(OUT), cells: vals(OUT), total: sum(vals(OUT)), children: outKids.filter((s) => s.children && s.children.length) };
  const balance = vals(BAL);
  let lo = 0; balance.forEach((v, i) => { if (v < balance[lo]) lo = i; });
  return { periods, beginning, cashIn, cashOut, balance, lowest: { iso: periods[lo].iso, label: `${periods[lo].label}, ${periods[lo].year}`, value: balance[lo] }, purple: purpleItems, purpleTotal: sum(purpleItems.map((p) => p.total)) };
}

export async function parseWorkbook(bytes: Buffer): Promise<{ q4: Q4Live; cash: CashLive; fy27: Q4Live }> {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(bytes as unknown as ArrayBuffer);
  return { q4: parseQ4(wb), cash: parseCash(wb), fy27: parseFY27(wb) };
}
