// The live pro forma (10/26): the October to December estimate and the cash
// worksheet read straight from the SharePoint workbook, so a change saved in
// SharePoint reaches the page within a minute. One parser, used three ways:
// at request time (an eTag check every 60 seconds, the workbook re-read only
// when it changed), by the one-minute refresh route the cron calls, and by the
// snapshot script that writes the committed fallback. Server only.
import ExcelJS from "exceljs";
import type { DocRow } from "@/content/doc";

export type LiveTotal = { cells: number[]; total: number };
export type LiveRow = { label: string; sub?: string; flag?: string; cells: number[]; total: number; children?: LiveRow[] };

export type Q4Live = {
  months: string[];
  top: { base: LiveTotal; forecasted: LiveTotal; expenses: LiveTotal; net: LiveTotal };
  sections: (LiveRow & { linesSum: number[] })[];
  sectionsSum: LiveTotal;
  expenseCats: LiveRow[];
  expenseSum: LiveTotal;
  purple: (LiveRow & { section: string })[];
  yellow: (LiveRow & { section: string })[];
  purpleTotal: number;
  yellowTotal: number;
  lineCount: number;
};

export type CashLive = {
  /** Column labels, "Oct 31" style, dates repaired by position (the sheet's year labels drift). */
  periods: { label: string; year: number; iso: string }[];
  beginning: number[];
  cashIn: LiveRow;
  cashOut: LiveRow;
  balance: number[];
  lowest: { iso: string; label: string; value: number };
};

export type LiveSource = { version: string | null; savedAt: string; savedBy: string; readAt: string; eTag: string; live: boolean };
export type FinanceLive = { source: LiveSource; q4: Q4Live; cash: CashLive };

const PURPLE = "FF7030A0", YELLOW = "FFFFFF00";
const r2 = (x: number) => Math.round(x * 100) / 100;
const sum = (a: number[]) => r2(a.reduce((s, v) => s + v, 0));

type Cell = ExcelJS.Cell;
const text = (c: Cell): string => {
  const v = c.value as unknown;
  if (v == null) return "";
  if (typeof v === "object" && v !== null && "richText" in (v as object)) return ((v as { richText: { text: string }[] }).richText || []).map((t) => t.text).join("");
  if (typeof v === "object" && v !== null && "result" in (v as object)) return String((v as { result: unknown }).result ?? "");
  return String(v);
};
const num = (c: Cell): number | null => {
  const v = c.value as unknown;
  if (v == null || v === "") return null;
  if (typeof v === "number") return v;
  if (typeof v === "object" && v !== null && "result" in (v as object)) { const r = (v as { result: unknown }).result; return typeof r === "number" ? r : null; }
  return null;
};
const bold = (c: Cell): boolean => !!c.font?.bold;
const fontColor = (c: Cell): string => (c.font?.color as { argb?: string } | undefined)?.argb ?? "";
const fillColor = (c: Cell): string => { const f = c.fill as { type?: string; fgColor?: { argb?: string } } | undefined; return f?.type === "pattern" ? f.fgColor?.argb ?? "" : ""; };

/* ---- the pro forma's October to December block, as build_pf_q4.py reads it ---- */
export function parseQ4(wb: ExcelJS.Workbook): Q4Live {
  const ws = wb.getWorksheet("PRO FORMA 2026");
  if (!ws) throw new Error("sheet PRO FORMA 2026 missing");
  // the 2026 block: the second "Jan" on row 4; Oct to Dec sit nine to eleven columns right of it
  const row4 = ws.getRow(4);
  const jans: number[] = [];
  row4.eachCell((c, col) => { if (text(c).trim() === "Jan") jans.push(col); });
  if (jans.length < 2) throw new Error("2026 block not found");
  const OCT = jans[1] + 9;
  const months = [0, 1, 2].map((m) => text(ws.getCell(4, OCT + m)).trim());
  if (months.join() !== "Oct,Nov,Dec") throw new Error(`Oct to Dec not where expected: ${months.join()}`);
  const cells = (r: number) => [0, 1, 2].map((m) => r2(num(ws.getCell(r, OCT + m)) ?? 0));
  const has = (r: number) => cells(r).some((v) => Math.abs(v) > 0.004);
  const label = (r: number) => text(ws.getCell(r, 2)).trim();
  const code = (r: number) => { const t = text(ws.getCell(r, 3)).trim(); return t || null; };
  const isBold = (r: number) => bold(ws.getCell(r, 2));
  const findRow = (want: string, from = 1, to = 400) => { for (let r = from; r <= to; r++) if (label(r).toLowerCase() === want) return r; throw new Error(`row ${want} missing`); };
  const BASE = findRow("base revenue"), FORE = findRow("forecasted revenue"), EXP = findRow("expenses"), NET = findRow("net income");

  // sections: the bold practice-area rows between Forecasted Revenue and Expenses, each running to the next bold header
  const heads: number[] = [];
  for (let r = FORE + 1; r < EXP; r++) if (isBold(r) && label(r) && !/total$/i.test(label(r))) heads.push(r);
  const sections: Q4Live["sections"] = []; const purple: Q4Live["purple"] = []; const yellow: Q4Live["yellow"] = [];
  heads.forEach((head, i) => {
    const next = i + 1 < heads.length ? heads[i + 1] : EXP;
    const kids: LiveRow[] = [];
    for (let r = head + 1; r < next; r++) {
      if (!label(r) || isBold(r)) continue;
      const isPurple = fontColor(ws.getCell(r, 2)) === PURPLE;
      if (!has(r) && !isPurple) continue;
      const k: LiveRow = { label: label(r), sub: code(r) ?? "no Project Code", cells: cells(r), total: sum(cells(r)) };
      if (isPurple) k.flag = "Assumption";
      else if (fillColor(ws.getCell(r, 2)) === YELLOW) k.flag = "Yellow in the sheet";
      if (k.flag === "Assumption") purple.push({ ...k, section: label(head) });
      if (k.flag === "Yellow in the sheet") yellow.push({ ...k, section: label(head) });
      kids.push(k);
    }
    sections.push({ label: label(head), cells: cells(head), total: sum(cells(head)), children: kids, linesSum: [0, 1, 2].map((m) => r2(kids.reduce((s, k) => s + k.cells[m], 0))) });
  });
  const sectionsSum = [0, 1, 2].map((m) => r2(sections.reduce((s, x) => s + x.cells[m], 0)));

  // expenses: bold category rows between Expenses and Net Income with the lines beneath them, both additive
  const cats: LiveRow[] = [];
  let cur: { label: string; own: number[]; kids: LiveRow[] } | null = null;
  const flush = () => {
    if (!cur) return;
    const ownHas = cur.own.some((v) => Math.abs(v) > 0.004);
    if (!ownHas && !cur.kids.length) { cur = null; return; }
    const kids = [...cur.kids];
    if (ownHas && kids.length) kids.unshift({ label: cur.label, sub: "the lump", cells: cur.own, total: sum(cur.own) });
    const tot = [0, 1, 2].map((m) => r2(cur!.own[m] + cur!.kids.reduce((s, k) => s + k.cells[m], 0)));
    const d: LiveRow = { label: cur.label, cells: tot, total: sum(tot) };
    if (kids.length) d.children = kids;
    cats.push(d); cur = null;
  };
  for (let r = EXP + 2; r < NET; r++) {
    if (!label(r)) continue;
    if (isBold(r)) { flush(); cur = { label: label(r), own: cells(r), kids: [] }; continue; }
    if (!cur || !has(r)) continue;
    const k: LiveRow = { label: label(r), cells: cells(r), total: sum(cells(r)) };
    if (code(r)) k.sub = code(r)!;
    cur.kids.push(k);
  }
  flush();
  const expenseSum = [0, 1, 2].map((m) => r2(cats.reduce((s, c) => s + c.cells[m], 0)));
  const tot = (r: number): LiveTotal => ({ cells: cells(r), total: sum(cells(r)) });
  return {
    months, top: { base: tot(BASE), forecasted: tot(FORE), expenses: tot(EXP), net: tot(NET) },
    sections, sectionsSum: { cells: sectionsSum, total: sum(sectionsSum) },
    expenseCats: cats, expenseSum: { cells: expenseSum, total: sum(expenseSum) },
    purple, yellow, purpleTotal: sum(purple.map((p) => p.total)), yellowTotal: sum(yellow.map((y) => y.total)),
    lineCount: sections.reduce((s, x) => s + (x.children?.length ?? 0), 0),
  };
}

/* ---- the cash worksheet, from the current October 31 column through June 30, 2027 ---- */
const MONTH = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
export function parseCash(wb: ExcelJS.Workbook, startIso = "2026-10-31", endIso = "2027-06-30"): CashLive {
  const ws = wb.getWorksheet("Cash Tracker 2026");
  if (!ws) throw new Error("sheet Cash Tracker 2026 missing");
  // the date header on row 1: years drift in the sheet, so repair them by position (a month smaller than the one before rolls the year)
  const row1 = ws.getRow(1);
  const cols: { col: number; month: number; day: number; year: number }[] = [];
  let year = 0, lastMonth = 0;
  row1.eachCell((c, col) => {
    const v = c.value as unknown;
    const d = v instanceof Date ? v : typeof v === "object" && v !== null && "result" in (v as object) && (v as { result: unknown }).result instanceof Date ? ((v as { result: Date }).result) : null;
    if (!d) return;
    const month = d.getUTCMonth() + 1, day = d.getUTCDate();
    if (!cols.length) year = d.getUTCFullYear();
    else if (month < lastMonth) year += 1;
    lastMonth = month;
    cols.push({ col, month, day, year });
  });
  const iso = (x: { year: number; month: number; day: number }) => `${x.year}-${String(x.month).padStart(2, "0")}-${String(x.day).padStart(2, "0")}`;
  const win = cols.filter((x) => iso(x) >= startIso && iso(x) <= endIso);
  if (!win.length) throw new Error("cash window not found");
  const periods = win.map((x) => ({ label: `${MONTH[x.month - 1]} ${x.day}`, year: x.year, iso: iso(x) }));
  const vals = (r: number) => win.map((x) => r2(num(ws.getCell(r, x.col)) ?? 0));
  const any = (r: number) => win.some((x) => num(ws.getCell(r, x.col)) != null);
  const label = (r: number) => text(ws.getCell(r, 1)).trim();
  const code = (r: number) => text(ws.getCell(r, 2)).trim();
  const isBold = (r: number) => bold(ws.getCell(r, 1)) || bold(ws.getCell(r, 2));
  const findRow = (want: string) => { for (let r = 1; r <= ws.rowCount; r++) if (label(r).toLowerCase() === want) return r; throw new Error(`cash row ${want} missing`); };
  const IN = findRow("cash in"), OUT = findRow("cash out"), BAL = findRow("anticipated 15-day balance");
  const beginning = vals(3);
  const inKids: LiveRow[] = [];
  for (let r = 4; r < IN; r++) {
    if (!label(r) || !any(r)) continue;
    inKids.push({ label: label(r), sub: code(r) || "no Project Code", cells: vals(r), total: sum(vals(r)) });
  }
  const outKids: LiveRow[] = [];
  let sec: LiveRow | null = null;
  for (let r = IN + 1; r < OUT; r++) {
    if (!label(r)) continue;
    if (isBold(r)) { if (sec) outKids.push(sec); sec = { label: label(r), cells: win.map(() => 0), total: 0, children: [] }; continue; }
    if (!sec || !any(r)) continue;
    const k: LiveRow = { label: label(r), cells: vals(r), total: sum(vals(r)) };
    sec.children!.push(k);
    sec.cells = sec.cells.map((v, i) => r2(v + k.cells[i])); sec.total = sum(sec.cells);
  }
  if (sec) outKids.push(sec);
  const cashIn: LiveRow = { label: label(IN), cells: vals(IN), total: sum(vals(IN)), children: inKids };
  const cashOut: LiveRow = { label: label(OUT), cells: vals(OUT), total: sum(vals(OUT)), children: outKids.filter((s) => s.children && s.children.length) };
  const balance = vals(BAL);
  let lo = 0; balance.forEach((v, i) => { if (v < balance[lo]) lo = i; });
  return { periods, beginning, cashIn, cashOut, balance, lowest: { iso: periods[lo].iso, label: `${periods[lo].label}, ${periods[lo].year}`, value: balance[lo] } };
}

export async function parseWorkbook(bytes: Buffer): Promise<{ q4: Q4Live; cash: CashLive }> {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(bytes as unknown as ArrayBuffer);
  return { q4: parseQ4(wb), cash: parseCash(wb) };
}
