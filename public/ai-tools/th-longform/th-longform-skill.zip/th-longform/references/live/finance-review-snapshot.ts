// Write content/finance-review-live-snapshot.json from a local copy of the pro
// forma workbook, with the same parser the live page uses. The snapshot is the
// fallback when SharePoint is unreachable and the fixture the build compiles
// against. Usage: node --experimental-strip-types scripts/finance-snapshot.ts <xlsx> <version> "<saved at>" "<saved by>"
import { readFileSync, writeFileSync } from "node:fs";
import ExcelJS from "exceljs";
import { parseQ4, parseCash } from "../lib/finance-live.ts";

const [, , path, version, savedAt, savedBy] = process.argv;
if (!path) { console.error("usage: finance-snapshot.ts <xlsx> <version> <saved at> <saved by>"); process.exit(1); }
const wb = new ExcelJS.Workbook();
await wb.xlsx.load(readFileSync(path) as unknown as ArrayBuffer);
const q4 = parseQ4(wb);
const cash = parseCash(wb);
const readAt = new Date().toLocaleString("en-US", { timeZone: "America/Chicago", month: "long", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" }) + " Central";
const out = { source: { version: version ?? null, savedAt: savedAt ?? "", savedBy: savedBy ?? "", readAt, eTag: "", live: false }, q4, cash };
writeFileSync(new URL("../content/finance-review-live-snapshot.json", import.meta.url), JSON.stringify(out, null, 1));
const f = (n: number) => n.toLocaleString("en-US", { maximumFractionDigits: 0 });
console.log(`q4: base ${f(q4.top.base.total)} | sections ${f(q4.sectionsSum.total)} | lines ${f(q4.sections.reduce((s, x) => s + x.linesSum.reduce((a, b) => a + b, 0), 0))} | expenses ${f(q4.top.expenses.total)} | elements ${f(q4.expenseSum.total)} | purple ${f(q4.purpleTotal)} | yellow ${f(q4.yellowTotal)} | lines ${q4.lineCount} | cats ${q4.expenseCats.length}`);
console.log(`cash: ${cash.periods.length} periods ${cash.periods[0].label} ${cash.periods[0].year} to ${cash.periods.at(-1)!.label} ${cash.periods.at(-1)!.year} | beginning ${f(cash.beginning[0])} | in ${f(cash.cashIn.total)} (${cash.cashIn.children!.length} lines) | out ${f(cash.cashOut.total)} (${cash.cashOut.children!.length} sections) | end balance ${f(cash.balance.at(-1)!)} | lowest ${f(cash.lowest.value)} on ${cash.lowest.label}`);
