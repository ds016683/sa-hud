// Where the finance review's live data comes from at request time (10/26).
// Every 60 seconds at most, ask SharePoint for the workbook's eTag; when it
// changed, download and parse the workbook once and keep the result in memory
// for this server instance. The one-minute refresh route calls the same thing.
// When SharePoint is not configured or fails, the committed snapshot stands in
// and the page says so. Server only.
import "server-only";
import snapshot from "@/content/finance-review-live-snapshot.json";
import { parseWorkbook, type FinanceLive } from "./finance-live";
import { proFormaBytes, proFormaMeta, proFormaVersion, sharepointConfigured } from "./sharepoint";

const CHECK_EVERY_MS = 60_000;

type State = { data: FinanceLive | null; eTag: string | null; checkedAt: number; error: string | null };
const g = globalThis as unknown as { __financeLive?: State };
const state: State = g.__financeLive ?? (g.__financeLive = { data: null, eTag: null, checkedAt: 0, error: null });

const fmtStamp = (iso: string) => new Date(iso).toLocaleString("en-US", { timeZone: "America/Chicago", month: "long", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" }) + " Central";

export const SNAPSHOT: FinanceLive = snapshot as unknown as FinanceLive;

/** The live data, refreshed when the workbook's eTag changed; never older than a minute without a check. */
export async function financeLive(opts: { force?: boolean } = {}): Promise<FinanceLive & { checkedAt: string; changed: boolean }> {
  const now = Date.now();
  let changed = false;
  if (sharepointConfigured() && (opts.force || now - state.checkedAt >= CHECK_EVERY_MS)) {
    try {
      const meta = await proFormaMeta();
      state.checkedAt = now;
      if (meta.eTag !== state.eTag || !state.data) {
        const [bytes, version] = await Promise.all([proFormaBytes(), proFormaVersion()]);
        const parsed = await parseWorkbook(bytes);
        state.data = {
          source: { version: version ?? meta.versionId, savedAt: fmtStamp(meta.lastModified), savedBy: meta.lastModifiedBy, readAt: fmtStamp(new Date(now).toISOString()), eTag: meta.eTag, live: true },
          ...parsed,
        };
        state.eTag = meta.eTag;
        state.error = null;
        changed = true;
      }
    } catch (e) {
      state.error = e instanceof Error ? e.message : String(e);
      state.checkedAt = now;
    }
  }
  const data = state.data ?? SNAPSHOT;
  return { ...data, checkedAt: state.checkedAt ? new Date(state.checkedAt).toISOString() : "", changed };
}

export function financeLiveStatus() {
  return { configured: sharepointConfigured(), eTag: state.eTag, checkedAt: state.checkedAt ? new Date(state.checkedAt).toISOString() : null, error: state.error, source: (state.data ?? SNAPSHOT).source };
}
