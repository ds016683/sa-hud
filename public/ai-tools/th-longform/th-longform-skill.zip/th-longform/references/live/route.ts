import { NextResponse } from "next/server";
import { financeLive, financeLiveStatus } from "@/lib/finance-source";
import { PRIVATE_CACHE_CONTROL } from "@/lib/gate";

// The one-minute check (10/26): Vercel's cron calls this every minute on the
// production deployment; it asks SharePoint for the workbook's eTag and
// re-reads the workbook when it changed, so the next page view is warm. It
// answers with the source stamp only, never with the figures. The page itself
// runs the same check at request time, so a preview deployment stays within a
// minute of SharePoint without the cron.

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const t0 = Date.now();
  let changed = false, error: string | null = null;
  try { changed = (await financeLive({ force: true })).changed; } catch (e) { error = e instanceof Error ? e.message : String(e); }
  const s = financeLiveStatus();
  console.log(`[finance-review refresh] by=${req.headers.get("user-agent") ?? ""} changed=${changed} version=${s.source.version} live=${s.source.live} ms=${Date.now() - t0}${error ?? s.error ? ` error=${error ?? s.error}` : ""}`);
  const res = NextResponse.json({ ok: !error && !s.error, changed, error: error ?? s.error, configured: s.configured, version: s.source.version, savedAt: s.source.savedAt, readAt: s.source.readAt, live: s.source.live, checkedAt: s.checkedAt, ms: Date.now() - t0 });
  res.headers.set("Cache-Control", PRIVATE_CACHE_CONTROL);
  return res;
}
