// SharePoint over Microsoft Graph, app-only (Sites.Selected on the THS Finance
// Binder). The client secret and the ids come from the environment, never from
// the repo: SHAREPOINT_TENANT_ID, SHAREPOINT_CLIENT_ID, SHAREPOINT_CLIENT_SECRET,
// SHAREPOINT_SITE_ID, SHAREPOINT_PROFORMA_ITEM. Server only.
import "server-only";

const GRAPH = "https://graph.microsoft.com/v1.0";

export type DriveItemMeta = { eTag: string; lastModified: string; lastModifiedBy: string; size: number; name: string; versionId: string | null };

function env(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`${name} is not set`);
  return v;
}

export function sharepointConfigured(): boolean {
  return ["SHAREPOINT_TENANT_ID", "SHAREPOINT_CLIENT_ID", "SHAREPOINT_CLIENT_SECRET", "SHAREPOINT_SITE_ID", "SHAREPOINT_PROFORMA_ITEM"].every((k) => !!process.env[k]);
}

let token: { value: string; expiresAt: number } | null = null;

async function accessToken(): Promise<string> {
  if (token && token.expiresAt > Date.now() + 60_000) return token.value;
  const body = new URLSearchParams({
    client_id: env("SHAREPOINT_CLIENT_ID"),
    client_secret: env("SHAREPOINT_CLIENT_SECRET"),
    scope: "https://graph.microsoft.com/.default",
    grant_type: "client_credentials",
  });
  const res = await fetch(`https://login.microsoftonline.com/${env("SHAREPOINT_TENANT_ID")}/oauth2/v2.0/token`, { method: "POST", body, cache: "no-store" });
  if (!res.ok) throw new Error(`token ${res.status}`);
  const j = (await res.json()) as { access_token: string; expires_in: number };
  token = { value: j.access_token, expiresAt: Date.now() + j.expires_in * 1000 };
  return token.value;
}

function itemUrl(): string {
  return `${GRAPH}/sites/${env("SHAREPOINT_SITE_ID")}/drive/items/${env("SHAREPOINT_PROFORMA_ITEM")}`;
}

/** The workbook's current eTag and save stamp: one small call, enough to know whether it changed. */
export async function proFormaMeta(): Promise<DriveItemMeta> {
  const t = await accessToken();
  const res = await fetch(`${itemUrl()}?$select=eTag,lastModifiedDateTime,lastModifiedBy,size,name&$expand=listItem($select=id)`, { headers: { Authorization: `Bearer ${t}` }, cache: "no-store" });
  if (!res.ok) throw new Error(`meta ${res.status}`);
  const j = (await res.json()) as { eTag: string; lastModifiedDateTime: string; lastModifiedBy?: { user?: { displayName?: string } }; size: number; name: string };
  const versionId = (j.eTag.match(/,(\d+)\}?"?$/) || [])[1] ?? null;
  return { eTag: j.eTag, lastModified: j.lastModifiedDateTime, lastModifiedBy: j.lastModifiedBy?.user?.displayName ?? "", size: j.size, name: j.name, versionId };
}

/** SharePoint's own version label for the current save ("4626"), one small call. */
export async function proFormaVersion(): Promise<string | null> {
  const t = await accessToken();
  const res = await fetch(`${itemUrl()}/versions?$top=1&$select=id`, { headers: { Authorization: `Bearer ${t}` }, cache: "no-store" });
  if (!res.ok) return null;
  const j = (await res.json()) as { value?: { id?: string }[] };
  const id = j.value?.[0]?.id ?? null;
  return id ? id.replace(/\.0$/, "") : null;
}

/** The workbook's bytes. */
export async function proFormaBytes(): Promise<Buffer> {
  const t = await accessToken();
  const res = await fetch(`${itemUrl()}/content`, { headers: { Authorization: `Bearer ${t}` }, cache: "no-store" });
  if (!res.ok) throw new Error(`content ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}
