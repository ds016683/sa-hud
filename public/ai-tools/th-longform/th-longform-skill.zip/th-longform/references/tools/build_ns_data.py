"""Write content/finance-review-ns-data.ts from the SuiteQL pull (ns_pl_jan_sep.json):
the income statement as NetSuite lays it out, every parent opening to its accounts,
monthly columns January through September plus the nine-month total, with the
statement's own total rows. Labels are NetSuite's "number - name". Branches with
no activity in the nine months are pruned.
Usage: build_ns_data.py <pull.json> <out.ts> <readOn>"""
import json, sys
src, out, read_on = sys.argv[1], sys.argv[2], sys.argv[3]
d = json.load(open(src))
lines_by_acct = {}
if len(sys.argv) > 4:
    for l in json.load(open(sys.argv[4]))["lines"]:
        lines_by_acct.setdefault(l["acct"], []).append(l)
months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"]
closed = [p["closed"] == "T" for p in sorted(d["periods"], key=lambda p: p["month"])]

# Every P&L account (summary parents included), activity attached where it exists.
nodes = {}
for a in d["allAccounts"]:
    nodes[a["id"]] = {"id": a["id"], "number": a.get("number") or "", "name": a.get("name") or "", "type": a["type"], "parent": a.get("parent"),
                      "own": [0.0] * 9, "kids": []}
for a in d["accounts"]:
    if a["id"] in nodes: nodes[a["id"]]["own"] = [round(a["months"][str(m)], 2) for m in range(1, 10)]
for n in nodes.values():
    if n["parent"] in nodes: nodes[n["parent"]]["kids"].append(n)
for n in nodes.values(): n["kids"].sort(key=lambda k: (k["number"], k["name"]))

def active(n): return any(abs(v) > 0.004 for v in n["own"]) or any(active(k) for k in n["kids"])
def label(n): return f"{n['number']} - {n['name']}" if n["number"] else n["name"]
def row(n):
    kids = [k for k in n["kids"] if active(k)]
    if not kids:
        r = {"label": label(n), "cells": n["own"], "total": round(sum(n["own"]), 2)}
        cl = sorted(lines_by_acct.get(n["id"], []), key=lambda l: -abs(l["total"]))
        if n["type"] == "Income" and cl:
            r["children"] = [{"label": l["client"], "sub": l["project"] or "no Project ID", **({"flag": l["flag"]} if l.get("flag") else {}), "cells": [round(l["months"][str(m)], 2) for m in range(1, 10)], "total": l["total"]} for l in cl]
            check = round(sum(l["total"] for l in cl), 2)
            assert abs(check - r["total"]) < 0.02, (label(n), check, r["total"])
        return r
    kid_rows = [row(k) for k in kids]
    if any(abs(v) > 0.004 for v in n["own"]):
        kid_rows.insert(0, {"label": label(n), "sub": "this account", "cells": n["own"], "total": round(sum(n["own"]), 2)})
    cells = [round(sum(r["cells"][m] for r in kid_rows), 2) for m in range(9)]
    return {"label": label(n), "cells": cells, "total": round(sum(cells), 2), "children": kid_rows}

def section(types):
    roots = [n for n in nodes.values() if n["type"] in types and n["parent"] not in nodes and active(n)]
    roots.sort(key=lambda k: (k["number"], k["name"]))
    return [row(n) for n in roots]

def sum_rows(rows):
    c = [round(sum(r["cells"][m] for r in rows), 2) for m in range(9)]
    return c, round(sum(c), 2)

income, expense = section({"Income"}), section({"Expense", "COGS"})
oth_inc, oth_exp = section({"OthIncome"}), section({"OthExpense"})
inc_c, inc_t = sum_rows(income); exp_c, exp_t = sum_rows(expense); oi_c, oi_t = sum_rows(oth_inc); oe_c, oe_t = sum_rows(oth_exp)
ord_c = [round(inc_c[m] - exp_c[m], 2) for m in range(9)]; ord_t = round(sum(ord_c), 2)
net_c = [round(ord_c[m] + oi_c[m] - oe_c[m], 2) for m in range(9)]; net_t = round(sum(net_c), 2)

data = {
    "readOn": read_on, "months": months, "closed": closed,
    "income": income, "expense": expense, "otherIncome": oth_inc, "otherExpense": oth_exp,
    "totals": {"income": {"cells": inc_c, "total": inc_t}, "expense": {"cells": exp_c, "total": exp_t}, "ordinary": {"cells": ord_c, "total": ord_t},
               "otherIncome": {"cells": oi_c, "total": oi_t}, "otherExpense": {"cells": oe_c, "total": oe_t}, "net": {"cells": net_c, "total": net_t}},
    "accountCount": len(d["accounts"]),
}
ts = ("// Generated from NetSuite over SuiteQL (posting transactions, accounting-period basis, the nine 2026 periods\n"
      "// January through September) on " + read_on + " by the session's ns_pl_jan_sep.py + build_ns_data.py. Do not edit by hand; regenerate.\n"
      "import type { DocRow } from \"./doc\";\n\n"
      "export type NsTotal = { cells: number[]; total: number };\n"
      "export type NsData = { readOn: string; months: string[]; closed: boolean[]; income: DocRow[]; expense: DocRow[]; otherIncome: DocRow[]; otherExpense: DocRow[];"
      " totals: { income: NsTotal; expense: NsTotal; ordinary: NsTotal; otherIncome: NsTotal; otherExpense: NsTotal; net: NsTotal }; accountCount: number };\n\n"
      "export const NS: NsData = " + json.dumps(data, ensure_ascii=False, indent=1) + ";\n")
open(out, "w", encoding="utf-8").write(ts)
print(f"income {inc_t:,.2f} | expense {exp_t:,.2f} | ordinary {ord_t:,.2f} | other income {oi_t:,.2f} | other expense {oe_t:,.2f} | net {net_t:,.2f}")
def show(rows, depth=0):
    for r in rows:
        print("  " * depth + f"{r['label'][:48]:<50} {r['total']:>14,.2f}")
        if r.get("children"): show(r["children"], depth + 1)
show(income); print("---"); show(expense); print("---"); show(oth_inc); print("---"); show(oth_exp)
