"""Write content/finance-review-data.ts from the live pro forma (PRO FORMA 2026, 2026 block)."""
import json, sys, datetime
import openpyxl
from openpyxl.utils import column_index_from_string as CI
src, out = sys.argv[1], sys.argv[2]
wb = openpyxl.load_workbook(src, data_only=True)
ws = wb["PRO FORMA 2026"]
jan, sep = CI("U"), CI("AC")
months = [str(ws.cell(4, c).value) for c in range(jan, sep + 1)]
labels = [str(ws.cell(5, c).value) for c in range(jan, sep + 1)]
assert months == ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"], months
def cells(r):
    v = [ws.cell(r, c).value for c in range(jan, sep + 1)]
    return [float(x) if isinstance(x, (int, float)) else None for x in v]
def row(r, sub=False):
    c = cells(r); nums = [x for x in c if x is not None]
    return {"label": str(ws.cell(r, 2).value).strip(), **({"sub": str(ws.cell(r, 3).value).strip()} if sub and ws.cell(r, 3).value not in (None, "") else {}),
            "cells": [int(round(x)) if x is not None else None for x in c], "total": int(round(sum(nums))) if nums else None}
SECTIONS = [(9, 71), (71, 91), (91, 141), (141, 152), (152, 177), (177, 192)]  # header row, next header row
sections = []
for head, nxt in SECTIONS:
    s = row(head)
    kids = []
    for r in range(head + 1, nxt):
        if ws.cell(r, 2).value in (None, ""): continue
        if ws.cell(r, 2).font and ws.cell(r, 2).font.b: continue  # a sub-total line such as "Market Analytics Total"
        k = row(r, sub=True)
        if k["total"] and k["total"] != 0: kids.append(k)
    s["children"] = kids
    sections.append(s)
base, fore, exp, net = row(6), row(7), row(192), row(278)
# checks
for m in range(9):
    assert abs((base["cells"][m] - exp["cells"][m]) - net["cells"][m]) <= 1, m
    assert base["cells"][m] == fore["cells"][m], m
secsum = sum(s["total"] for s in sections)
data = {"readOn": "October 25, 2026", "months": months, "labels": labels, "sections": sections, "base": base, "forecasted": fore, "expenses": exp, "net": net,
        "sectionsTotal": secsum, "kidsCount": sum(len(s["children"]) for s in sections)}
ts = "// Generated from the live pro forma (SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026,\n// 2026 block, columns U to AC) on " + data["readOn"] + " by the session's build_pf_data.py. Do not edit by hand; regenerate.\n"
ts += "import type { DocRow } from \"./doc\";\n\n"
ts += "export type PfData = { readOn: string; months: string[]; labels: string[]; sections: DocRow[]; base: DocRow; forecasted: DocRow; expenses: DocRow; net: DocRow; sectionsTotal: number; kidsCount: number };\n\n"
ts += "export const PF: PfData = " + json.dumps(data, ensure_ascii=False, indent=1) + ";\n"
open(out, "w", encoding="utf-8").write(ts)
print("sections:", [(s["label"], s["total"], len(s["children"])) for s in sections])
print("base", base["total"], "expenses", exp["total"], "net", net["total"], "sections sum", secsum)
