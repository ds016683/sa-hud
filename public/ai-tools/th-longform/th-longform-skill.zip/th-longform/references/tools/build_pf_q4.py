"""Write content/finance-review-q4-data.ts from the live pro forma (PRO FORMA 2026, 2026
block): the October through December estimate as the sheet's own elements. Revenue by
practice area with its client lines (purple font flagged as an assumption, yellow fill
flagged as highlighted), expenses by category lump with its lines, the sheet's typed top
lines (Base Revenue, Forecasted Revenue, Expenses, Net Income) and the sums of the
elements beside them. Usage: build_pf_q4.py <xlsx> <out.ts> <readOn> <savedAt> <version>"""
import json, sys
import openpyxl
from openpyxl.utils import column_index_from_string as CI
src, out, read_on, saved_at, version = sys.argv[1:6]
wb = openpyxl.load_workbook(src, data_only=True)
ws = wb["PRO FORMA 2026"]
OCT, DEC = CI("AD"), CI("AF")
assert [ws.cell(4, c).value for c in range(OCT, DEC + 1)] == ["Oct", "Nov", "Dec"]
months = ["Oct", "Nov", "Dec"]
PURPLE, YELLOW = "FF7030A0", "FFFFFF00"

def cells(r):
    v = [ws.cell(r, c).value for c in range(OCT, DEC + 1)]
    return [round(float(x), 2) if isinstance(x, (int, float)) else 0.0 for x in v]
def has(r): return any(abs(v) > 0.004 for v in cells(r))
def bold(r): return bool(ws.cell(r, 2).font and ws.cell(r, 2).font.b)
def label(r): return str(ws.cell(r, 2).value).strip()
def code(r):
    v = ws.cell(r, 3).value
    return str(v).strip() if v not in (None, "") else None
def font(r):
    c = ws.cell(r, 2).font
    return c.color.rgb if (c and c.color is not None and isinstance(c.color.rgb, str)) else ""
def fill(r):
    f = ws.cell(r, 2).fill
    if f and f.fill_type == "solid" and f.fgColor is not None and isinstance(f.fgColor.rgb, str): return f.fgColor.rgb
    return ""
def row(r, with_flags=False):
    d = {"label": label(r), "cells": cells(r), "total": round(sum(cells(r)), 2)}
    if with_flags: d["sub"] = code(r) or "no Project ID"
    elif code(r): d["sub"] = code(r)
    if with_flags:
        if font(r) == PURPLE: d["flag"] = "Assumption"
        elif fill(r) == YELLOW: d["flag"] = "Yellow in the sheet"
    return d

# Revenue: the six practice-area sections and their client lines with Q4 activity.
SECTIONS = [(9, 71), (71, 91), (91, 141), (141, 152), (152, 177), (177, 192)]
sections, purple, yellow = [], [], []
for head, nxt in SECTIONS:
    s = {"label": label(head), "cells": cells(head), "total": round(sum(cells(head)), 2), "children": []}
    for r in range(head + 1, nxt):
        if ws.cell(r, 2).value in (None, "") or bold(r): continue
        if not has(r) and font(r) != PURPLE: continue
        k = row(r, with_flags=True)
        k["section"] = label(head)
        if k.get("flag") == "Assumption": purple.append({**k})
        if k.get("flag") == "Yellow in the sheet": yellow.append({**k})
        k.pop("section", None)
        s["children"].append(k)
    s["linesSum"] = [round(sum(k["cells"][m] for k in s["children"]), 2) for m in range(3)]
    sections.append(s)
sections_sum = [round(sum(s["cells"][m] for s in sections), 2) for m in range(3)]

# Expenses: bold category rows with the non-bold lines beneath them, both additive.
cats, cur = [], None
for r in range(194, 278):
    if ws.cell(r, 2).value in (None, ""): continue
    if bold(r):
        cur = {"label": label(r), "own": cells(r), "children": []}; cats.append(cur); continue
    if cur is None or not has(r): continue
    cur["children"].append(row(r))
expense_cats = []
for c in cats:
    own_has = any(abs(v) > 0.004 for v in c["own"])
    if not own_has and not c["children"]: continue
    kids = list(c["children"])
    if own_has and kids: kids.insert(0, {"label": c["label"], "sub": "the lump", "cells": c["own"], "total": round(sum(c["own"]), 2)})
    total_cells = [round(c["own"][m] + sum(k["cells"][m] for k in c["children"]), 2) for m in range(3)]
    d = {"label": c["label"], "cells": total_cells, "total": round(sum(total_cells), 2)}
    if kids: d["children"] = kids
    expense_cats.append(d)
expense_sum = [round(sum(c["cells"][m] for c in expense_cats), 2) for m in range(3)]

top = {"base": {"cells": cells(6), "total": round(sum(cells(6)), 2)}, "forecasted": {"cells": cells(7), "total": round(sum(cells(7)), 2)},
       "expenses": {"cells": cells(192), "total": round(sum(cells(192)), 2)}, "net": {"cells": cells(278), "total": round(sum(cells(278)), 2)}}
data = {"readOn": read_on, "savedAt": saved_at, "version": version, "months": months, "top": top,
        "sections": sections, "sectionsSum": {"cells": sections_sum, "total": round(sum(sections_sum), 2)},
        "expenseCats": expense_cats, "expenseSum": {"cells": expense_sum, "total": round(sum(expense_sum), 2)},
        "purple": purple, "yellow": yellow,
        "purpleTotal": round(sum(p["total"] for p in purple), 2), "yellowTotal": round(sum(y["total"] for y in yellow), 2),
        "lineCount": sum(len(s["children"]) for s in sections)}
ts = ("// Generated from the live pro forma (SharePoint Finance Binder, 2025 Pro Forma.xlsx, sheet PRO FORMA 2026, 2026 block,\n"
      "// columns AD to AF) version " + version + ", saved " + saved_at + ", read " + read_on + ", by the session's build_pf_q4.py. Do not edit by hand; regenerate.\n"
      "export type Q4Total = { cells: number[]; total: number };\n"
      "/** A sheet row: every cell a number (the sheet carries zeros, never blanks); assignable to DocRow. */\n"
      "export type Q4Row = { label: string; sub?: string; flag?: string; cells: number[]; total: number; children?: Q4Row[] };\n"
      "export type Q4Data = { readOn: string; savedAt: string; version: string; months: string[]; top: { base: Q4Total; forecasted: Q4Total; expenses: Q4Total; net: Q4Total };"
      " sections: (Q4Row & { linesSum: number[] })[]; sectionsSum: Q4Total; expenseCats: Q4Row[]; expenseSum: Q4Total; purple: (Q4Row & { section: string })[]; yellow: (Q4Row & { section: string })[];"
      " purpleTotal: number; yellowTotal: number; lineCount: number };\n\n"
      "export const Q4: Q4Data = " + json.dumps(data, ensure_ascii=False, indent=1) + ";\n")
open(out, "w", encoding="utf-8").write(ts)
f = lambda v: f"{v:,.0f}"
print("months", months)
print("Base      ", [f(v) for v in top["base"]["cells"]], f(top["base"]["total"]))
print("sections  ", [f(v) for v in sections_sum], f(sum(sections_sum)), "| diff", [f(top["base"]["cells"][m] - sections_sum[m]) for m in range(3)])
print("Forecasted", [f(v) for v in top["forecasted"]["cells"]], "| diff to base", [f(top["forecasted"]["cells"][m] - top["base"]["cells"][m]) for m in range(3)])
print("Expenses  ", [f(v) for v in top["expenses"]["cells"]], f(top["expenses"]["total"]))
print("elements  ", [f(v) for v in expense_sum], f(sum(expense_sum)), "| diff", [f(top["expenses"]["cells"][m] - expense_sum[m]) for m in range(3)])
print("Net       ", [f(v) for v in top["net"]["cells"]], f(top["net"]["total"]), "| base-exp", [f(top['base']['cells'][m] - top['expenses']['cells'][m]) for m in range(3)])
for s in sections: print("  ", s["label"], f(s["total"]), "lines", len(s["children"]), "| lines sum", f(sum(s["linesSum"])), "| diff", f(s["total"] - sum(s["linesSum"])))
print("purple:", [(p["label"], p["section"], f(p["total"])) for p in purple], f(data["purpleTotal"]))
print("yellow:", [(y["label"], y["section"], f(y["total"])) for y in yellow], f(data["yellowTotal"]))
print("expense cats:", [(c["label"], f(c["total"]), len(c.get("children", []))) for c in expense_cats])
