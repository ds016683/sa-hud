#!/bin/bash
# Gate checks for a document on th-longform against a production build: anonymous
# requests are denied, the unlock page carries no code, the right code opens the page,
# and the build emits no static payload. Run after `npx next build`.
# Usage: check_longform_gate.sh <port> [slug]
set -u
PORT=${1:-3040}; SLUG=${2:-finance-review}; UP=$(echo "$SLUG" | tr 'a-z-' 'A-Z_')
cd /Users/davidsmith/builds/th-longform
env "DOCUMENT_CODE_${UP}=check-code" DOCUMENT_SECRET=check-secret node node_modules/next/dist/bin/next start -H 127.0.0.1 -p "$PORT" >/tmp/claude-501/lf-start.log 2>&1 &
PID=$!
for i in $(seq 1 60); do curl -s -o /dev/null "http://127.0.0.1:$PORT/$SLUG/unlock" && break; sleep 0.5; done
fail=0
chk() { if [ "$2" = "$3" ]; then echo "PASS $1"; else echo "FAIL $1: got $2, wanted $3"; fail=1; fi; }
code=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:$PORT/$SLUG"); chk "anonymous /$SLUG denied" "$code" "307"
loc=$(curl -s -o /dev/null -w "%{redirect_url}" "http://127.0.0.1:$PORT/$SLUG"); chk "redirect goes to unlock" "${loc##*:$PORT}" "/$SLUG/unlock"
code=$(curl -s -o /dev/null -w "%{http_code}" -H "RSC: 1" "http://127.0.0.1:$PORT/$SLUG"); chk "anonymous RSC denied" "$code" "307"
body=$(curl -s "http://127.0.0.1:$PORT/$SLUG/unlock"); chk "unlock page carries no code" "$(echo "$body" | grep -c check-code)" "0"
code=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "slug=$SLUG&code=wrong" "http://127.0.0.1:$PORT/api/unlock"); chk "wrong code bounces" "$code" "303"
cookie=$(curl -s -o /dev/null -D - -X POST -d "slug=$SLUG&code=check-code" "http://127.0.0.1:$PORT/api/unlock" | grep -i "^set-cookie" | sed -E 's/^[Ss]et-[Cc]ookie: ([^;]+).*/\1/'); chk "right code grants the session cookie" "${cookie%%=*}" "thl_$SLUG"
code=$(curl -s -o /dev/null -w "%{http_code}" -H "Cookie: $cookie" "http://127.0.0.1:$PORT/$SLUG"); chk "authorized page opens" "$code" "200"
code=$(curl -s -o /dev/null -w "%{http_code}" -H "Cookie: thl_$SLUG=v1.1.deadbeef" "http://127.0.0.1:$PORT/$SLUG"); chk "tampered cookie denied" "$code" "307"
code=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:$PORT/api/finance-review/refresh"); chk "refresh route answers" "$code" "200"
static=$(find .next/server/app -maxdepth 2 \( -name "$SLUG.html" -o -name "$SLUG.rsc" \) | wc -l | tr -d ' '); chk "no static document payload in the build" "$static" "0"
kill $PID 2>/dev/null; wait $PID 2>/dev/null
exit $fail
