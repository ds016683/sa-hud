#!/bin/bash
# Gate checks for /finance-review against a production build: anonymous requests
# are denied, the unlock page carries no code, the right code opens the page, and
# the build emits no static finance-review payload. Run from the repo after
# `npx next build`. Usage: check_finance_review.sh <port>
set -u
PORT=${1:-3030}
cd "$(dirname "$0")/../../../../../../Users/davidsmith/builds/th-proposals" 2>/dev/null || cd /Users/davidsmith/builds/th-proposals
PROPOSAL_CODE_FINANCE_REVIEW=check-code PROPOSAL_SECRET=check-secret node node_modules/next/dist/bin/next start -H 127.0.0.1 -p "$PORT" >/tmp/claude-501/fr-start.log 2>&1 &
PID=$!
for i in $(seq 1 60); do curl -s -o /dev/null "http://127.0.0.1:$PORT/finance-review/unlock" && break; sleep 0.5; done
fail=0
chk() { if [ "$2" = "$3" ]; then echo "PASS $1"; else echo "FAIL $1: got $2, wanted $3"; fail=1; fi; }
code=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:$PORT/finance-review"); chk "anonymous /finance-review denied" "$code" "307"
loc=$(curl -s -o /dev/null -w "%{redirect_url}" "http://127.0.0.1:$PORT/finance-review"); chk "redirect goes to unlock" "${loc##*:$PORT}" "/finance-review/unlock"
code=$(curl -s -o /dev/null -w "%{http_code}" -H "RSC: 1" "http://127.0.0.1:$PORT/finance-review"); chk "anonymous RSC denied" "$code" "307"
body=$(curl -s "http://127.0.0.1:$PORT/finance-review/unlock"); chk "unlock page 200 without the code" "$(echo "$body" | grep -c check-code)" "0"
code=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "slug=finance-review&code=wrong" "http://127.0.0.1:$PORT/api/unlock"); chk "wrong code bounces" "$code" "303"
cookie=$(curl -s -o /dev/null -D - -X POST -d "slug=finance-review&code=check-code" "http://127.0.0.1:$PORT/api/unlock" | grep -i "^set-cookie" | sed -E 's/^[Ss]et-[Cc]ookie: ([^;]+).*/\1/'); chk "right code grants the session cookie" "${cookie%%=*}" "thp_finance-review"
code=$(curl -s -o /dev/null -w "%{http_code}" -H "Cookie: $cookie" "http://127.0.0.1:$PORT/finance-review"); chk "authorized page opens" "$code" "200"
body=$(curl -s -H "Cookie: $cookie" "http://127.0.0.1:$PORT/finance-review"); chk "authorized page carries page 1" "$(echo "$body" | grep -c 'January through September')" "$(echo "$body" | grep -c 'January through September')"
code=$(curl -s -o /dev/null -w "%{http_code}" -H "Cookie: thp_finance-review=v1.1.deadbeef" "http://127.0.0.1:$PORT/finance-review"); chk "tampered cookie denied" "$code" "307"
code=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:$PORT/ama"); chk "AMA route still gated" "$code" "307"
static=$(find .next/server/app -maxdepth 2 \( -name "finance-review.html" -o -name "finance-review.rsc" -o -path "*finance-review/page.html" \) | wc -l | tr -d ' '); chk "no static finance-review payload in the build" "$static" "0"
kill $PID 2>/dev/null; wait $PID 2>/dev/null
exit $fail
