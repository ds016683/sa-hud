#!/bin/bash
# Gate checks against a deployed th-longform host (no real code is sent; the right-code grant is proven by check_longform_gate.sh on the local build).
# Usage: check_longform_prod.sh <host> [slug]
set -u
H=${1:?host}; SLUG=${2:-finance-review}; B="https://$H"; fail=0
chk() { if [ "$2" = "$3" ]; then echo "PASS $1"; else echo "FAIL $1: got $2, wanted $3"; fail=1; fi; }
chk "root answers" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 30 "$B/")" "200"
chk "anonymous /$SLUG denied" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 30 "$B/$SLUG")" "307"
loc=$(curl -s -o /dev/null -w '%{redirect_url}' --max-time 30 "$B/$SLUG"); chk "redirect goes to unlock" "${loc#"$B"}" "/$SLUG/unlock"
chk "anonymous RSC denied" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 30 -H 'RSC: 1' "$B/$SLUG")" "307"
body=$(curl -s --max-time 30 "$B/$SLUG/unlock"); chk "unlock page renders" "$(echo "$body" | grep -c 'This document is confidential')" "1"
chk "unlock page carries no code" "$(echo "$body" | grep -ci 'cfr2026')" "0"
chk "wrong code bounces" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 30 -X POST -d "slug=$SLUG&code=wrong" "$B/api/unlock")" "303"
chk "tampered cookie denied" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 30 -H "Cookie: thl_$SLUG=v1.1.deadbeef" "$B/$SLUG")" "307"
r=$(curl -s --max-time 90 "$B/api/$SLUG/refresh"); chk "refresh route answers live" "$(echo "$r" | grep -c '"live":true')" "1"
chk "no SharePoint secret in any response" "$(echo "$body$r" | grep -ci 'client_secret')" "0"
exit $fail
