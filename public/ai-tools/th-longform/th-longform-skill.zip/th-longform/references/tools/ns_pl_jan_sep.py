"""Pull the NetSuite income statement for the 2026 accounting periods January through
September over SuiteQL: every P&L account by posting period, with the account tree
(number, name, type, parent) so the statement's subtotals rebuild exactly as the
NetSuite report shows them. Accounting-period basis (postingperiod), posting
transactions only. Income credits flipped to positive. Writes <out>.json.
Usage: ns_pl_jan_sep.py <pipeline dir with .env> <out.json>"""
import json, pathlib, sys
import requests
from requests_oauthlib import OAuth1

PIPE, OUT = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
env = {}
for line in (PIPE / ".env").read_text().splitlines():
    s = line.strip()
    if s and not s.startswith("#") and "=" in s:
        k, v = s.split("=", 1); env[k.strip()] = v.strip()
ACCOUNT = env["NETSUITE_ACCOUNT_ID"]; HOST = ACCOUNT.lower().replace("_", "-")
BASE = f"https://{HOST}.suitetalk.api.netsuite.com/services/rest/query/v1/suiteql"
auth = OAuth1(env["NETSUITE_CONSUMER_KEY"], env["NETSUITE_CONSUMER_SECRET"], env["NETSUITE_TOKEN_ID"], env["NETSUITE_TOKEN_SECRET"], signature_method="HMAC-SHA256", realm=ACCOUNT)

def q(sql):
    items, off = [], 0
    while True:
        r = requests.post(f"{BASE}?limit=1000&offset={off}", auth=auth, headers={"Prefer": "transient", "Content-Type": "application/json"}, json={"q": sql}, timeout=120)
        if r.status_code >= 400: raise SystemExit(f"SuiteQL {r.status_code}: {r.text[:600]}\nSQL: {sql[:300]}")
        j = r.json(); items += j.get("items", [])
        if not j.get("hasMore"): break
        off += 1000
    return items

# The nine month periods of 2026 through September, with their closed flags.
periods = q("""SELECT id, periodname, startdate, enddate, closed, isquarter, isyear, isadjust
FROM accountingperiod
WHERE startdate >= TO_DATE('2026-01-01','YYYY-MM-DD') AND startdate < TO_DATE('2026-10-01','YYYY-MM-DD')
  AND isquarter = 'F' AND isyear = 'F'
ORDER BY startdate""")
pid_to_month = {}
for p in periods:
    m = int(str(p["startdate"]).split("/")[0]) if "/" in str(p["startdate"]) else int(str(p["startdate"])[5:7])
    pid_to_month[str(p["id"])] = m
assert sorted(pid_to_month.values()) == list(range(1, 10)), pid_to_month
pids = ",".join(pid_to_month.keys())

# The P&L account tree.
accts = {str(a["id"]): a for a in q("""SELECT a.id, a.acctnumber, a.acctname, a.accttype, a.parent, a.issummary, a.isinactive
FROM account a WHERE a.accttype IN ('Income','OthIncome','Expense','COGS','OthExpense')""")}

# Amounts by account and period: posting transaction lines only.
rows = q(f"""SELECT tl.account acct, t.postingperiod pp, ROUND(SUM(tl.amount), 2) amt
FROM transactionline tl JOIN transaction t ON t.id = tl.transaction JOIN account a ON a.id = tl.account
WHERE t.posting = 'T' AND t.postingperiod IN ({pids}) AND a.accttype IN ('Income','OthIncome','Expense','COGS','OthExpense')
GROUP BY tl.account, t.postingperiod""")
by = {}
for r in rows:
    aid = str(r["acct"]); m = pid_to_month[str(r["pp"])]
    a = accts.get(aid)
    if not a: continue
    amt = float(r["amt"] or 0)
    if a["accttype"] in ("Income", "OthIncome"): amt = -amt
    by.setdefault(aid, {})[m] = round(by.get(aid, {}).get(m, 0) + amt, 2)

out = {
    "periods": [{"id": str(p["id"]), "name": p["periodname"], "month": pid_to_month[str(p["id"])], "closed": p["closed"]} for p in periods],
    "accounts": [
        {"id": aid, "number": a.get("acctnumber") or "", "name": a.get("acctname") or "", "type": a["accttype"], "parent": str(a["parent"]) if a.get("parent") else None,
         "months": {str(m): by.get(aid, {}).get(m, 0) for m in range(1, 10)}, "total": round(sum(by.get(aid, {}).values()), 2)}
        for aid, a in accts.items() if aid in by
    ],
    "allAccounts": [{"id": aid, "number": a.get("acctnumber") or "", "name": a.get("acctname") or "", "type": a["accttype"], "parent": str(a["parent"]) if a.get("parent") else None, "summary": a.get("issummary")} for aid, a in accts.items()],
    "visibleRecordTypes": sorted(x["rt"] for x in q("SELECT DISTINCT t.recordtype rt FROM transaction t WHERE t.trandate >= TO_DATE('2026-01-01','YYYY-MM-DD')")),
}
OUT.write_text(json.dumps(out, indent=1))

# Tie-out against David's NetSuite income statement screenshot (Jan to Sep aggregate).
screen = {"41100": 709318.43, "41210": 49033.37, "41220": 36000.00, "42100": 4825669.69, "42300": 364695.19, "43200": 5400.91, "43400": 1449.91,
          "61100": 3577410.43, "61150": 248574.29, "61200": 40000.00, "61250": 3731.95, "61300": 80037.06, "61350": 170748.91, "61400": 17107.23,
          "61750": 1709.91, "61800": 18121.76, "61850": 6311.00, "62100": 5137.36, "62300": 474.11, "63100": 44410.00, "63200": 23798.03, "63300": 51805.19,
          "63810": 120122.42, "63820": 16408.14, "63830": 64034.21, "63840": 49175.00}
bynum = {a["number"]: a for a in out["accounts"]}
bad = 0
for num, want in screen.items():
    got = bynum.get(num, {}).get("total")
    flag = "" if got is not None and abs(got - want) < 0.005 else "  <-- MISMATCH"
    if flag: bad += 1
    print(f"{num:>6} {str(bynum.get(num, {}).get('name', '?'))[:40]:<40} {got if got is not None else 'missing':>14} vs {want:>14,.2f}{flag}")
rev = sum(a["total"] for a in out["accounts"] if a["type"] == "Income")
oth_inc = sum(a["total"] for a in out["accounts"] if a["type"] == "OthIncome")
exp = sum(a["total"] for a in out["accounts"] if a["type"] in ("Expense", "COGS"))
oth_exp = sum(a["total"] for a in out["accounts"] if a["type"] == "OthExpense")
print(f"Income {rev:,.2f} (screen 5,991,567.50) | Expense {exp:,.2f} | Other income {oth_inc:,.2f} | Other expense {oth_exp:,.2f} | Net {rev - exp + oth_inc - oth_exp:,.2f}")
print("periods:", [(p['name'], p['closed']) for p in out['periods']])
print("accounts with activity:", len(out["accounts"]), "| mismatches:", bad)
