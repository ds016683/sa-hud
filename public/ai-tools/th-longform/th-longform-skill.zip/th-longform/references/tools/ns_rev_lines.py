"""Pull NetSuite income by account, client and Project ID (the line entity, the contract code)
for the nine 2026 periods January through September, over SuiteQL. Journal entry lines with
no client are re-attributed to the invoice their memo cites ("Inv ####"), as ns_2026_full.py
does. Writes <out.json>: {lines: [{acct, client, project, months{1..9}, total}]}.
Usage: ns_rev_lines.py <pipeline dir with .env> <out.json>"""
import json, pathlib, re, sys
import requests
from requests_oauthlib import OAuth1

PIPE, OUT = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
env = {}
for line in (PIPE / ".env").read_text().splitlines():
    s = line.strip()
    if s and not s.startswith("#") and "=" in s:
        k, v = s.split("=", 1); env[k.strip()] = v.strip()
ACCOUNT = env["NETSUITE_ACCOUNT_ID"]; HOST = ACCOUNT.lower().replace("_", "-")
BASE = f"https://{HOST}.suitetalk.api.netsuite.com/services/rest/query/v1/suiteql"
auth = OAuth1(env["NETSUITE_CONSUMER_KEY"], env["NETSUITE_CONSUMER_SECRET"], env["NETSUITE_TOKEN_ID"], env["NETSUITE_TOKEN_SECRET"], signature_method="HMAC-SHA256", realm=ACCOUNT)

def q(sql):
    items, off = [], 0
    while True:
        r = requests.post(f"{BASE}?limit=1000&offset={off}", auth=auth, headers={"Prefer": "transient", "Content-Type": "application/json"}, json={"q": sql}, timeout=120)
        if r.status_code >= 400: raise SystemExit(f"SuiteQL {r.status_code}: {r.text[:500]}")
        j = r.json(); items += j.get("items", [])
        if not j.get("hasMore"): break
        off += 1000
    return items

periods = q("SELECT id, startdate FROM accountingperiod WHERE startdate >= TO_DATE('2026-01-01','YYYY-MM-DD') AND startdate < TO_DATE('2026-10-01','YYYY-MM-DD') AND isquarter = 'F' AND isyear = 'F' ORDER BY startdate")
pid_to_month = {str(p["id"]): int(str(p["startdate"]).split("/")[0]) for p in periods}
pids = ",".join(pid_to_month.keys())

# invoices, for re-attributing journal entry lines that cite them
invmap = {}
for x in q("""SELECT t.tranid tid, BUILTIN.DF(t.entity) client, BUILTIN.DF(tl.entity) proj, a.accttype atype
FROM transaction t JOIN transactionline tl ON tl.transaction = t.id JOIN account a ON a.id = tl.account
WHERE t.recordtype = 'invoice' AND t.trandate >= TO_DATE('2025-01-01','YYYY-MM-DD')"""):
    tid = str(x.get("tid") or "").strip()
    if not tid: continue
    cur = invmap.setdefault(tid, {})
    if x.get("client") and not cur.get("client"): cur["client"] = x["client"]
    if x.get("atype") == "Income" and x.get("proj") and not cur.get("proj"): cur["proj"] = x["proj"]
INV = re.compile(r"inv\s*#?\s*(\d{3,})", re.I)

rows = q(f"""SELECT tl.account acct, t.postingperiod pp, t.recordtype rt, BUILTIN.DF(t.entity) client, BUILTIN.DF(tl.entity) proj,
  t.memo hm, tl.memo lm, ROUND(tl.amount, 2) amt
FROM transactionline tl JOIN transaction t ON t.id = tl.transaction JOIN account a ON a.id = tl.account
WHERE t.posting = 'T' AND t.postingperiod IN ({pids}) AND a.accttype = 'Income'""")
agg = {}
unattributed = 0.0
for r in rows:
    m = pid_to_month[str(r["pp"])]; amt = -float(r["amt"] or 0)
    client, proj = r.get("client") or "", r.get("proj") or ""
    if not client:
        for memo in (r.get("hm"), r.get("lm")):
            mm = INV.search(memo or "")
            if mm and mm.group(1) in invmap:
                d = invmap[mm.group(1)]; client = d.get("client") or client; proj = proj or d.get("proj") or ""; break
    if not client: client = "(no customer on the entry)"; unattributed += amt
    key = (str(r["acct"]), client, proj)
    agg.setdefault(key, {})[m] = round(agg.get(key, {}).get(m, 0) + amt, 2)
# A line with no client but a Project ID: the client the code belongs to, from the invoices first, then the pro forma sheet.
code_client = {}
for d in invmap.values():
    if d.get("proj") and d.get("client"): code_client.setdefault(d["proj"].strip(), d["client"])
try:
    import openpyxl
    ws = openpyxl.load_workbook(sys.argv[3], data_only=True)["PRO FORMA 2026"]
    for r in range(9, 192):
        code, name = ws.cell(r, 3).value, ws.cell(r, 2).value
        if code and name and str(code).strip() not in ("NEW", "Adjacent", "EXISTING MSA"): code_client.setdefault(str(code).strip(), str(name).strip())
except Exception as e:
    print("no sheet map:", e)
fixed = {}
still = 0.0
for (a, c, pcode), v in agg.items():
    if c == "(no customer on the entry)":
        hit = code_client.get(pcode.strip()) if pcode else None
        flag = None
        if not hit and pcode:
            # the code is not on an invoice or the sheet: the sheet code sharing the longest prefix (12+ characters),
            # else the sheet code ending in the same client token; such a line carries a "Client by code" flag
            code = pcode.strip().upper().replace(" ", "-")
            best, bestn = None, 0
            for k, cl in code_client.items():
                kk = k.upper().replace(" ", "-")
                n = 0
                while n < min(len(code), len(kk)) and code[n] == kk[n]: n += 1
                if n >= 12 and n > bestn: best, bestn = cl, n
            if not best:
                tok = code.split("-")[-1]
                cands = {cl for k, cl in code_client.items() if k.upper().replace(" ", "-").split("-")[-1] == tok and len(tok) >= 3}
                if len(cands) == 1: best = cands.pop()
            if best: hit, flag = best, "Client by code"
        if hit: c = hit + ("\u0000" + flag if flag else "")
        else: still += sum(v.values())
    key = (a, c, pcode)
    for m, amt in v.items(): fixed.setdefault(key, {})[m] = round(fixed.get(key, {}).get(m, 0) + amt, 2)
agg = fixed
print(f"after the Project ID map: unattributed {still:,.2f}")
lines = [{"acct": a, "client": c.split("\u0000")[0], "flag": (c.split("\u0000")[1] if "\u0000" in c else None), "project": p, "months": {str(m): v.get(m, 0) for m in range(1, 10)}, "total": round(sum(v.values()), 2)} for (a, c, p), v in agg.items()]
OUT.write_text(json.dumps({"lines": lines}, indent=1))
tot = sum(l["total"] for l in lines)
print(f"lines {len(lines)} | total {tot:,.2f} | unattributed {unattributed:,.2f} | clients {len({l['client'] for l in lines})} | with project id {sum(1 for l in lines if l['project'])}")
for l in sorted(lines, key=lambda l: -l["total"])[:8]: print("  ", l["acct"], "|", l["client"][:34], "|", l["project"][:28], "|", f"{l['total']:,.2f}")
